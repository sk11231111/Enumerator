"""
report.py — build a clean, comprehensive PDF "Enumeration report" from a parsed
enumerator run (the dict produced by server.parse_run()).

Design goals: aerated editorial layout, restrained single-accent palette,
hairline-ruled section headers (no heavy filled bars), everything legible and
on one line. Pure-Python (reportlab); no system dependencies.

Section order:
  01 Executive summary
  02 Scope
  03 Ports and services
  04 Loot (credentials + sources, files/shares/ftp collected, flags)
  05 BloodHound analysis - Attack paths
  06 Web & fuzzing
  07 Tools used and command-line history
"""
from __future__ import annotations

import re
import sys
import io
import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle,
    KeepTogether, HRFlowable,
)

# ---- palette (light, one calm accent) -----------------------------------
INK = colors.HexColor("#222b35")      # primary headings / strong text
BODY = colors.HexColor("#333d49")     # body text
MUTE = colors.HexColor("#6a7886")     # secondary / labels
ACCENT = colors.HexColor("#2e6da4")   # the single accent: numbers, rules, links
ACCENT_D = colors.HexColor("#1d4f7d")
RULE = colors.HexColor("#dde3ea")     # hairlines
RULE_H = colors.HexColor("#c7d0da")   # rule under section headings
THBG = colors.HexColor("#eef2f7")     # table header background (neutral)
THINK = colors.HexColor("#2b3742")    # table header text
ZEBRA = colors.HexColor("#fafbfc")
CODEBG = colors.HexColor("#f6f8fb")
CODEBORDER = colors.HexColor("#dbe2ea")
RED = colors.HexColor("#bf2f3c")
AMBER = colors.HexColor("#9a6b00")
GREEN = colors.HexColor("#1d7a4d")
PANEL = colors.HexColor("#f7f9fc")


def hx(c):
    return "#" + c.hexval()[2:]


# ---- unicode -> latin-1 sanitiser ---------------------------------------
_UNI = {
    "\u21d2": "=>", "\u2192": "->", "\u21b3": "->", "\u2550": "=", "\u2500": "-",
    "\u2502": "|", "\u2605": "*", "\u2606": "*", "\u2726": "*", "\u25b8": ">",
    "\u25b6": ">", "\u00b7": "-", "\u2022": "-", "\u2514": "-", "\u251c": "-",
    "\u2026": "...", "\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"',
    "\u2013": "-", "\u2014": "-", "\u00a0": " ", "\u2713": "[x]", "\u2717": "[ ]",
    "\u2744": "*", "\u2691": "flag", "\u25aa": "-",
}


def _clean(s) -> str:
    s = "" if s is None else str(s)
    for k, v in _UNI.items():
        s = s.replace(k, v)
    return s.encode("latin-1", "replace").decode("latin-1")


def S(s) -> str:
    return _clean(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ---- styles --------------------------------------------------------------
def _styles():
    ss = getSampleStyleSheet()
    st = {}
    st["coverttl"] = ParagraphStyle("ct", parent=ss["Title"], fontName="Helvetica-Bold",
                                    fontSize=30, textColor=INK, leading=33, spaceAfter=4, alignment=0)
    st["coversub"] = ParagraphStyle("cs", fontName="Helvetica", fontSize=13,
                                    textColor=ACCENT, leading=17, spaceAfter=2)
    st["covermeta"] = ParagraphStyle("cm", fontName="Helvetica", fontSize=8.5,
                                     textColor=MUTE, leading=12)
    st["statn"] = ParagraphStyle("sn", fontName="Helvetica", fontSize=8, textColor=INK,
                                 leading=17, alignment=1)
    st["section"] = ParagraphStyle("sec", fontName="Helvetica-Bold", fontSize=14.5,
                                   textColor=INK, leading=18, spaceBefore=6, spaceAfter=0)
    st["h3"] = ParagraphStyle("h3", fontName="Helvetica-Bold", fontSize=10.5,
                             textColor=ACCENT_D, leading=14, spaceBefore=11, spaceAfter=4)
    st["eyebrow"] = ParagraphStyle("eb", fontName="Helvetica-Bold", fontSize=7,
                                  textColor=ACCENT, leading=10, spaceBefore=12, spaceAfter=1)
    st["objttl"] = ParagraphStyle("ot", fontName="Helvetica-Bold", fontSize=11.5,
                                 textColor=INK, leading=15, spaceAfter=3)
    st["route"] = ParagraphStyle("rt", fontName="Helvetica-Bold", fontSize=9.6,
                                textColor=BODY, leading=13, spaceBefore=9, spaceAfter=3, leftIndent=2)
    st["body"] = ParagraphStyle("b", fontName="Helvetica", fontSize=9.4,
                               textColor=BODY, leading=13.5, spaceAfter=4)
    st["note"] = ParagraphStyle("n", fontName="Helvetica", fontSize=8.6,
                               textColor=MUTE, leading=12, spaceAfter=2, leftIndent=4)
    st["step"] = ParagraphStyle("st", fontName="Helvetica", fontSize=9.3,
                               textColor=BODY, leading=13, leftIndent=12, spaceBefore=5, spaceAfter=1)
    st["code"] = ParagraphStyle("code", fontName="Courier", fontSize=7.8,
                               textColor=colors.HexColor("#15293a"), leading=10.8,
                               backColor=CODEBG, borderColor=CODEBORDER, borderWidth=0.6,
                               borderPadding=(6, 7, 6, 7), leftIndent=12, spaceBefore=6, spaceAfter=8)
    st["mono"] = ParagraphStyle("mono", fontName="Courier", fontSize=7.6,
                               textColor=colors.HexColor("#243240"), leading=11.4, spaceAfter=0, leftIndent=2)
    st["cell"] = ParagraphStyle("cell", fontName="Helvetica", fontSize=8.4,
                               textColor=BODY, leading=11)
    st["cellc"] = ParagraphStyle("cellc", fontName="Courier", fontSize=8, textColor=BODY, leading=11)
    st["th"] = ParagraphStyle("th", fontName="Helvetica-Bold", fontSize=8, textColor=THINK, leading=10)
    st["tag"] = ParagraphStyle("tg", fontName="Helvetica-Bold", fontSize=7.6, leading=10, splitLongWords=0)
    st["link"] = ParagraphStyle("lk", fontName="Helvetica", fontSize=8.3,
                               textColor=ACCENT, leading=11, leftIndent=12, spaceAfter=5)
    st["meta"] = ParagraphStyle("m", fontName="Helvetica", fontSize=8.7,
                               textColor=MUTE, leading=12, spaceAfter=3)
    return st


# ---- helpers -------------------------------------------------------------
def _looks_cmd(s: str) -> bool:
    return bool(re.search(
        r"(^|\s)(certipy|nxc|netexec|crackmapexec|secretsdump\.py|addcomputer\.py|rbcd\.py|"
        r"getST\.py|GetUserSPNs\.py|GetNPUsers\.py|targetedKerberoast\.py|hashcat|john|"
        r"printerbug\.py|PetitPotam|Rubeus|bloodyAD|pywhisker|dacledit\.py|owneredit\.py|"
        r"net rpc|ntlmrelayx\.py|gpoabuse|SharpGPOAbuse|pyGPOAbuse|Certify|certutil|evil-winrm|"
        r"smbclient|ldapsearch|kinit|impacket-\w+|export KRB5CCNAME)(\s|$)", s, re.I)
    ) or bool(re.match(r"^\s*[A-Za-z0-9_.\/-]+\.(py|sh|ps1|exe)\b", s))


def _strip_or(s):
    return re.sub(r"^\s*\(or\)\s*", "", s)


def _human(n):
    try:
        n = float(n)
    except Exception:
        return "0 B"
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%d %s" % (int(n), unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1024.0


def _section(st, num, title):
    """An aerated, hairline-ruled section header (no filled bar)."""
    p = Paragraph('<font color="%s"><b>%s</b></font>&nbsp;&nbsp;&nbsp;<font color="%s"><b>%s</b></font>'
                  % (hx(ACCENT), num, hx(INK), S(title)), st["section"])
    rule = HRFlowable(width="100%", thickness=1.1, color=RULE_H, spaceBefore=4, spaceAfter=12)
    return [Spacer(1, 16), KeepTogether([p, rule])]


def _sev_tag(st, sev):
    sev = (sev or "").upper()
    col = RED if sev == "CRITICAL" else AMBER if sev in ("HIGH", "MEDIUM") else MUTE
    return Paragraph('<font color="%s">%s</font>' % (hx(col), S(sev or "-")), st["tag"])


def _tags(items):
    cmap = {"owned": GREEN, "admin": RED, "kerberoast": AMBER, "AS-REP": colors.HexColor("#6b3fa0"),
            "no-pw-req": RED, "disabled": MUTE, "DC": ACCENT, "unconstrained": AMBER}
    return "  ".join('<font color="%s"><b>%s</b></font>' % (hx(cmap.get(t, MUTE)), S(t)) for t in items) or "-"


def _table(data, col_widths, st, header=True, zebra=True, small=False):
    cellstyle = st["cellc"] if small else st["cell"]
    rows = []
    for i, r in enumerate(data):
        out = []
        for c in r:
            if hasattr(c, "wrap"):                       # already a flowable
                out.append(c)
            elif header and i == 0:
                out.append(Paragraph(S(c), st["th"]))
            elif isinstance(c, str) and ("<font" in c or "<b>" in c):
                out.append(Paragraph(c, cellstyle))      # pre-marked-up
            else:
                out.append(Paragraph(S(c), cellstyle))
        rows.append(out)
    t = Table(rows, colWidths=col_widths, repeatRows=1 if header else 0)
    style = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LINEBELOW", (0, 1 if header else 0), (-1, -1), 0.4, RULE),
    ]
    if header:
        style += [("BACKGROUND", (0, 0), (-1, 0), THBG),
                  ("LINEABOVE", (0, 0), (-1, 0), 0.6, RULE_H),
                  ("LINEBELOW", (0, 0), (-1, 0), 0.6, RULE_H),
                  ("TOPPADDING", (0, 0), (-1, 0), 5.5), ("BOTTOMPADDING", (0, 0), (-1, 0), 5.5)]
    if zebra:
        for i in range(1 + (1 if header else 0), len(rows), 2):
            style.append(("BACKGROUND", (0, i), (-1, i), ZEBRA))
    t.setStyle(TableStyle(style))
    return t


# ---- playbook typed-lines -> objectives ---------------------------------
def _parse_playbook(playbook):
    objs, techs, secs, notes = [], [], [], []
    cur_obj = cur_route = cur_sec = None

    def is_info(t):
        return re.search(r"don'?t control|don'?t hold|you don'?t|principals exist|not owned", t, re.I)

    for ln in playbook or []:
        t, v = ln.get("t"), ln.get("v", "")
        if t == "space":
            continue
        if t == "route_major":
            cur_obj = {"title": v, "intro": [], "routes": []}
            objs.append(cur_obj); cur_route = cur_sec = None; continue
        if t == "route":
            title = v.strip("- ").strip()
            if is_info(title):
                cur_sec = {"title": title, "body": [], "link": ""}; secs.append(cur_sec)
                cur_route = None; continue
            cur_route = {"title": title, "body": [], "link": ""}
            (cur_obj["routes"] if (title.upper().startswith("ROUTE") and cur_obj) else techs).append(cur_route)
            cur_sec = None; continue
        if t == "link":
            if cur_route:
                cur_route["link"] = v
            elif cur_sec:
                cur_sec["link"] = v
            elif cur_obj:
                cur_obj["intro"].append(("link", v))
            else:
                notes.append(("link", v))
            continue
        item = (t, v)
        (cur_route["body"] if cur_route else cur_sec["body"] if cur_sec
         else cur_obj["intro"] if cur_obj else notes).append(item)
    return objs, techs, secs, notes


def _route_parts(title):
    name = re.sub(r"^ROUTE\s*[A-Z]?\s*[\-:]\s*", "", _clean(title), flags=re.I)
    tag = ""
    m = re.search(r"\(([^)]+)\)", name)
    if m:
        tag = re.split(r"[;,]", m.group(1))[0].strip()
        name = re.sub(r"\s*\([^)]*\)", "", name).strip()
    sub = ""
    mm = re.match(r"^(.*?)\s*::\s*(.+)$", name)
    if mm:
        name, sub = mm.group(1).strip(), mm.group(2).strip()
    return name, tag, sub


def _render_body(body, st):
    out = []
    n = 0
    for t, v in body:
        if t == "step":
            rest = re.sub(r"^\d+\)\s*", "", v)
            n += 1
            if _looks_cmd(rest):
                out.append(Paragraph('<font color="%s"><b>%d.</b></font>' % (hx(ACCENT), n), st["step"]))
                out.append(Paragraph(S(_strip_or(rest)), st["code"]))
            else:
                out.append(Paragraph('<font color="%s"><b>%d.</b></font> %s' % (hx(ACCENT), n, S(rest)), st["step"]))
        elif t == "cmd" or _looks_cmd(v):
            out.append(Paragraph(S(_strip_or(v)), st["code"]))
        elif t == "comment":
            out.append(Paragraph(S(re.sub(r"^#\s*", "", v)), st["note"]))
        else:
            out.append(Paragraph(S(v), st["note"]))
    return out


def _render_route(route, st, label):
    name, tag, sub = _route_parts(route["title"])
    hdr = '<font color="%s"><b>%s</b></font>&nbsp;&nbsp;<font color="%s"><b>%s</b></font>' % (
        hx(ACCENT), S(label), hx(INK), S(name))
    if tag:
        hdr += '&nbsp;&nbsp;<font color="%s" size="7.5">- %s</font>' % (hx(MUTE), S(tag))
    flow = [Paragraph(hdr, st["route"])]
    if sub:
        flow.append(Paragraph('<font color="%s">targets: %s</font>' % (hx(AMBER), S(sub)), st["note"]))
    flow += _render_body(route["body"], st)
    if route.get("link"):
        flow.append(Paragraph('<link href="%s"><font color="%s">HackTricks reference &gt;</font></link>'
                              % (S(route["link"]), hx(ACCENT)), st["link"]))
    return flow


def _attack_paths(bh, st):
    flow = []
    objs, techs, secs, notes = _parse_playbook(bh.get("playbook"))
    if not (objs or techs or secs or bh.get("findings")):
        return [Paragraph("No privilege path or dangerous ACL was identified for the accounts "
                         "in this dataset.", st["body"])]
    for idx, obj in enumerate(objs, 1):
        title = re.sub(r"^[=\s]+|[=\s]+$", "", obj["title"])
        eyebrow = "ATTACK PATH %d  -  TO DOMAIN ADMIN" % idx if "domain admin" in title.lower() else "PRIVILEGE PATH %d" % idx
        o = S(title).replace("Domain Admin", '<font color="%s"><b>Domain Admin</b></font>' % hx(GREEN))
        head = [Paragraph(eyebrow, st["eyebrow"]), Paragraph(o, st["objttl"])]
        for it_t, it_v in obj["intro"]:
            if it_t in ("meta", "text"):
                head.append(Paragraph(S(it_v), st["meta"]))
        flow.append(KeepTogether(head))
        for i, r in enumerate(obj["routes"]):
            flow += _render_route(r, st, "ROUTE " + chr(65 + i))
    if techs:
        flow.append(Paragraph("Other techniques available", st["h3"]))
        for r in techs:
            flow += _render_route(r, st, "TECHNIQUE")
    for sc in secs:
        flow.append(Paragraph(S(sc["title"]), st["route"]))
        flow += _render_body(sc["body"], st)
        if sc.get("link"):
            flow.append(Paragraph('<link href="%s"><font color="%s">reference &gt;</font></link>'
                                 % (S(sc["link"]), hx(ACCENT)), st["link"]))
    link_notes = [v for (t, v) in notes if t == "link"]
    if link_notes:
        flow.append(Paragraph("References", st["h3"]))
        for u in link_notes:
            flow.append(Paragraph('<link href="%s"><font color="%s">%s</font></link>' % (S(u), hx(ACCENT), S(u)), st["link"]))
    return flow


# ---- page furniture ------------------------------------------------------
def _decorate(canvas, doc):
    canvas.saveState()
    w, h = A4
    # top hairline only on inner pages; cover gets the accent rule from the story
    canvas.setStrokeColor(RULE); canvas.setLineWidth(0.5)
    canvas.line(20 * mm, 13 * mm, w - 20 * mm, 13 * mm)
    canvas.setFont("Helvetica", 7.3); canvas.setFillColor(MUTE)
    canvas.drawString(20 * mm, 9 * mm, "Enumeration report  -  authorized engagement, confidential")
    canvas.drawRightString(w - 20 * mm, 9 * mm, "Page %d" % doc.page)
    canvas.restoreState()


# ---- main ----------------------------------------------------------------
def build_report(data: dict) -> bytes:
    st = _styles()
    s = data.get("summary", {}) or {}
    stats = data.get("stats", {}) or {}
    creds = data.get("creds", {}) or {}
    bh = data.get("bloodhound", {}) or {}
    directory = data.get("directory", {}) or {}
    web = data.get("web", []) or []
    loot = data.get("loot", {}) or {}
    cmds = data.get("commands", {}) or {}
    crit = data.get("critical_leads", []) or []

    buf = io.BytesIO()
    doc = BaseDocTemplate(buf, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm,
                          topMargin=20 * mm, bottomMargin=17 * mm,
                          title="Enumeration report - %s" % (s.get("ip") or "target"),
                          author="enumerator")
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="main")
    doc.addPageTemplates([PageTemplate(id="t", frames=[frame], onPage=_decorate)])

    story = []
    cw = doc.width
    ip = s.get("ip") or "unknown target"
    dom = s.get("domain") or ""

    # ===== cover =====
    story.append(HRFlowable(width="100%", thickness=2.4, color=ACCENT, spaceAfter=18))
    story.append(Paragraph("Enumeration report", st["coverttl"]))
    story.append(Paragraph(S(ip) + ("  &nbsp;/&nbsp;  " + S(dom) if dom else ""), st["coversub"]))
    gen = s.get("generated") or datetime.date.today().isoformat()
    story.append(Paragraph("Mode: %s &nbsp;&nbsp;/&nbsp;&nbsp; Generated: %s &nbsp;&nbsp;/&nbsp;&nbsp; Run: %s"
                          % (S(s.get("mode") or "?"), S(gen), S(data.get("id", "-"))), st["covermeta"]))
    story.append(Spacer(1, 16))

    # snapshot figures (clean, no fill) - guarded so a bad stat can never break the cover
    try:
        figs = [(stats.get("ports", 0), "OPEN PORTS"), (stats.get("exploitable", 0), "EXPLOITABLE"),
                (stats.get("users", 0), "USERS"), (stats.get("computers", 0), "COMPUTERS"),
                (stats.get("valid_creds", 0), "CREDENTIALS"), (stats.get("flags", 0), "FLAGS"),
                (stats.get("critical", 0), "CRITICAL")]
        cells = [Paragraph('<font size="16" color="%s"><b>%s</b></font><br/><font size="6.3" color="%s">%s</font>'
                           % (hx(INK), S(v), hx(MUTE), lab), st["statn"]) for v, lab in figs]
        stt = Table([cells], colWidths=[cw / 7.0] * 7)
        stt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                 ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                                 ("LINEABOVE", (0, 0), (-1, 0), 0.8, RULE_H),
                                 ("LINEBELOW", (0, 0), (-1, 0), 0.8, RULE_H),
                                 ("LINEAFTER", (0, 0), (-2, 0), 0.5, RULE)]))
        story.append(stt)
    except Exception:
        import traceback
        traceback.print_exc()

    # ===== sections, each fault-isolated so one bad section can never 500 the export =====
    def sec_exec():
        out = []
        objs0, _t, _s, _n = _parse_playbook(bh.get("playbook"))
        has_path = bool(bh.get("attack_path")) or any(o["routes"] for o in objs0)
        if has_path:
            verdict = ("A complete privilege-escalation path to <b>Domain Admin</b> was identified during "
                       "this engagement. The actionable steps are detailed in section 05.")
        elif stats.get("valid_creds"):
            verdict = ("Valid domain credentials were obtained. No direct path to Domain Admin has been "
                       "confirmed yet; continue from the leads below.")
        else:
            verdict = "Reconnaissance completed. Review the priority findings below for the next foothold."
        out.append(Paragraph(verdict, st["body"]))
        if bh.get("adcs"):
            out.append(Paragraph("Active Directory Certificate Services was found to be vulnerable to "
                                 "certificate-template (ESC) abuse - see section 05.", st["body"]))
        if crit:
            out.append(Paragraph("Priority findings", st["h3"]))
            rows = [["Severity", "Finding", "Recommended next action"]]
            for l in crit:
                rows.append([_sev_tag(st, l.get("sev")), S(l.get("text", "")), S(l.get("action", ""))])
            out.append(_table(rows, [22 * mm, (cw - 22 * mm) * 0.5, (cw - 22 * mm) * 0.5], st))
        else:
            out.append(Paragraph("No critical or high-severity findings were recorded.", st["note"]))
        return out

    def sec_scope():
        out = []
        rows = [["Field", "Value"], ["Target host", S(ip)]]
        if dom:
            rows.append(["Domain", S(dom)])
        rows.append(["Authentication", "Authenticated (credentialed)" if (s.get("mode") == "auth") else "Unauthenticated"])
        rows.append(["Open ports", "%d (%s)" % (len(s.get("open_ports", [])), S(", ".join(s.get("open_ports", []))) or "none")])
        rows.append(["Report generated", S(gen)])
        out.append(_table(rows, [38 * mm, cw - 38 * mm], st))
        out.append(Paragraph("This report covers only the host above and was produced from an authorized "
                             "security assessment. All findings and credentials are confidential.", st["note"]))
        return out

    def sec_ports():
        out = []
        ports = s.get("open_ports", [])
        out.append(Paragraph("<b>%d</b> open ports: %s" % (len(ports), S(", ".join(ports)) or "none"), st["body"]))
        svcs = s.get("services", [])
        if svcs:
            rows = [["Port", "Service", "Product / version", "Notes", "Status"]]
            for sv in svcs:
                status = ('<font color="%s"><b>exploitable</b></font>' % hx(RED)) if sv.get("hot") else \
                         ('<font color="%s">open</font>' % hx(MUTE))
                rows.append([S(sv.get("port", "")), S(sv.get("service", sv.get("key", ""))),
                             S(sv.get("product", "")), S(sv.get("notes", "")), status])
            mid = (cw - 11 * mm - 24 * mm - 26 * mm) / 2.0
            out.append(_table(rows, [11 * mm, 24 * mm, mid, mid, 26 * mm], st))
            for sv in svcs:
                if sv.get("findings"):
                    out.append(Paragraph("%s - notes" % S(sv.get("service", sv.get("key", ""))), st["h3"]))
                    for f in sv["findings"]:
                        out.append(Paragraph("- " + S(f), st["note"]))
        else:
            out.append(Paragraph("No service table was parsed for this run.", st["note"]))
        if s.get("fscan"):
            out.append(Paragraph("fscan key findings", st["h3"]))
            for f in s["fscan"][:60]:
                out.append(Paragraph("- " + S(f), st["note"]))
        return out

    def sec_loot():
        out = []
        held = {c.get("account", "").lower(): c for c in bh.get("creds_held", [])}
        any_loot = False
        cred_rows = [["Account / item", "Secret / value", "Source"]]
        for v in creds.get("valid", []):
            h = held.get(str(v.get("user", "")).lower())
            src = "validated login (privileged)" if (h and h.get("privesc")) else "validated login"
            cred_rows.append([S(v.get("user", "")), S(v.get("password") or "(blank)"), src])
        for f in creds.get("ldap_fields", [])[:60]:
            cred_rows.append([Paragraph(S(f), st["cellc"]), "", "LDAP attribute"])
        for c in creds.get("candidates", [])[:80]:
            cred_rows.append([Paragraph(S(c), st["cellc"]), "", "candidate / dump"])
        if len(cred_rows) > 1:
            any_loot = True
            out.append(Paragraph("Credentials &amp; secrets obtained", st["h3"]))
            out.append(_table(cred_rows, [cw * 0.40, cw * 0.34, cw * 0.26], st))
        cats = loot.get("categories", {})
        if cats:
            any_loot = True
            out.append(Paragraph("Files &amp; artifacts collected (%d files, %s)"
                                 % (loot.get("total", 0), _human(loot.get("bytes", 0))), st["h3"]))
            for cat in sorted(cats):
                files = cats[cat] or []
                out.append(Paragraph("%s (%d)" % (S(cat), len(files)), st["route"]))
                for f in files[:80]:
                    out.append(Paragraph("%s &nbsp;&nbsp;<font color='%s'>%s</font>"
                                         % (S(f.get("path", "")), hx(MUTE), _human(f.get("size", 0))), st["mono"]))
        if creds.get("flags"):
            any_loot = True
            out.append(Paragraph("Flags captured", st["h3"]))
            rows = [["Name", "Value", "Path"]]
            for f in creds["flags"]:
                rows.append([S(f.get("name", "") or "flag"), Paragraph(S(f.get("value", "")), st["cellc"]),
                             Paragraph(S(f.get("path", "")), st["cellc"])])
            out.append(_table(rows, [22 * mm, (cw - 22 * mm) * 0.45, (cw - 22 * mm) * 0.55], st))
        if not any_loot:
            out.append(Paragraph("Nothing was looted on this run.", st["note"]))
        return out

    def sec_bh():
        out = []
        if not bh.get("present"):
            out.append(Paragraph("No BloodHound or ADCS analysis is available for this run (run "
                                 "authenticated with collection enabled to populate this section).", st["note"]))
            return out
        if bh.get("creds_held"):
            out.append(Paragraph("Credentials held - capability summary", st["h3"]))
            rows = [["Account", "Capability"]]
            for c in bh["creds_held"]:
                cap = ('<font color="%s"><b>%s</b></font>' % (hx(GREEN), S(c.get("capability", "")))) \
                    if c.get("privesc") else S(c.get("capability", ""))
                rows.append([S(c.get("account", "")), cap])
            out.append(_table(rows, [42 * mm, cw - 42 * mm], st))
        out += _attack_paths(bh, st)
        if bh.get("findings"):
            out.append(Paragraph("Supporting findings", st["h3"]))
            for f in bh["findings"]:
                out.append(Paragraph(S(f.get("title", "")), st["route"]))
                for it in f.get("items", []):
                    out.append(Paragraph("- " + S(it), st["note"]))
        us = directory.get("users", [])
        cs = directory.get("computers", [])
        if us:
            out.append(Paragraph("Domain users (%d)" % len(us), st["h3"]))
            rows = [["User", "Attributes", "Description"]]
            for u in us:
                tags = []
                for k, lab in (("owned", "owned"), ("admin", "admin"), ("kerberoastable", "kerberoast"),
                               ("asrep", "AS-REP"), ("pwdnotreqd", "no-pw-req")):
                    if u.get(k):
                        tags.append(lab)
                if not u.get("enabled", True):
                    tags.append("disabled")
                rows.append([S(u.get("name", "")), _tags(tags), S((str(u.get("desc", "") or ""))[:80])])
            out.append(_table(rows, [38 * mm, 54 * mm, cw - 92 * mm], st))
        if cs:
            out.append(Paragraph("Domain computers (%d)" % len(cs), st["h3"]))
            rows = [["Computer", "Operating system", "Attributes"]]
            for c in cs:
                tags = []
                if c.get("dc"):
                    tags.append("DC")
                if c.get("unconstrained") and not c.get("dc"):
                    tags.append("unconstrained")
                if c.get("owned"):
                    tags.append("owned")
                rows.append([S(c.get("name", "")), S(c.get("os", "")), _tags(tags)])
            out.append(_table(rows, [34 * mm, cw - 84 * mm, 50 * mm], st))
        return out

    def sec_web():
        out = []
        if not web:
            out.append(Paragraph("N/A - no web services were enumerated on this host.", st["body"]))
            return out
        for wp in web:
            out.append(Paragraph("Port %s" % S(wp.get("port", "")), st["h3"]))
            tech = (wp.get("tech") or "").strip()
            if tech:
                for line in tech.splitlines()[:16]:
                    if line.strip():
                        out.append(Paragraph(S(line.strip()), st["mono"]))
            for n in (wp.get("nuclei") or [])[:60]:
                col = RED if n.get("sev") in ("critical", "high") else AMBER if n.get("sev") == "medium" else MUTE
                out.append(Paragraph('<font color="%s">%s</font>' % (hx(col), S(n.get("line", ""))), st["mono"]))
            paths = wp.get("paths") or []
            if paths:
                out.append(Paragraph("discovered content (%d shown)" % min(len(paths), 80), st["route"]))
                for p in paths[:80]:
                    out.append(Paragraph("<font color='%s'>%s</font>&nbsp;&nbsp;%s"
                                         % (hx(ACCENT), S(p.get("code", "")), S(p.get("url", ""))), st["mono"]))
        return out

    def sec_tools():
        out = []
        tools = cmds.get("tools", [])
        if tools:
            out.append(Paragraph("Tools used", st["h3"]))
            pairs = [(t.get("name", ""), str(t.get("count", ""))) for t in tools]
            half = (len(pairs) + 1) // 2
            left, right = pairs[:half], pairs[half:]
            rows = [["Tool", "Runs", "Tool", "Runs"]]
            for i in range(half):
                l = left[i]
                r = right[i] if i < len(right) else ("", "")
                rows.append([S(l[0]), l[1], S(r[0]), r[1]])
            out.append(_table(rows, [cw * 0.34, cw * 0.16, cw * 0.34, cw * 0.16], st))
        cmd_list = cmds.get("commands", [])
        if cmd_list:
            out.append(Paragraph("Command-line history (%d commands, in order)" % len(cmd_list), st["h3"]))
            out.append(Paragraph("Full audit trail of every command executed during the engagement.", st["note"]))
            out.append(Spacer(1, 3))
            for i, c in enumerate(cmd_list, 1):
                out.append(Paragraph('<font color="%s">%3d</font>&nbsp;&nbsp;$ %s' % (hx(MUTE), i, S(c)), st["mono"]))
        if not tools and not cmd_list:
            out.append(Paragraph("No command log was recorded for this run.", st["note"]))
        return out

    SECTIONS = [("01", "Executive summary", sec_exec), ("02", "Scope", sec_scope),
                ("03", "Ports and services", sec_ports), ("04", "Loot", sec_loot),
                ("05", "BloodHound analysis - Attack paths", sec_bh),
                ("06", "Web & fuzzing", sec_web),
                ("07", "Tools used and command-line history", sec_tools)]
    for num, title, fn in SECTIONS:
        story += _section(st, num, title)
        try:
            story += fn()
        except Exception as e:
            import traceback
            sys.stderr.write("[report] section %s (%s) failed: %s\n" % (num, title, e))
            traceback.print_exc()
            story.append(Paragraph("This section could not be fully rendered due to an unexpected "
                                   "formatting issue (%s). The underlying data was still captured."
                                   % S("%s: %s" % (type(e).__name__, e)), st["note"]))

    # ===== build with a safety net: if the assembled story fails to lay out, emit a condensed fallback =====
    try:
        doc.build(story)
        return buf.getvalue()
    except Exception:
        import traceback
        sys.stderr.write("[report] full layout failed; emitting condensed fallback\n")
        traceback.print_exc()
    buf2 = io.BytesIO()
    doc2 = BaseDocTemplate(buf2, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm,
                           topMargin=20 * mm, bottomMargin=17 * mm, title="Enumeration report")
    doc2.addPageTemplates([PageTemplate(id="t", frames=[
        Frame(doc2.leftMargin, doc2.bottomMargin, doc2.width, doc2.height, id="m")], onPage=_decorate)])
    mini = [HRFlowable(width="100%", thickness=2.4, color=ACCENT, spaceAfter=18),
            Paragraph("Enumeration report", st["coverttl"]),
            Paragraph(S(ip) + (("  /  " + S(dom)) if dom else ""), st["coversub"]),
            Spacer(1, 14),
            Paragraph("The full report layout hit an unexpected issue, so a condensed version is shown. "
                      "Credentials and the command audit trail are below.", st["note"]),
            Spacer(1, 8)]
    if creds.get("valid"):
        mini.append(Paragraph("Credentials obtained", st["h3"]))
        for v in creds["valid"]:
            mini.append(Paragraph("%s : %s" % (S(v.get("user", "")), S(v.get("password") or "(blank)")), st["mono"]))
    if cmds.get("commands"):
        mini.append(Paragraph("Command-line history", st["h3"]))
        for i, c in enumerate(cmds["commands"], 1):
            mini.append(Paragraph("%3d  $ %s" % (i, S(c)), st["mono"]))
    doc2.build(mini)
    return buf2.getvalue()
