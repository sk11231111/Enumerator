#!/usr/bin/env python3
"""
enumerator.sh web dashboard — backend + parser.

Reads the artifacts that enumerator.sh writes into each `enum_<ip>_<stamp>/`
run directory and exposes them as JSON for the single-page UI. Optionally
launches new scans and streams their console output over a websocket.

Run:
    pip install -r requirements.txt
    ENUM_SCAN_ROOT=/path/holding/enum_dirs ENUM_SCRIPT=/path/to/enumerator.sh \
        uvicorn server:app --host 127.0.0.1 --port 8000

Everything binds to localhost by design. Scans run with shell=False and a
whitelisted flag set.
"""
import os
import re
import csv
import io
import json
import time
import signal
import shutil
import asyncio
import secrets
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Query, Body, Response
from fastapi.responses import HTMLResponse, PlainTextResponse, FileResponse
from fastapi.staticfiles import StaticFiles

# --------------------------------------------------------------------------- #
#  Configuration (all overridable via environment)                            #
# --------------------------------------------------------------------------- #
HERE = Path(__file__).resolve().parent
SCAN_ROOT = Path(os.environ.get("ENUM_SCAN_ROOT", ".")).expanduser().resolve()
ENUM_SCRIPT = os.environ.get("ENUM_SCRIPT", "./enumerator.sh")
ALLOW_SCAN = os.environ.get("ENUM_ALLOW_SCAN", "1") != "0"

ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
RUN_RE = re.compile(r"^enum_(?P<ip>[^_]+(?:_[^_]+)*?)_(?P<stamp>\d{8}_\d{6})$")
PORT_SVC = {  # port -> (service-key, keyword aliases used to match leads)
    "21": ("ftp", ["ftp"]), "22": ("ssh", ["ssh"]),
    "23": ("telnet", ["telnet"]), "25": ("smtp", ["smtp", "mail"]),
    "53": ("dns", ["dns"]), "80": ("http", ["http", "web", "nuclei", "ferox", "ffuf"]),
    "88": ("kerberos", ["kerberos", "as-rep", "asrep", "kerberoast"]),
    "110": ("pop", ["pop3", "pop"]), "111": ("nfs", ["nfs", "rpcbind"]),
    "135": ("msrpc", ["msrpc", "rpc"]), "139": ("smb", ["smb", "netbios", "share"]),
    "143": ("imap", ["imap"]), "389": ("ldap", ["ldap", "bloodhound", "ldapdomaindump", "laps", "adcs", "certi"]),
    "443": ("http", ["https", "http", "web", "nuclei", "ferox", "ffuf"]),
    "445": ("smb", ["smb", "share", "gpp", "sysvol", "spider"]),
    "464": ("kerberos", ["kpasswd", "kerberos"]), "593": ("msrpc", ["rpc", "ncacn"]),
    "636": ("ldap", ["ldaps", "ldap"]), "1433": ("mssql", ["mssql", "sql server", "linked server"]),
    "3268": ("ldap", ["ldap", "global catalog"]), "3269": ("ldap", ["ldaps", "ldap"]),
    "3306": ("mysql", ["mysql", "mariadb"]), "3389": ("rdp", ["rdp", "remote desktop"]),
    "5432": ("postgres", ["postgres"]), "5985": ("winrm", ["winrm", "evil-winrm", "pwn3d"]),
    "5986": ("winrm", ["winrm", "evil-winrm"]), "8080": ("http", ["http", "web", "nuclei"]),
    "9389": ("adws", ["adws", "soap"]),
}
SEV_BY_PREFIX = {"[!!]": "critical", "[!]": "high", "[+]": "good", "[*]": "info", "★": "flag"}


def strip_ansi(s: str) -> str:
    return ANSI.sub("", s)


def _read(p: Path, limit: int = 600_000) -> str:
    try:
        data = p.read_text(errors="replace")
        return data if len(data) <= limit else data[:limit] + "\n…(truncated)…"
    except Exception:
        return ""


def _safe(rid: str) -> Path:
    """Resolve a run dir and refuse anything outside SCAN_ROOT."""
    if not RUN_RE.match(rid):
        raise HTTPException(404, "unknown run")
    d = (SCAN_ROOT / rid).resolve()
    if SCAN_ROOT not in d.parents and d != SCAN_ROOT:
        raise HTTPException(403, "path escapes scan root")
    if not d.is_dir():
        raise HTTPException(404, "run not found")
    return d


def _sev(text: str) -> str:
    for pre, sev in SEV_BY_PREFIX.items():
        if text.lstrip().startswith(pre):
            return sev
    return "info"


# --------------------------------------------------------------------------- #
#  Parsers                                                                     #
# --------------------------------------------------------------------------- #
def parse_summary(outdir: Path) -> dict:
    out = {
        "ip": "", "mode": "", "domain": "", "generated": "",
        "open_ports": [], "services": [], "fscan": [],
        "ldap_fields": [], "bloodhound": [], "leads": [],
        "present": False,
    }
    f = outdir / "_SUMMARY.txt"
    if not f.is_file():
        return out
    out["present"] = True
    lines = _read(f).splitlines()

    m = next((re.search(r"ENUMERATION SUMMARY\s*-\s*(\S+)", l) for l in lines if "ENUMERATION SUMMARY" in l), None)
    if m:
        out["ip"] = m.group(1)
    for l in lines:
        mm = re.search(r"Mode:\s*(\S+)\s+Domain:\s*(\S+)\s+Generated:\s*(.+)$", l)
        if mm:
            out["mode"], out["domain"], out["generated"] = mm.group(1), mm.group(2), mm.group(3).strip()
            break

    section = None
    pending_lead = None
    for raw in lines:
        l = raw.rstrip()
        s = l.strip()
        # section switches
        if s.startswith("OPEN PORTS:"):
            section = "ports"; continue
        if s.startswith("SERVICES ("):
            section = "services"; continue
        if s.startswith("FSCAN KEY FINDINGS:"):
            section = "fscan"; continue
        if s.startswith("LDAP CREDENTIAL-BEARING FIELDS"):
            section = "ldap"; continue
        if s.startswith("BLOODHOUND:"):
            section = "bh"; continue
        if "LEADS / NEXT STEPS" in s:
            section = "leads"; continue
        if not s:
            if section in ("ports", "fscan", "ldap", "bh"):
                section = None
            continue
        if set(s) <= {"-", "=", " "}:  # divider rule
            continue

        if section == "ports":
            out["open_ports"] = [p for p in re.split(r"[,\s]+", s) if p.isdigit()]
            section = None
        elif section == "services":
            mm = re.match(r"^\s*(\d+)\s+(\S+)?\s*(.*?)(?:\s*\|\s*(.*))?$", raw)
            if mm and mm.group(1):
                port = mm.group(1)
                key, _ = PORT_SVC.get(port, (mm.group(2) or "", []))
                out["services"].append({
                    "port": port,
                    "service": (mm.group(2) or "").strip(),
                    "product": (mm.group(3) or "").strip(),
                    "notes": (mm.group(4) or "").strip(),
                    "key": key,
                    "findings": [],
                    "hot": False,
                })
        elif section == "fscan":
            out["fscan"].append(s)
        elif section == "ldap":
            out["ldap_fields"].append(s)
        elif section == "bh":
            out["bloodhound"].append(s)
        elif section == "leads":
            if s.startswith("->"):
                if pending_lead is not None:
                    pending_lead["action"] += (" " if pending_lead["action"] else "") + s[2:].strip()
            elif re.match(r"^\[.+?\]", s):
                pending_lead = {"text": s, "action": "", "sev": _sev(s)}
                out["leads"].append(pending_lead)
            elif pending_lead is not None and not s.startswith("["):
                # continuation of an action line
                pending_lead["action"] += (" " if pending_lead["action"] else "") + s

    # cross-reference leads -> services (exploitability)
    for svc in out["services"]:
        port, key = svc["port"], svc["key"]
        aliases = PORT_SVC.get(port, (key, [key]))[1]
        for lead in out["leads"]:
            blob = (lead["text"] + " " + lead["action"]).lower()
            if (f":{port}" in blob or f" {port} " in blob
                    or any(a and a in blob for a in aliases)):
                if lead["sev"] in ("critical", "high"):
                    svc["findings"].append(lead["text"])
                    svc["hot"] = True
        # de-dup findings, keep order
        seen = set(); svc["findings"] = [x for x in svc["findings"] if not (x in seen or seen.add(x))]
    return out


def parse_creds(loot: Path) -> dict:
    res = {"valid": [], "candidates": [], "ldap_fields": [], "flags": [], "users": []}
    vc = loot / "valid_creds.txt"
    if vc.is_file():
        for l in _read(vc).splitlines():
            if not l.strip():
                continue
            parts = l.split("\t") if "\t" in l else l.split(None, 1)
            user = parts[0].strip()
            pw = parts[1].strip() if len(parts) > 1 else ""
            res["valid"].append({"user": user, "password": pw})
    seen = set()
    res["valid"] = [c for c in res["valid"] if not ((c["user"], c["password"]) in seen or seen.add((c["user"], c["password"])))]

    u = loot / "users.txt"
    if u.is_file():
        res["users"] = [x.strip() for x in _read(u).splitlines() if x.strip()]

    for cand in sorted(loot.glob("candidate_secrets_*.txt")):
        for l in _read(cand).splitlines():
            if l.strip():
                res["candidates"].append(l.strip())
    res["candidates"] = list(dict.fromkeys(res["candidates"]))

    for li in sorted(loot.glob("ldap_interesting_*.txt")):
        for l in _read(li).splitlines():
            if l.strip():
                res["ldap_fields"].append(l.strip())

    for ff in sorted(loot.glob("flags_*.txt")):
        for l in _read(ff).splitlines():
            if not l.strip():
                continue
            parts = l.split("\t")
            if len(parts) >= 2:
                res["flags"].append({
                    "name": parts[0].strip(),
                    "value": parts[1].strip(),
                    "path": parts[2].strip() if len(parts) > 2 else "",
                })
            else:
                res["flags"].append({"name": "", "value": l.strip(), "path": ""})
    return res


CATEGORY_RULES = [
    ("BloodHound", lambda n: n.startswith("bh_") or n == "bh_analysis.txt" or "bloodhound" in n),
    ("Hashes / dumps", lambda n: n.startswith(("ntds", "asrep", "kerb", "dcsync")) or n.endswith(".ntds")),
    ("LDAP dumps", lambda n: n.startswith(("ldap_", "ldd")) or n.startswith("domain_")),
    ("Credentials", lambda n: n.startswith(("valid_creds", "candidate_secrets", "users", "pwned"))),
    ("Flags", lambda n: n.startswith("flags_")),
    ("Web / fuzzing", lambda n: n.startswith(("nuclei_", "ferox_", "ffuf_"))),
]


def _categorize(name: str) -> str:
    low = name.lower()
    for label, fn in CATEGORY_RULES:
        if fn(low):
            return label
    return "Other"


def parse_loot(loot: Path) -> dict:
    res = {"categories": {}, "shares": [], "total": 0, "bytes": 0}
    if not loot.is_dir():
        return res
    for p in sorted(loot.rglob("*")):
        if p.is_dir():
            continue
        rel = p.relative_to(loot).as_posix()
        try:
            size = p.stat().st_size
        except Exception:
            size = 0
        res["total"] += 1; res["bytes"] += size
        if rel.startswith("shares/"):
            res["shares"].append({"path": rel, "size": size})
            cat = "Downloaded shares"
        else:
            cat = _categorize(p.name)
        res["categories"].setdefault(cat, []).append({"path": rel, "size": size})
    return res


def parse_web(outdir: Path, loot: Path) -> list:
    """One entry per web port: tech fingerprint, nuclei findings, discovered paths."""
    ports = {}
    for wf in sorted((outdir / "services").glob("web_*.txt")):
        m = re.search(r"web_(\d+)\.txt$", wf.name)
        if m:
            ports.setdefault(m.group(1), {})["tech"] = _read(wf, 40_000)
    for nf in sorted(loot.glob("nuclei_*_*.txt")):
        m = re.search(r"nuclei_.*_(\d+)\.txt$", nf.name)
        if not m:
            continue
        findings = []
        for l in _read(nf, 120_000).splitlines():
            ls = strip_ansi(l).strip()
            sm = re.search(r"\[(info|low|medium|high|critical)\]", ls, re.I)
            if sm and ls:
                findings.append({"sev": sm.group(1).lower(), "line": ls})
        ports.setdefault(m.group(1), {})["nuclei"] = findings
    for cf in sorted(loot.glob("ferox_*_*.txt")):
        m = re.search(r"ferox_.*_(\d+)\.txt$", cf.name)
        if not m:
            continue
        paths = []
        for l in _read(cf, 120_000).splitlines():
            ls = strip_ansi(l).strip()
            mm = re.match(r"^(\d{3})\s+\S+\s+\S+\s+\S+\s+(\S+)", ls) or re.match(r"^(\d{3}).*?(\S+)\s*$", ls)
            if mm:
                paths.append({"code": mm.group(1), "url": mm.group(2)})
        ports.setdefault(m.group(1), {})["paths"] = paths[:400]
    for ff in sorted(loot.glob("ffuf_*_*.csv")):
        m = re.search(r"ffuf_.*_(\d+)\.csv$", ff.name)
        if not m:
            continue
        paths = []
        try:
            rdr = csv.DictReader(io.StringIO(_read(ff, 120_000)))
            for row in rdr:
                url = row.get("url") or row.get("input.FUZZ") or ""
                code = row.get("status") or row.get("status_code") or ""
                if url:
                    paths.append({"code": str(code), "url": url})
        except Exception:
            pass
        ports.setdefault(m.group(1), {}).setdefault("paths", []).extend(paths[:400])
    out = []
    for port in sorted(ports, key=lambda x: int(x)):
        d = ports[port]
        out.append({
            "port": port,
            "tech": d.get("tech", ""),
            "nuclei": d.get("nuclei", []),
            "paths": d.get("paths", []),
        })
    return out


def parse_bloodhound(loot: Path) -> dict:
    res = {"present": False, "findings": [], "creds_held": [], "playbook": [], "attack_path": None}
    f = loot / "bh_analysis.txt"
    if not f.is_file():
        return res
    res["present"] = True
    lines = _read(f).splitlines()
    sections = []  # (title, [lines])
    cur = None
    for l in lines:
        m = re.match(r"^==\s*(.+?)\s*==$", l)
        if m:
            cur = {"title": m.group(1), "lines": []}
            sections.append(cur)
        elif cur is not None:
            cur["lines"].append(l)

    for sec in sections:
        title = sec["title"]
        body = [x for x in sec["lines"]]
        up = title.upper()
        if up.startswith("PLAYBOOK"):
            res["playbook"] = classify_playbook(body)
        elif up.startswith("CREDENTIALS YOU HOLD"):
            for l in body:
                ls = l.strip()
                if not ls:
                    continue
                parts = re.split(r"\s{2,}", ls, maxsplit=1)
                acct = parts[0].strip()
                cap = parts[1].strip() if len(parts) > 1 else ""
                privesc = "PRIVESC" in cap.upper()
                res["creds_held"].append({"account": acct, "capability": cap, "privesc": privesc})
                if privesc and res["attack_path"] is None:
                    res["attack_path"] = _attack_path(acct, cap)
        else:
            items = [l.strip() for l in body if l.strip()]
            if items:
                res["findings"].append({"title": title, "items": items})
    return res


def _attack_path(acct: str, cap: str):
    m = re.search(r"(GenericAll|GenericWrite|WriteDacl|WriteOwner|AddKeyCredentialLink)\s+on\s+(\S+)", cap)
    mid = f"{m.group(1)} on {m.group(2)}" if m else cap[:48]
    return {"foothold": acct, "control": mid, "goal": "Domain Admin"}


def classify_playbook(body: list) -> list:
    """Turn the playbook text into typed lines the UI can style/copy."""
    out = []
    for raw in body:
        l = raw.rstrip()
        if not l.strip():
            out.append({"t": "space", "v": ""})
            continue
        s = l.strip()
        if re.match(r"^═+", s) or "PRIVESC:" in s:
            out.append({"t": "route_major", "v": s.strip("═ ").strip()})
        elif s.startswith("──") or re.match(r"^──\s*ROUTE", s):
            out.append({"t": "route", "v": s.strip("─ ").strip()})
        elif s.startswith("↳"):
            url = s.lstrip("↳ ").strip()
            out.append({"t": "link", "v": url})
        elif re.match(r"^\d+\)", s):
            out.append({"t": "step", "v": s})
        elif s.startswith("#"):
            out.append({"t": "comment", "v": s})
        elif s.upper().startswith(("WHO", "WHAT", "NOTE", "HOLDERS", "REACH")):
            out.append({"t": "meta", "v": s})
        elif re.search(r"\b(certipy|nxc|netexec|crackmapexec|secretsdump\.py|addcomputer\.py|rbcd\.py|getST\.py|GetUserSPNs\.py|GetNPUsers\.py|targetedKerberoast\.py|hashcat|john|impacket|printerbug\.py|PetitPotam|Rubeus\.exe|bloodyAD|pywhisker|dacledit\.py|owneredit\.py|ntlmrelayx\.py|gpoabuse|SharpGPOAbuse|pyGPOAbuse|Certify|evil-winrm|export KRB5CCNAME)\b", s) or re.match(r"^net rpc\b", s):
            out.append({"t": "cmd", "v": s})
        elif s.startswith("└") or s.startswith("inherited"):
            out.append({"t": "meta", "v": s})
        else:
            out.append({"t": "text", "v": s})
    return out


def parse_adcs(loot: Path) -> dict:
    """Read loot/adcs_analysis.txt (certipy ESC playbook) into playbook + findings."""
    res = {"playbook": [], "findings": []}
    f = loot / "adcs_analysis.txt"
    if not f.is_file():
        return res
    cur = None
    sections = []
    for l in _read(f).splitlines():
        m = re.match(r"^==\s*(.+?)\s*==$", l)
        if m:
            cur = {"title": m.group(1), "lines": []}
            sections.append(cur)
        elif cur is not None:
            cur["lines"].append(l)
    for sec in sections:
        if sec["title"].upper().startswith("PLAYBOOK"):
            res["playbook"] = classify_playbook(sec["lines"])
        else:
            items = [l.strip() for l in sec["lines"] if l.strip()]
            if items:
                res["findings"].append({"title": sec["title"], "items": items})
    return res


def _find_bh_json(loot: Path, kind: str):
    cands = [p for p in loot.glob("**/*_%s.json" % kind) if "ldd" not in p.parts]
    cands.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0)
    return cands[-1] if cands else None


def extract_directory(loot: Path, valid_creds: list) -> dict:
    """Pull a compact users + computers inventory from the BloodHound JSON."""
    res = {"present": False, "users": [], "computers": []}
    owned = {(c.get("user") or "").split("@")[0].lower() for c in valid_creds if c.get("user")}
    uf = _find_bh_json(loot, "users")
    cf = _find_bh_json(loot, "computers")
    if not uf and not cf:
        return res
    res["present"] = True
    if uf:
        try:
            data = json.loads(_read(uf, 6_000_000)).get("data", [])
        except Exception:
            data = []
        for o in data:
            p = o.get("Properties", {}) or {}
            full = p.get("name") or ""
            name = (p.get("samaccountname") or full or "").split("@")[0]
            if not name:
                continue
            desc = p.get("description")
            if isinstance(desc, list):
                desc = "; ".join(str(x) for x in desc if x)
            desc = (str(desc) if desc is not None else "").strip()
            res["users"].append({
                "name": name,
                "enabled": bool(p.get("enabled", True)),
                "admin": bool(p.get("admincount", False)),
                "kerberoastable": bool(p.get("hasspn", False)),
                "asrep": bool(p.get("dontreqpreauth", False)),
                "pwdnotreqd": bool(p.get("passwordnotreqd", False)),
                "desc": desc,
                "owned": name.lower() in owned,
            })
    if cf:
        try:
            data = json.loads(_read(cf, 6_000_000)).get("data", [])
        except Exception:
            data = []
        for o in data:
            p = o.get("Properties", {}) or {}
            name = (p.get("name") or "").split(".")[0]
            if not name:
                continue
            pgsid = str(o.get("PrimaryGroupSID") or p.get("primarygroupsid") or "")
            osn = (p.get("operatingsystem") or "").strip()
            res["computers"].append({
                "name": name,
                "os": osn,
                "dc": pgsid.endswith("-516") or pgsid.endswith("-521") or "domain controller" in osn.lower(),
                "unconstrained": bool(p.get("unconstraineddelegation", False)),
                "enabled": bool(p.get("enabled", True)),
                "owned": name.lower() in owned or (name.lower() + "$") in owned,
            })
    # de-dup by name; sort interesting first
    def _uniq(lst):
        seen = set(); out = []
        for x in lst:
            k = x["name"].lower()
            if k in seen:
                continue
            seen.add(k); out.append(x)
        return out
    res["users"] = _uniq(res["users"])
    res["computers"] = _uniq(res["computers"])
    res["users"].sort(key=lambda u: (not u["owned"], not u["admin"], not (u["kerberoastable"] or u["asrep"]), u["name"].lower()))
    res["computers"].sort(key=lambda c: (not c["dc"], not c["unconstrained"], c["name"].lower()))
    return res


def parse_commands(outdir: Path) -> dict:
    res = {"commands": [], "tools": []}
    f = outdir / "_commands.log"
    if not f.is_file():
        return res
    tools = {}
    for l in _read(f, 400_000).splitlines():
        s = l.strip()
        if not s:
            continue
        cmd = s[2:].strip() if s.startswith("$ ") else s
        res["commands"].append(cmd)
        # first meaningful token = tool
        toks = cmd.split()
        for t in toks:
            if t in ("sudo", "timeout", "-k", "bash", "-c", "PASSWD=", "env") or t.startswith(("-", "PASSWD", "2>", ">", "<", "|")):
                continue
            base = os.path.basename(t).split("=")[0]
            if re.match(r"^[A-Za-z][\w.\-]+$", base):
                tools[base] = tools.get(base, 0) + 1
            break
    res["tools"] = [{"name": k, "count": v} for k, v in sorted(tools.items(), key=lambda kv: -kv[1])]
    return res


def parse_run(rid: str) -> dict:
    outdir = _safe(rid)
    loot = outdir / "loot"
    summary = parse_summary(outdir)
    creds = parse_creds(loot)
    bh = parse_bloodhound(loot)
    adcs = parse_adcs(loot)
    if adcs["playbook"] or adcs["findings"]:
        bh["present"] = True
        bh["adcs"] = True
        if adcs["playbook"]:
            if bh["playbook"]:
                bh["playbook"].append({"t": "space", "v": ""})
            bh["playbook"].extend(adcs["playbook"])
        bh["findings"].extend(adcs["findings"])
    directory = extract_directory(loot, creds["valid"])
    cmds = parse_commands(outdir)
    web = parse_web(outdir, loot)
    lootf = parse_loot(loot)
    crit = [l for l in summary["leads"] if l["sev"] in ("critical", "high")]
    stats = {
        "ports": len(summary["open_ports"]),
        "services": len(summary["services"]),
        "exploitable": sum(1 for s in summary["services"] if s["hot"]),
        "users": len(directory["users"]) or len(creds["users"]),
        "computers": len(directory["computers"]),
        "valid_creds": len(creds["valid"]),
        "flags": len(creds["flags"]),
        "leads": len(summary["leads"]),
        "critical": len(crit),
        "tools": len(cmds["tools"]),
        "commands": len(cmds["commands"]),
        "loot_files": lootf["total"],
    }
    return {
        "id": rid, "summary": summary, "creds": creds, "bloodhound": bh,
        "directory": directory, "commands": cmds, "web": web, "loot": lootf,
        "stats": stats, "critical_leads": crit,
    }


def list_runs() -> list:
    runs = []
    if not SCAN_ROOT.is_dir():
        return runs
    for d in SCAN_ROOT.iterdir():
        m = RUN_RE.match(d.name)
        if not d.is_dir() or not m:
            continue
        st = (d / "_SUMMARY.txt")
        try:
            mtime = d.stat().st_mtime
        except Exception:
            mtime = 0
        runs.append({
            "id": d.name,
            "ip": m.group("ip"),
            "stamp": m.group("stamp"),
            "mtime": mtime,
            "has_summary": st.is_file(),
        })
    runs.sort(key=lambda r: r["mtime"], reverse=True)
    return runs


# --------------------------------------------------------------------------- #
#  Scan launcher (optional)                                                    #
# --------------------------------------------------------------------------- #
RUNS: dict = {}  # run_id -> {proc, queues, lines, status, outdir, target}
TARGET_RE = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9.\-]{0,253})$")
ALLOWED_SVC = {"smb", "ldap", "kerberos", "http", "web", "ftp", "winrm", "mssql",
               "dns", "rdp", "ssh", "smtp", "snmp", "nfs", "redis", "msrpc",
               "telnet", "pop3", "imap", "mysql"}
SAFE_VAL = re.compile(r"^[^\-][\w./:@\-]{0,255}$")  # for login paths/wordlists (no leading dash)


async def _pump(run_id: str):
    rec = RUNS[run_id]
    proc = rec["proc"]
    assert proc.stdout is not None
    while True:
        raw = await proc.stdout.readline()
        if not raw:
            break
        line = strip_ansi(raw.decode(errors="replace").rstrip("\n"))
        rec["lines"].append(line)
        m = re.search(r"Output\s*:\s*(\S+enum_\S+)", line)
        if m:
            rec["outdir"] = m.group(1)
        for q in list(rec["queues"]):
            try:
                q.put_nowait(line)
            except Exception:
                pass
    await proc.wait()
    if rec.get("stopped"):
        rec["status"] = "stopped"
    else:
        rec["status"] = "done" if proc.returncode == 0 else f"exited ({proc.returncode})"
    for q in list(rec["queues"]):
        q.put_nowait(None)


# --------------------------------------------------------------------------- #
#  App                                                                          #
# --------------------------------------------------------------------------- #
app = FastAPI(title="enumerator dashboard")


@app.get("/", response_class=HTMLResponse)
def index():
    for p in (HERE / "static" / "index.html", HERE / "index.html"):
        if p.is_file():
            return p.read_text()
    return HTMLResponse(
        "<pre style='font-family:monospace;color:#fb7185;padding:24px'>"
        "index.html not found.\n\nPut it in a 'static' folder next to server.py:\n"
        "  enum_dashboard/server.py\n  enum_dashboard/static/index.html\n</pre>",
        status_code=500,
    )


@app.get("/api/config")
def config():
    return {"scan_root": str(SCAN_ROOT), "script": ENUM_SCRIPT, "allow_scan": ALLOW_SCAN}


@app.get("/api/runs")
def runs():
    return {"runs": list_runs()}


@app.get("/api/run/{rid}")
def run(rid: str):
    return parse_run(rid)


@app.get("/api/run/{rid}/raw", response_class=PlainTextResponse)
def raw(rid: str, path: str = Query(...)):
    outdir = _safe(rid)
    target = (outdir / path).resolve()
    if outdir not in target.parents:
        raise HTTPException(403, "path escapes run dir")
    if not target.is_file():
        raise HTTPException(404, "file not found")
    if target.stat().st_size > 3_000_000:
        return PlainTextResponse("(file too large to preview)")
    return PlainTextResponse(_read(target, 2_000_000))


@app.get("/api/run/{rid}/report.pdf")
def report_pdf(rid: str):
    data = parse_run(rid)
    try:
        import report
    except ImportError:
        raise HTTPException(500, "PDF export needs the 'reportlab' package. Install it with "
                                 "'pip install reportlab' (or re-run ./run.sh) and try again.")
    try:
        pdf = report.build_report(data)
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(500, "Report generation failed: %s: %s" % (type(e).__name__, e))
    ip = (data.get("summary", {}) or {}).get("ip") or rid
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", str(ip))
    fname = "enum_report_%s.pdf" % safe
    return Response(content=pdf, media_type="application/pdf",
                    headers={"Content-Disposition": 'attachment; filename="%s"' % fname})


@app.post("/api/scan")
async def scan(body: dict = Body(...)):
    if not ALLOW_SCAN:
        raise HTTPException(403, "scanning is disabled (ENUM_ALLOW_SCAN=0)")
    target = (body.get("target") or "").strip()
    if not TARGET_RE.match(target):
        raise HTTPException(400, "invalid target")
    mode = body.get("mode", "auth")
    argv = ["bash", ENUM_SCRIPT]
    argv += ["--auth", target] if mode == "auth" else ["--unauth", target]
    for opt, flag in (("user", "-u"), ("password", "-p"), ("domain", "-d")):
        val = (body.get(opt) or "").strip()
        if val:
            argv += [flag, val]

    # service selection (empty / "all" => every handler)
    svcs = [s.strip().lower() for s in (body.get("services") or []) if s.strip()]
    svcs = [s for s in svcs if s in ALLOWED_SVC]
    if svcs and not body.get("all_services", False):
        argv += ["--services", ",".join(dict.fromkeys(svcs))]

    # boolean toggles -> negative flags (defaults are "on" in the scanner)
    if body.get("web", True) is False:          argv.append("--no-web")
    if body.get("web_fuzz", True) is False:     argv.append("--no-web-fuzz")
    if body.get("web_vulns", False) is True:    argv.append("--web-vulns")
    if body.get("ftp_download", True) is False: argv.append("--no-loot-ftp")
    if body.get("smb_download", True) is False: argv.append("--no-loot-shares")
    if body.get("bloodhound", True) is False:   argv.append("--no-bloodhound")
    if body.get("flags", True) is False:        argv.append("--no-flags")
    if body.get("aggressive", False) is True:   argv.append("--aggressive")

    # optional login-brute / wordlist paths (sanitised; no leading dash)
    for key, flag in (("login_path", "--login-path"), ("login_userlist", "--login-userlist"),
                      ("login_passlist", "--login-passlist"), ("login_failstr", "--login-failstr"),
                      ("web_wordlist", "--web-wordlist"), ("vhost_wordlist", "--vhost-wordlist"),
                      ("param_wordlist", "--param-wordlist")):
        v = (body.get(key) or "").strip()
        if v and SAFE_VAL.match(v):
            argv += [flag, v]

    run_id = secrets.token_hex(6)
    proc = await asyncio.create_subprocess_exec(
        *argv, cwd=str(SCAN_ROOT),
        stdin=asyncio.subprocess.DEVNULL,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        start_new_session=True,   # own process group so we can kill the whole tree
    )
    RUNS[run_id] = {"proc": proc, "queues": [], "lines": [], "status": "running",
                    "outdir": "", "target": target, "argv": argv[2:], "stopped": False}
    asyncio.create_task(_pump(run_id))
    return {"run_id": run_id, "cmd": " ".join(argv)}


@app.get("/api/scans")
def scans():
    """Active/recent scans this server launched, so the UI can re-attach."""
    out = []
    for rid, rec in RUNS.items():
        out.append({"run_id": rid, "target": rec.get("target", ""),
                    "status": rec["status"], "lines": len(rec["lines"]),
                    "outdir": rec.get("outdir", "")})
    out.sort(key=lambda r: r["status"] != "running")  # running first
    return {"scans": out}


@app.get("/api/scan/{run_id}/status")
def scan_status(run_id: str):
    rec = RUNS.get(run_id)
    if not rec:
        raise HTTPException(404, "no such scan")
    return {"status": rec["status"], "outdir": rec["outdir"], "lines": len(rec["lines"])}


def _terminate_group(proc):
    """SIGTERM the whole process group (kills fscan etc.), then SIGKILL after a grace period."""
    if proc.returncode is not None:
        return
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        try:
            proc.terminate()
        except Exception:
            pass

    async def _hard():
        await asyncio.sleep(5)
        if proc.returncode is None:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
    asyncio.create_task(_hard())


@app.post("/api/scan/{run_id}/stop")
async def stop_scan(run_id: str):
    rec = RUNS.get(run_id)
    if not rec:
        raise HTTPException(404, "no such scan")
    if rec["proc"].returncode is None:
        rec["stopped"] = True
        rec["status"] = "stopping"
        _terminate_group(rec["proc"])
    return {"status": rec["status"]}


@app.delete("/api/run/{rid}")
async def delete_run(rid: str):
    outdir = _safe(rid)   # validates this is an enum_ dir under SCAN_ROOT
    # if a scan is actively writing into this folder, stop it (and its child tools) first
    for hid, rec in list(RUNS.items()):
        od = rec.get("outdir") or ""
        if od and Path(od).name == rid and rec["proc"].returncode is None:
            rec["stopped"] = True
            _terminate_group(rec["proc"])
            try:
                await asyncio.wait_for(rec["proc"].wait(), timeout=8)
            except Exception:
                pass
    try:
        shutil.rmtree(outdir)
    except Exception as e:
        raise HTTPException(500, f"delete failed: {e}")
    for hid in [h for h, r in RUNS.items() if r.get("outdir") and Path(r["outdir"]).name == rid]:
        RUNS.pop(hid, None)
    return {"deleted": rid}


@app.websocket("/ws/{run_id}")
async def ws(run_id: str, websocket: WebSocket):
    await websocket.accept()
    rec = RUNS.get(run_id)
    if not rec:
        await websocket.send_json({"type": "error", "msg": "no such scan"})
        await websocket.close()
        return
    q: asyncio.Queue = asyncio.Queue()
    for ln in rec["lines"]:  # replay backlog
        q.put_nowait(ln)
    rec["queues"].append(q)
    if rec["status"] != "running":
        q.put_nowait(None)
    try:
        while True:
            item = await q.get()
            if item is None:
                await websocket.send_json({"type": "end", "status": rec["status"], "outdir": rec["outdir"]})
                break
            await websocket.send_json({"type": "line", "line": item})
    except WebSocketDisconnect:
        pass
    finally:
        if q in rec["queues"]:
            rec["queues"].remove(q)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=os.environ.get("ENUM_HOST", "127.0.0.1"),
                port=int(os.environ.get("ENUM_PORT", "8000")))
