# enumerator dashboard

A local web UI for [`enumerator.sh`](../enumerator.sh). It parses the artifacts
each `enum_<ip>_<stamp>/` run directory already contains and presents them as a
navigable, cyber-themed dashboard — and can optionally launch new scans and
stream their console output live.

It is **read-only by default** and binds to **127.0.0.1** only. Nothing is sent
anywhere; it just reads the files your tool writes on the same box.

## Quick start (one command)

From this `enum_dashboard` folder, run:

```bash
bash run.sh
```

That's it. The first time, it sets up a small Python environment and installs
what it needs (takes a minute). Then it prints a line like:

```
  open in your browser →  http://127.0.0.1:8000
```

Open that address in your browser. Press **Ctrl+C** in the terminal to stop it.

`run.sh` tries to find the folder that holds your `enum_<ip>_<stamp>` run
directories on its own (it checks the current folder, the folder above, and
`~/Desktop`). If it guesses wrong, just tell it where to look:

```bash
bash run.sh /root/Desktop          # point it at your run folders
bash run.sh /root/Desktop 8200     # ...and use a different port
```

> On Kali you normally run `enumerator.sh` as **root**, and the `enum_*` folders
> land wherever you ran it (often `~/Desktop` or `/root/Desktop`). Point `run.sh`
> at that same place and your past runs show up in the dropdown.

## What it shows

- **Overview** — target HUD, the validated escalation path, key counts
  (ports / exploitable / users / creds / flags / critical leads), captured
  flags, and the priority `[!!]`/`[!]` leads.
- **Ports & Services** — the service table with exploitable rows highlighted
  (cross-referenced against the leads), plus a link to each raw service file.
- **Credentials** — validated `user:pass`, candidate secrets, LDAP
  credential-bearing fields, flags, and the enumerated user list. One-click copy.
- **Loot** — every file under `loot/`, grouped (hashes/dumps, BloodHound, LDAP
  dumps, web/fuzzing, downloaded shares…) with sizes and an in-browser viewer.
- **Web & Fuzzing** — per-port tech fingerprint, nuclei findings (severity
  coloured), and discovered paths from feroxbuster/ffuf.
- **Overview** — the command center. Combines, on one screen: a status verdict
  (privilege path found / creds obtained / recon done), the **credentials you
  hold** and what each one can do, a **what-to-do-next** panel (every privilege
  path as a condensed card, including ADCS, linking to the full playbook in the
  BloodHound tab), the **users** table (owned / admin / kerberoastable / AS-REP /
  disabled badges), the **computers** table (DC / unconstrained-delegation
  badges), priority leads, and captured flags.
- **Export report** — the top-bar **⤓ export report** button downloads a single,
  comprehensive **PDF** ("Enumeration report") of the selected scan, with a clean,
  aerated layout. Sections, in order: **01 Executive summary**, **02 Scope**,
  **03 Ports and services**, **04 Loot** (credentials obtained with their source,
  every file/share/FTP artifact collected, flags), **05 BloodHound analysis –
  Attack paths** (the playbook route cards with copy-ready commands + HackTricks
  links, plus the domain users/computers inventory), **06 Web & fuzzing** (or
  *N/A*), and **07 Tools used and command-line history** (the full audit trail of
  every command executed). Requires `reportlab`, included in `requirements.txt`.
- **BloodHound** — the full attack analysis **and** the step-by-step playbook in
  one place: the path-to-DA strip, every privilege path rendered as route cards
  with copyable commands + HackTricks links, the *credentials you hold → what
  each can do* summary, and the supporting findings. (The old separate Playbook
  tab was removed — it showed the same information.)
  The playbook engine inside the BloodHound tab is **general-purpose**: it renders
  whatever privilege path a given box exposes, as polished route cards. Covered:
  - **computer-object ACEs** → Shadow Credentials + RBCD
  - **user-object ACEs** (incl. ForceChangePassword / AddKeyCredentialLink) →
    Shadow Credentials, Targeted Kerberoast, Force-password-reset
  - **group-object ACEs** → add-yourself-to-the-group
  - **Kerberoasting**, **AS-REP roasting**, **unconstrained delegation**, **DCSync**
  - **WriteOwner / WriteDacl** chains get a "take ownership / grant yourself
    rights first" pre-step
  - **ADCS / certipy ESC1–ESC8+** — when `certipy find` reports a vulnerable
    template, the exact `certipy req … -upn administrator` → `certipy auth -pfx`
    → Pass-the-Hash chain is emitted as a route card with the AD CS
    domain-escalation HackTricks link. ESC4 (rewrite template), ESC7 (Manage CA),
    and ESC8 (NTLM-relay a DC to web-enrollment → DCSync) get their own tailored
    routes.
  If several paths exist on one box, each is shown as its own objective.
- **Commands** — the full `_commands.log` (searchable) plus the tools used.
- **Live Scan** — configure and launch a scan, then watch the output stream in a
  live console. The form lets you choose:
  - **mode** (auth/unauth), target, and optional user / pass / domain;
  - **services to enumerate** — *All services*, or untick it and pick specific
    ones (SMB, LDAP, Kerberos, Web, FTP, WinRM, MSSQL, …);
  - **web** — enumerate web at all, run ffuf fuzzing (dirs / vhosts / GET+POST
    params), and an opt-in **OWASP vuln test** pass;
  - **download loot** — pull readable SMB shares and/or anonymous FTP contents
    (each toggleable, mirrored into `loot/`);
  - **BloodHound** on/off, **flag hunting** on/off (untick for *box-build mode*),
    and **aggressive** (spray + intrusive checks);
  - an **advanced** drawer for login-brute (path + user/pass lists + fail string)
    and custom wordlists.

  You can switch to other tabs while a scan runs and come back — the console
  re-attaches to the running scan, and the **Overview** shows a "scan running"
  banner while it's live. **Stop** a scan from the banner or the Live Scan card
  (this kills `fscan` and every child tool, not just the parent), and **delete**
  a run with the 🗑 button by the run selector (removing the folder from disk;
  if that run is still scanning it's stopped first).

### Web / OWASP testing

The web side targets the OWASP-Top-10 categories, all driven by standard Kali
tools that the script calls if they're installed (it skips any that aren't):

- **content / vhost / parameter discovery** — `feroxbuster`/`ffuf` for dirs &
  files, `ffuf` vhost mode (needs a `-d` domain), `ffuf` GET & POST parameter
  fuzzing;
- **Security Misconfiguration** — `nikto`, `whatweb`, plus the ffuf passes;
- **Vulnerable/Outdated Components** — `whatweb` + `nuclei` (and a broader
  `nuclei` tag pass under `--web-vulns`);
- **Cryptographic Failures** — `testssl.sh` or `sslscan` on HTTPS;
- **Injection** — `sqlmap --batch --crawl` (only when **aggressive**, since it's
  intrusive) and a quick `curl` LFI/path-traversal probe;
- **Auth Failures** — login brute via `ffuf` (or `hydra`), opt-in, run only when
  you supply a login path **and** both word-lists. *It assumes `username`/
  `password` form fields* — tune the field names in the script if your target
  differs.

Install the web tools you don't have (`sudo apt install nikto sqlmap ffuf
feroxbuster nuclei testssl.sh sslscan hydra wfuzz`). The script's preflight lists
anything missing at start-up.

> **Heads-up about Support.htb:** it has **no web server** (no 80/443 — the
> `139 http` / `5985 http` you may see are fscan mislabels for SMB/WinRM). So the
> Web and OWASP tabs stay empty on Support; those features are for the many
> web-to-root boxes on the list. Support is solved through LDAP (cleartext
> password in the `info` field) → `Shared Support Accounts` GenericAll on the DC.

## If `run.sh` doesn't work for you (manual start)

`run.sh` is just a convenience wrapper. You can do the same thing by hand:

```bash
cd enum_dashboard
python3 -m venv .venv && source .venv/bin/activate    # one-time setup
pip install -r requirements.txt                        # one-time setup
ENUM_SCAN_ROOT="$HOME/Desktop" uvicorn server:app --host 127.0.0.1 --port 8000
```

(On Kali, if `python3 -m venv` complains, run `sudo apt install python3-venv`
first, or skip the venv and use `pip install -r requirements.txt --break-system-packages`.)

### Settings you can override

`run.sh` reads these too, so you can `export` them before running it:

| var               | default            | meaning                                            |
|-------------------|--------------------|----------------------------------------------------|
| `ENUM_SCAN_ROOT`  | auto-detected      | directory holding the `enum_<ip>_<stamp>` folders  |
| `ENUM_SCRIPT`     | auto-detected      | path to the scanner (used by **Live Scan**)        |
| `ENUM_ALLOW_SCAN` | `1`                | set to `0` to disable launching (view-only)        |
| `ENUM_PORT`       | `8000`             | port                                               |

## Notes

- **Launching scans runs as whatever user started uvicorn.** `enumerator.sh`
  expects root and its tools (fscan, nxc, impacket, …) on `PATH`, so if you want
  Live Scan to work, start uvicorn from the same environment you normally run the
  scanner in. Otherwise leave `ENUM_ALLOW_SCAN=0` and use it as a viewer.
- Scan arguments are passed with `shell=False`; the target is validated, service
  names are checked against an allow-list, and login/wordlist paths are sanitised
  (no leading dashes / shell metacharacters). Still, only run this on your own
  machine against authorised targets.
- The **BloodHound playbook** keeps `<password>` as a placeholder — substitute from
  `loot/valid_creds.txt` when you run a command.
