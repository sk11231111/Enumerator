#!/usr/bin/env bash
# One-command launcher for the enumerator dashboard.
#
#   bash run.sh                 # auto-detect everything, open on :8000
#   bash run.sh /root/Desktop   # tell it where your enum_* folders live
#   bash run.sh /root/Desktop 8200   # ...and which port
#
# It sets up a Python virtual env, installs deps the first time, finds the
# directory that holds your enum_<ip>_<stamp> run folders and your
# enumerator.sh, then starts the web UI on 127.0.0.1 (localhost only).

set -euo pipefail
cd "$(dirname "$0")"
DASH="$(pwd)"
PARENT="$(dirname "$DASH")"

c_grn=$'\e[92m'; c_cyn=$'\e[96m'; c_dim=$'\e[90m'; c_yel=$'\e[93m'; c_rst=$'\e[0m'
say(){ printf '%s\n' "$*"; }

# ---------------------------------------------------------------- arguments --
SCAN_ROOT="${1:-${ENUM_SCAN_ROOT:-}}"
PORT="${2:-${ENUM_PORT:-8000}}"

# -------------------------------------------- find the run-folder directory --
# Look for the newest enum_<ip>_<stamp> folder in a few likely places.
if [[ -z "${SCAN_ROOT}" ]]; then
  best=""; best_t=0
  for base in "$PWD" "$PARENT" "$HOME/Desktop" "$HOME" "/root/Desktop" "/root"; do
    [[ -d "$base" ]] || continue
    for d in "$base"/enum_*_*/ ; do
      [[ -d "$d" ]] || continue
      t=$(stat -c %Y "$d" 2>/dev/null || echo 0)
      (( t > best_t )) && { best_t=$t; best="$base"; }
    done
  done
  SCAN_ROOT="${best:-$PARENT}"
fi
SCAN_ROOT="$(cd "$SCAN_ROOT" 2>/dev/null && pwd || echo "$SCAN_ROOT")"

# -------------------------------------------------------- find enumerator.sh --
SCRIPT="${ENUM_SCRIPT:-}"
if [[ -z "${SCRIPT}" ]]; then
  for cand in "$SCAN_ROOT"/enumerator*.sh "$PARENT"/enumerator*.sh "$DASH"/enumerator*.sh; do
    [[ -f "$cand" ]] && { SCRIPT="$(cd "$(dirname "$cand")" && pwd)/$(basename "$cand")"; break; }
  done
  SCRIPT="${SCRIPT:-$PARENT/enumerator.sh}"
fi

# --------------------------------------------------- python env + packages --
if ! command -v python3 >/dev/null 2>&1; then
  say "${c_yel}python3 not found. Install it: sudo apt install python3 python3-venv${c_rst}"; exit 1
fi
USE_VENV=1
if [[ ! -d .venv ]]; then
  say "${c_dim}Setting up a Python virtual env (first run only)…${c_rst}"
  python3 -m venv .venv 2>/dev/null || USE_VENV=0
fi
if [[ "$USE_VENV" -eq 1 ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
  if ! python3 -c 'import fastapi, uvicorn, reportlab' 2>/dev/null; then
    say "${c_dim}Installing dependencies…${c_rst}"; pip install -q -r requirements.txt
  fi
else
  say "${c_dim}venv unavailable — installing into system python…${c_rst}"
  python3 -c 'import fastapi, uvicorn, reportlab' 2>/dev/null || pip install -q -r requirements.txt --break-system-packages
fi

# --------------------------------------------------------------- run count --
runs=$(find "$SCAN_ROOT" -maxdepth 1 -type d -name 'enum_*_*' 2>/dev/null | wc -l | tr -d ' ')

export ENUM_SCAN_ROOT="$SCAN_ROOT" ENUM_SCRIPT="$SCRIPT" ENUM_PORT="$PORT"
URL="http://127.0.0.1:${PORT}"

say ""
say "${c_grn}  ┌─ enumerator dashboard ────────────────────────────────${c_rst}"
say "${c_grn}  │${c_rst}  run folders : ${c_cyn}${SCAN_ROOT}${c_rst}  ${c_dim}(${runs} found)${c_rst}"
say "${c_grn}  │${c_rst}  scanner     : ${c_cyn}${SCRIPT}${c_rst}"
say "${c_grn}  │${c_rst}  open in your browser →  ${c_yel}${URL}${c_rst}"
say "${c_grn}  │${c_rst}  ${c_dim}stop with Ctrl+C${c_rst}"
say "${c_grn}  └───────────────────────────────────────────────────────${c_rst}"
say ""
if [[ "$runs" == "0" ]]; then
  say "${c_dim}  No enum_* folders here yet. Either pass the right path"
  say "  (e.g. 'bash run.sh /root/Desktop'), or use the Live Scan tab.${c_rst}"
  say ""
fi

# try to pop the browser open (ignored if headless)
( sleep 1.6; command -v xdg-open >/dev/null 2>&1 && xdg-open "$URL" >/dev/null 2>&1 || true ) &

exec python3 -m uvicorn server:app --host 127.0.0.1 --port "$PORT"
